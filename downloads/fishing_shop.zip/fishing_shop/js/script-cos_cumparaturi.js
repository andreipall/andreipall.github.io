$( document ).ready(function() {
	$('#sendOrder').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deleteProduct').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$(".quantity").change(function() {
		var product_id = $(this).attr('id');
		var quantity = $(this).val();
		$.post( "/fishing_shop/data/modifica_cantitate_produs.php", { product_id: product_id, quantity: quantity })
		  .done(function( data ) {
			$("#cart-products-number").text(data.nr_total_produse);
			$("#total_cost").text(data.cost_total);
		}, "json");
	});
});