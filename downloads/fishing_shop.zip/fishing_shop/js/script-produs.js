$( document ).ready(function() {
	$('#editProduct').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deleteProduct').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	
	$("#add-to-cart").click(function(event) {
		event.preventDefault();
		var cart_items = parseInt($("#cart-products-number").text());
		var quantity = parseInt($("#quantity").val());
		if(isNaN(quantity)) {
			var quantity = 1;
		}
		var promotion_id = $("#promotion-id").val();
		var selloff = $("#selloff").val();
		var product_id = $("#product-id").val();

		$("#cart-products-number").text(cart_items + quantity);
	    //alert(cart_items);
		$.post( "/fishing_shop/data/adauga_produs.php", { product_id: product_id, promotion_id: promotion_id, selloff: selloff, quantity: quantity })
		  .done(function( data ) {
			location.reload();
		});
	});
	
	$("#add-review").click(function(event) {
		event.preventDefault();

		var product_id = $("#product-id").val();
		var review = $("#review").val();
	    //alert(review);
		
		$.post( "/fishing_shop/data/adauga_recenzie.php", { product_id: product_id, review: review })
		  .done(function( data ) {
			location.reload();
		});
	});
	
	$(".add-review-response").click(function(event) {
		event.preventDefault();
		if ($(this).hasClass("disabled")) {
			event.preventDefault();
			//alert("disabled");
		}
		else {
			$(this).addClass("disabled");
			//alert("add disabled");
			var product_id = $("#product-id").val();
			var parent_review_id = $(this).attr('id');
			$('<form role="form"><textarea name="response" class="form-control response" rows="3" required></textarea><button class="btn btn-default btn-xs add-response">Adauga raspuns</button></form>').insertAfter(this);
			$(this).parent().find(".add-response").click(function(e) {
				e.preventDefault();

				var review = $(this).parent().find(".response").val();
				$.post( "/fishing_shop/data/adauga_recenzie.php", { product_id: product_id, review: review, parent_review_id: parent_review_id })
				  .done(function( data ) {
					location.reload();
				});
			});
		}
	});
	
	$(".delete-review").click(function(event) {
		event.preventDefault();
		var review_id = $(this).attr('review_id');
		if (confirm('Sunteti sigur ca doriti sa stergeti recenzia?')) { 
			$.post( "/fishing_shop/data/sterge_recenzie.php", { id: review_id })
			  .done(function(data) {
				location.reload();
			});
		}
	});
});