$( document ).ready(function() {
	$('#editRole').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deleteRole').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
  
});