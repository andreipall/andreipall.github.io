$( document ).ready(function() {
  $(".role-permission").click(function() {
    var id = $(this).attr("id");
	
	var ids = id.split("_");
	var role_id = ids[0];
	var permission_id = ids[1];

	if($("#"+id).is(':checked'))
	{
		
		$.post("/fishing_shop/data/permisiuni_utilizatori.php", { action: "add", id_rol: role_id, id_permisiune: permission_id });
	}
	else
	{
		$.post("/fishing_shop/data/permisiuni_utilizatori.php", { action: "delete", id_rol: role_id, id_permisiune: permission_id });
	}
    /*
    var name = $("#name").val();
	var description = $("#description").val();
	
    $.post("/fishing_shop/data/permisiune.php", { action: "add", nume: name, descriere: description })
	  .done(function( data ) {
		$("#name").val('');
		$("#description").val('');
		//$('#add-permission').modal('hide');
		//alert( "Data Loaded: " + data );
	  });
	*/
  });
  
});