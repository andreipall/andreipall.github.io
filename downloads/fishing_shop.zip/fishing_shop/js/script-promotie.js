$( document ).ready(function() {
	$('#editPromotion').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deletePromotion').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
});