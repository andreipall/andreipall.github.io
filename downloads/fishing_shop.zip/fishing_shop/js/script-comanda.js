$( document ).ready(function() {
	$("#save_status").click(function(event) {
		event.preventDefault();
	    var order = $("#order_id").val();
		var status = $("#status").val();
		$.post( "/fishing_shop/data/schimba_status_comanda.php", { order:order, status: status })
		  .done(function(data) {
			location.reload();
		});
	});
});