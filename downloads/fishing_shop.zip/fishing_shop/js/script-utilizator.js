$( document ).ready(function() {
	$('#editUser').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deleteUser').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
});