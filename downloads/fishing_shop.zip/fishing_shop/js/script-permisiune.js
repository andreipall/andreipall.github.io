$( document ).ready(function() {
  $('#editPermission').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deletePermission').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
  
});