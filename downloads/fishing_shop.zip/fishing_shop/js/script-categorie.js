$( document ).ready(function() {
	$('#editCategory').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
	$('#deleteCategory').on('hide.bs.modal', function (e) {
	  $(this).data('bs.modal', null);
	})
});