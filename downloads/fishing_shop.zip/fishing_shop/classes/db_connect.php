<?php 
//require_once 'config.php';

class Db_connect
{
	private static $host = DB_HOST;
	private static $database = DB_NAME;
	private static $password = DB_PASSWORD;
	private static $conn;
	
	public static function createConnection() {
		self::$conn = oci_connect(self::$database, self::$password, self::$host);
		if (!self::$conn) {
		    $e = oci_error();
		    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
		}
		return self::$conn;
	}
	
	public static function closeConnection() {
		oci_close(self::$conn);
	}
}
?>