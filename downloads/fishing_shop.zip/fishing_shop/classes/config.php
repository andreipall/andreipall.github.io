<?php
define("DB_HOST", "localhost/XE");
define("DB_NAME", "fishing_shop");
define("DB_PASSWORD", "password");
define("SRV_PATH", $_SERVER["DOCUMENT_ROOT"]."/fishing_shop/");
define("HOME_PATH", "/fishing_shop/");
define("SELLOFFS_PROD", 10);
define("PER_PAGE", 6);
?>