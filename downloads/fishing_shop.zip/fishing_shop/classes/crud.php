<?php
require_once SRV_PATH.'classes/db_connect.php';

class Crud {
	private $conn;
	private $sql;

	function __construct() {
		$this -> conn = Db_connect::createConnection();
	}

	public function select($coloane, $tabel, $clauza_where, $clauza_order=null) {
		/*
		 SELECT
		 [ALL | DISTINCT | DISTINCTROW ]
		 [HIGH_PRIORITY]
		 [STRAIGHT_JOIN]
		 [SQL_SMALL_RESULT] [SQL_BIG_RESULT] [SQL_BUFFER_RESULT]
		 [SQL_CACHE | SQL_NO_CACHE] [SQL_CALC_FOUND_ROWS]
		 select_expr [, select_expr ...]
		 [FROM table_references
		 [WHERE where_condition]
		 [GROUP BY {col_name | expr | position}
		 [ASC | DESC], ... [WITH ROLLUP]]
		 [HAVING where_condition]
		 [ORDER BY {col_name | expr | position}
		 [ASC | DESC], ...]
		 [LIMIT {[offset,] row_count | row_count OFFSET offset}]
		 [PROCEDURE procedure_name(argument_list)]
		 [INTO OUTFILE 'file_name' export_options
		 | INTO DUMPFILE 'file_name'
		 | INTO var_name [, var_name]]
		 [FOR UPDATE | LOCK IN SHARE MODE]]
		 */
		$sql = "SELECT ";
		foreach ($coloane as $val) {
			$sql .= $val . ", ";
		}
		$sql = substr($sql, 0, -2);
		$sql .= " FROM ";
		foreach ($tabel as $val) {
			$sql .= $val . ", ";
		}
		$sql = substr($sql, 0, -2);
		if (!empty($clauza_where)) {
			$sql .= " WHERE " . $clauza_where;
		}
		if (!empty($clauza_order)) {
			$sql .= " ORDER BY " . $clauza_order;
		}
		//echo $sql;die;
		$stid = oci_parse($this -> conn, $sql);
		oci_execute($stid);
		$result = array();
		while ($row = oci_fetch_object($stid)) {
			$result[] = $row;
		}
		//var_dump($result);
		return $result;
		//return json_encode($result);
	}

	public function insert($tabel, $coloane, $valori) {
		/*
		 INSERT [LOW_PRIORITY | DELAYED | HIGH_PRIORITY] [IGNORE]
		 [INTO] tbl_name [(col_name,...)]
		 {VALUES | VALUE} ({expr | DEFAULT},...),(...),...
		 [ ON DUPLICATE KEY UPDATE
		 col_name=expr
		 [, col_name=expr] ... ]
		 */
		$sql = "INSERT INTO " . $tabel . " (";
		foreach ($coloane as $val) {
			$sql .= $val . ", ";
		}
		$sql = substr($sql, 0, -2);
		$sql .= ") VALUES (";
		foreach ($valori as $val) {
			$sql .= "'" . addslashes($val) . "', ";
		}
		$sql = substr($sql, 0, -2) . ")";
		//echo $sql;die;
		$stid = oci_parse($this -> conn, $sql);

		if (oci_execute($stid)) {
			$msg = array('tip' => 'succes', 'mesaj' => 'Informatia a fost adaugata cu succes !');
		} else {
			$msg = array('tip' => 'eroare', 'mesaj' => 'Eroare intrducere date !');
		}
		
		return $msg;
		//return "[" . json_encode($msg) . "]";
	}

	public function update($tabel, $coloane, $clauza_where) {
		/*
		 UPDATE [LOW_PRIORITY] [IGNORE] table_reference
		 SET col_name1={expr1|DEFAULT} [, col_name2={expr2|DEFAULT}] ...
		 [WHERE where_condition]
		 [ORDER BY ...]
		 [LIMIT row_count]
		 */
		$sql = "UPDATE " . $tabel . " SET ";
		foreach ($coloane as $key => $value) {
			$sql .= $key . " = '" . addslashes($value) . "', ";
		}
		$sql = substr($sql, 0, -2);
		if (!empty($clauza_where)) {
			$sql .= " WHERE " . $clauza_where;
		}
		/*$sql .= " WHERE ";

		$max = sizeof($clauza_where);
		$i = 1;
		foreach ($clauza_where as $key => $value) {
			$sql .= $key . " = '" . $value . "'";
			if ($i < $max) {
				$sql .= " AND ";
			}
			$i++;
		}*/
		$stid = oci_parse($this -> conn, $sql);
		if (oci_execute($stid)) {
			$msg = array('tip' => 'succes', 'mesaj' => 'Informatia a fost modificata cu succes !');
		} else {
			$msg = array('tip' => 'eroare', 'mesaj' => 'Eroare modificare date !');
		}

		return $msg;
	}

	public function delete($tabel, $clauza_where) {
		/*
		 DELETE [LOW_PRIORITY] [QUICK] [IGNORE] FROM tbl_name
		 [WHERE where_condition]
		 [ORDER BY ...]
		 [LIMIT row_count
		 */
		$sql = "DELETE FROM " . $tabel . " WHERE ";
		$sql .= $clauza_where;
		/*
		$max = sizeof($clauza_where);
		$i = 1;
		foreach ($clauza_where as $key => $value) {
			$sql .= $key . " = '" . $value . "'";
			if ($i < $max) {
				$sql .= " AND ";
			}
			$i++;
		}*/
		$stid = oci_parse($this -> conn, $sql);
		if (oci_execute($stid)) {
			$msg = array('tip' => 'succes', 'mesaj' => 'Informatia a fost stearsa cu succes !');
		} else {
			$msg = array('tip' => 'eroare', 'mesaj' => 'Eroare stergere date !');
		}

		return "[" . json_encode($msg) . "]";
	}
	
	public function run_stored_proc($proc) {
		$sql = "BEGIN ".$proc." END;";
		$stid = oci_parse($this -> conn, $sql);
		// Bind the output parameter
		oci_bind_by_name($stid,':output',$output);
		oci_execute($stid);

		if ($output=="1") {
			$msg = array('tip' => 'succes', 'mesaj' => 'Procedura a fost executata cu succes !');
		} else {
			$msg = array('tip' => 'eroare', 'mesaj' => 'Eroare la executarea procedurii !');
		}
		return $msg;
	}
	
	public function run_stored_proc_ins($proc) {
		$sql = "BEGIN ".$proc." END;";
		$stid = oci_parse($this -> conn, $sql);
		// Bind the output parameter
		oci_bind_by_name($stid,':id',$id);
		oci_bind_by_name($stid,':output',$output);
		oci_execute($stid);

		if ($output=="1") {
			$msg = array('tip' => 'succes', 'mesaj' => 'Procedura a fost executata cu succes !', 'id' => $id);
		} else {
			$msg = array('tip' => 'eroare', 'mesaj' => 'Eroare la executarea procedurii !');
		}
		return $msg;
	}
	
	public function count($tabel, $clauza_where) {
		/*
		 SELECT
		 [ALL | DISTINCT | DISTINCTROW ]
		 [HIGH_PRIORITY]
		 [STRAIGHT_JOIN]
		 [SQL_SMALL_RESULT] [SQL_BIG_RESULT] [SQL_BUFFER_RESULT]
		 [SQL_CACHE | SQL_NO_CACHE] [SQL_CALC_FOUND_ROWS]
		 select_expr [, select_expr ...]
		 [FROM table_references
		 [WHERE where_condition]
		 [GROUP BY {col_name | expr | position}
		 [ASC | DESC], ... [WITH ROLLUP]]
		 [HAVING where_condition]
		 [ORDER BY {col_name | expr | position}
		 [ASC | DESC], ...]
		 [LIMIT {[offset,] row_count | row_count OFFSET offset}]
		 [PROCEDURE procedure_name(argument_list)]
		 [INTO OUTFILE 'file_name' export_options
		 | INTO DUMPFILE 'file_name'
		 | INTO var_name [, var_name]]
		 [FOR UPDATE | LOCK IN SHARE MODE]]
		 */
		$sql = "SELECT COUNT(*) AS COUNT FROM ".$tabel;
		/*
		foreach ($tabel as $val) {
			$sql .= $val . ", ";
		}
		$sql = substr($sql, 0, -2);*/
		if (!empty($clauza_where)) {
			$sql .= " WHERE " . $clauza_where;
		}
		//echo $sql;die;
		$stid = oci_parse($this -> conn, $sql);
		oci_execute($stid);
		$row = oci_fetch_object($stid);
		return $row->COUNT;
		//return json_encode($result);
	}
}
?>