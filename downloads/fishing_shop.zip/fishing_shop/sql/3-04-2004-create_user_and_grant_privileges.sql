CREATE USER fishing_shop IDENTIFIED BY password;
  GRANT CONNECT TO fishing_shop;
  GRANT ALL PRIVILEGES TO fishing_shop;
  DROP TABLE CATEGORIE CASCADE CONSTRAINTS;
  DROP TABLE PRODUCATOR CASCADE CONSTRAINTS;
  DROP TABLE PRODUS CASCADE CONSTRAINTS;
  DROP TABLE PRODUS_COMANDA CASCADE CONSTRAINTS;
  DROP TABLE UTILIZATOR CASCADE CONSTRAINTS;
  DROP TABLE RECENZIE CASCADE CONSTRAINTS;
  DROP TABLE STATUS_COMANDA CASCADE CONSTRAINTS;
  DROP TABLE COMANDA CASCADE CONSTRAINTS;
  DROP TABLE PERMISIUNE CASCADE CONSTRAINTS;
  DROP TABLE ROL CASCADE CONSTRAINTS;
  DROP TABLE ROL_PERMISIUNE CASCADE CONSTRAINTS;
  DROP TABLE CLIENT CASCADE CONSTRAINTS;
  DROP TABLE STOC CASCADE CONSTRAINTS;
  DROP TABLE ORAS CASCADE CONSTRAINTS;
  DROP TABLE TARA CASCADE CONSTRAINTS;
  DROP TABLE ERORI CASCADE CONSTRAINTS;
  DROP SEQUENCE categorie_produs_seq;
  DROP SEQUENCE producator_seq;
  DROP SEQUENCE produs_seq;
  DROP SEQUENCE imagine_produs_seq;
  DROP SEQUENCE status_comanda_seq;
  DROP SEQUENCE utilizator_seq;
  DROP SEQUENCE recenzie_seq;
  DROP SEQUENCE comanda_seq;
  DROP SEQUENCE produse_comanda_seq;
  DROP SEQUENCE oras_seq;
  DROP SEQUENCE tara_seq;
  --Creaza tabelul pentru erori
  CREATE TABLE eroare
    (
      cod  VARCHAR2(50) NOT NULL,
      text VARCHAR2(500) NOT NULL,
      CONSTRAINT eroare_pk PRIMARY KEY (cod)
    );
  --Creaza tabelul pentru categoriile de produse
  CREATE TABLE categorie
    (
      id_categorie         NUMBER(3),
      id_categorie_parinte NUMBER(3),
      nume                 VARCHAR2(100) NOT NULL,
      descriere            VARCHAR2(50) NOT NULL,
      CONSTRAINT categorie_pk PRIMARY KEY (id_categorie)
    );
  --Creaza tabelul cu producatori
  CREATE TABLE producator
    (
      id_producator NUMBER(3),
      nume          VARCHAR2(50) NOT NULL,
      descriere     VARCHAR2(50) NOT NULL,
      CONSTRAINT producator_pk PRIMARY KEY (id_producator)
    );
  --Creaza tabelul cu produse
  CREATE TABLE produs
    (
      id_produs           NUMBER(10),
      id_categorie        NUMBER(3),
      id_producator       NUMBER(3),
      nume                VARCHAR2(100) NOT NULL,
      imagine             VARCHAR2(100) NOT NULL,
      descriere           VARCHAR2(1000) NOT NULL,
      specificatii        VARCHAR2(1000) NOT NULL,
      pret_de_vanzare     NUMBER(19,4) NOT NULL,
      pret_lichidare_stoc NUMBER(19,4) NOT NULL,
      activ               NUMBER(1) DEFAULT 1,
      CONSTRAINT produs_pk PRIMARY KEY (id_produs),
      CONSTRAINT fk_categorie FOREIGN KEY (id_categorie) REFERENCES categorie(id_categorie),
      CONSTRAINT fk_producator FOREIGN KEY (id_producator) REFERENCES producator(id_producator)
    );
  --Creaza tabelul cu promotii
  CREATE TABLE promotie
    (
      id_promotie      NUMBER(10),
      id_produs        NUMBER(10),
      procent_discount NUMBER(19,4) NOT NULL,
      data_inceput     DATE,
      data_sfarsit     DATE,
      activ            NUMBER(1) DEFAULT 1,
      CONSTRAINT promotie_pk PRIMARY KEY (id_promotie),
      CONSTRAINT fk_promotie_produs FOREIGN KEY (id_produs) REFERENCES produs(id_produs)
    );
  --Creaza tabelul cu stocuri pentru produse
  CREATE TABLE stoc
    (
      id_produs         NUMBER(10),
      pret_de_achizitie NUMBER(19,4) NOT NULL,
      cantitate         NUMBER(3) NOT NULL,
      CONSTRAINT stoc_pk PRIMARY KEY (id_produs),
      CONSTRAINT fk_stoc_produs FOREIGN KEY (id_produs) REFERENCES produs(id_produs)
    );
  CREATE TABLE date_calcul_pret
    (
      tva                  NUMBER(19,4) NOT NULL,
      adaos                NUMBER(19,4) NOT NULL,
      adaos_lichidare_stoc NUMBER(19,4) NOT NULL
    );
  --Creaza tabelul cu roluri pentru utilizatori
  CREATE TABLE rol
    (
      id_rol    NUMBER(10),
      nume      VARCHAR2(50) NOT NULL,
      descriere VARCHAR2(50) NOT NULL,
      CONSTRAINT rol_pk PRIMARY KEY (id_rol)
    );
  --Creaza tabelul cu permisiuni pentru fiecare rol
  CREATE TABLE permisiune
    (
      id_permisiune NUMBER(10),
      nume          VARCHAR2(50) NOT NULL,
      descriere     VARCHAR2(50) NOT NULL,
      CONSTRAINT permisiune_pk PRIMARY KEY (id_permisiune)
    );
  --Creaza tabelul de legatura intre roluri si permisiuni
  CREATE TABLE rol_permisiune
    (
      id_rol        NUMBER(10),
      id_permisiune NUMBER(10),
      CONSTRAINT rol_permisiune_pk PRIMARY KEY (id_rol, id_permisiune),
      CONSTRAINT fk_rol_permisiune_rol FOREIGN KEY (id_rol) REFERENCES rol(id_rol),
      CONSTRAINT fk_rol_permisiune_perm FOREIGN KEY (id_permisiune) REFERENCES permisiune(id_permisiune)
    );
  --Creaza tabelul pentru tari
  CREATE TABLE tara
    (
      id_tara NUMBER(10),
      nume    VARCHAR2(100) NOT NULL,
      CONSTRAINT tara_pk PRIMARY KEY (id_tara)
    );
  --Creaza tabelul pentru orase
  CREATE TABLE oras
    (
      id_oras NUMBER(10),
      nume    VARCHAR2(100) NOT NULL,
      id_tara NUMBER(10),
      CONSTRAINT oras_pk PRIMARY KEY (id_oras),
      CONSTRAINT fk_tara FOREIGN KEY (id_tara) REFERENCES tara(id_tara)
    );
  --Creaza tabelul pentru utilizatori
  CREATE TABLE utilizator
    (
      id_utilizator      NUMBER(10),
      id_rol             NUMBER(10),
      email              VARCHAR2(50) NOT NULL,
      parola             VARCHAR2(100) NOT NULL,
      activ              NUMBER(1) DEFAULT 1,
      data_inregistrare  DATE DEFAULT SYSDATE,
      data_ultima_logare DATE,
      CONSTRAINT utilizator_pk PRIMARY KEY (id_utilizator),
      CONSTRAINT fk_rol FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
    );
  --Creaza tabelul pentru clienti
  CREATE TABLE client
    (
      id_utilizator NUMBER(10),
      nume          VARCHAR2(50) NOT NULL,
      prenume       VARCHAR2(50) NOT NULL,
      poza          VARCHAR2(50),
      telefon       VARCHAR2(50) NOT NULL,
      adresa        VARCHAR2(200) NOT NULL,
      id_oras       NUMBER(10),
      cod_postal    VARCHAR2(100) NOT NULL,
      CONSTRAINT client_pk PRIMARY KEY (id_utilizator),
      CONSTRAINT fk_client_utilizator FOREIGN KEY (id_utilizator) REFERENCES utilizator(id_utilizator),
      CONSTRAINT fk_oras FOREIGN KEY (id_oras) REFERENCES oras(id_oras)
    );
  --Creaza tabelul cu recenzii
  CREATE TABLE recenzie
    (
      id_recenzie         NUMBER(10),
      id_recenzie_parinte NUMBER(10),
      id_produs           NUMBER(10),
      id_utilizator       NUMBER(10),
      continut            VARCHAR2(1000) NOT NULL,
      data_postarii       DATE DEFAULT SYSDATE,
      CONSTRAINT recenzie_pk PRIMARY KEY (id_recenzie),
      CONSTRAINT fk_rec_produs FOREIGN KEY (id_produs) REFERENCES produs(id_produs),
      CONSTRAINT fk_rec_utilizator FOREIGN KEY (id_utilizator) REFERENCES utilizator(id_utilizator)
    );
  --Creaza tabelul cu statusuri pentru comenzi
  CREATE TABLE status_comanda
    (
      id_status_comanda NUMBER(3),
      status            VARCHAR2(50) NOT NULL,
      CONSTRAINT status_comanda_pk PRIMARY KEY (id_status_comanda)
    );
  --Creaza tabelul pentru comenzi
  CREATE TABLE comanda
    (
      id_comanda                NUMBER(10),
      id_utilizator             NUMBER(10),
      id_status_comanda         NUMBER(3),
      valoare_totala            NUMBER(19,4) NOT NULL,
      data_comanda_inregistrata DATE DEFAULT SYSDATE,
      data_comanda_finalizata   DATE,
      CONSTRAINT comanda_pk PRIMARY KEY (id_comanda),
      CONSTRAINT fk_com_utilizator FOREIGN KEY (id_utilizator) REFERENCES utilizator(id_utilizator),
      CONSTRAINT fk_com_status_comanda FOREIGN KEY (id_status_comanda) REFERENCES status_comanda(id_status_comanda),
      CONSTRAINT com_inreg_fin CHECK (data_comanda_inregistrata < data_comanda_finalizata)
    );
  --Creaza tabelul cu produse comandate
  CREATE TABLE produs_comanda
    (
      id_comanda     NUMBER(10),
      id_produs      NUMBER(10),
      pret_vanzare   NUMBER(19,4) NOT NULL,
      cantitate      NUMBER(10) NOT NULL,
      lichidare_stoc NUMBER(1),
      id_promotie    NUMBER(1),
      CONSTRAINT produs_comanda_pk PRIMARY KEY (id_comanda, id_produs),
      CONSTRAINT fk_prod_com_produs FOREIGN KEY (id_produs) REFERENCES produs(id_produs),
      CONSTRAINT fk_prod_com_comanda FOREIGN KEY (id_comanda) REFERENCES comanda(id_comanda),
      CONSTRAINT fk_prod_com_promotie FOREIGN KEY (id_promotie) REFERENCES promotie(id_promotie)
    );
CREATE OR REPLACE VIEW DETALII_PRODUS
AS
  SELECT PRODUS.ID_PRODUS,
    PRODUS.ID_CATEGORIE,
    CATEGORIE.ID_CATEGORIE_PARINTE,
    PRODUS.NUME,
    PRODUS.IMAGINE,
    PRODUS.DESCRIERE,
    PRODUS.SPECIFICATII,
    PRODUCATOR.DESCRIERE AS PRODUCATOR,
    STOC.PRET_DE_ACHIZITIE,
    PRODUS.PRET_DE_VANZARE,
    STOC.PRET_DE_ACHIZITIE + STOC.PRET_DE_ACHIZITIE * PROMOTIE.PROCENT_DISCOUNT / 100 AS PRET_DE_VANZARE_PROMOTIE,
    PRODUS.PRET_LICHIDARE_STOC,
    STOC.CANTITATE,
    PROMOTIE.ACTIV                                         AS PROMOTIE,
    PROMOTIE.ID_PROMOTIE,
    PROMOTIE.PROCENT_DISCOUNT                              AS PROMOTIE_PROCENT_DISCOUNT,
    STOC.PRET_DE_ACHIZITIE * PROMOTIE.PROCENT_DISCOUNT/100 AS PROMOTIE_VALOARE_DISCOUNT,
    PROMOTIE.DATA_INCEPUT                                  AS PROMOTIE_DATA_INCEPUT,
    PROMOTIE.DATA_SFARSIT                                  AS PROMOTIE_DATA_SFARSIT
  FROM PRODUS
  INNER JOIN CATEGORIE
  ON PRODUS.ID_CATEGORIE=CATEGORIE.ID_CATEGORIE
  INNER JOIN PRODUCATOR
  ON PRODUS.ID_PRODUCATOR=PRODUCATOR.ID_PRODUCATOR
  INNER JOIN STOC
  ON PRODUS.ID_PRODUS=STOC.ID_PRODUS
  LEFT JOIN PROMOTIE
  ON PRODUS.ID_PRODUS=PROMOTIE.ID_PRODUS
  WHERE PRODUS.ACTIV =1;
CREATE OR REPLACE VIEW DETALII_UTILIZATOR
AS
  SELECT UTILIZATOR.ID_UTILIZATOR,
    UTILIZATOR.EMAIL,
    UTILIZATOR.PAROLA,
    CLIENT.POZA,
    CLIENT.NUME,
    CLIENT.PRENUME,
    CLIENT.TELEFON,
    CLIENT.ADRESA,
    ORAS.NUME AS ORAS,
    TARA.NUME AS TARA,
    CLIENT.COD_POSTAL,
    ROL.NUME AS ROL
  FROM UTILIZATOR
  INNER JOIN CLIENT
  ON UTILIZATOR.ID_UTILIZATOR = CLIENT.ID_UTILIZATOR
  INNER JOIN ROL
  ON UTILIZATOR.ID_ROL = ROL.ID_ROL
  INNER JOIN ORAS
  ON CLIENT.ID_ORAS=ORAS.ID_ORAS
  INNER JOIN TARA
  ON ORAS.ID_TARA       =TARA.ID_TARA
  WHERE UTILIZATOR.ACTIV=1;
CREATE OR REPLACE VIEW ROLURI_PERMISIUNI
                    AS
  SELECT ROL.NUME   AS ROL,
    PERMISIUNE.NUME AS PERMISIUNE
  FROM PERMISIUNE
  JOIN ROL_PERMISIUNE
  ON PERMISIUNE.ID_PERMISIUNE = ROL_PERMISIUNE.ID_PERMISIUNE
  JOIN ROL
  ON ROL_PERMISIUNE.ID_ROL = ROL.ID_ROL;
CREATE OR REPLACE VIEW RECENZII_PRODUS
AS
  SELECT RECENZIE.ID_RECENZIE,
    RECENZIE.ID_RECENZIE_PARINTE,
    RECENZIE.ID_PRODUS,
    RECENZIE.ID_UTILIZATOR,
    PRODUS.NUME AS PRODUS,
    RECENZIE.CONTINUT,
    RECENZIE.DATA_POSTARII,
    CLIENT.POZA,
    CLIENT.NUME,
    CLIENT.PRENUME
  FROM RECENZIE
  INNER JOIN PRODUS
  ON RECENZIE.ID_PRODUS = PRODUS.ID_PRODUS
  INNER JOIN UTILIZATOR
  ON RECENZIE.ID_UTILIZATOR = UTILIZATOR.ID_UTILIZATOR
  INNER JOIN CLIENT
  ON UTILIZATOR.ID_UTILIZATOR = CLIENT.ID_UTILIZATOR;
CREATE OR REPLACE VIEW PROMOTII
AS
  SELECT PROMOTIE.ID_PROMOTIE,
    PRODUS.ID_PRODUS,
    PRODUS.NUME AS PRODUS,
    PROMOTIE.PROCENT_DISCOUNT,
    PROMOTIE.DATA_INCEPUT,
    PROMOTIE.DATA_SFARSIT
  FROM PRODUS
  RIGHT JOIN PROMOTIE
  ON PRODUS.ID_PRODUS=PROMOTIE.ID_PRODUS
  WHERE PRODUS.ACTIV =1
  AND PROMOTIE.ACTIV =1;
CREATE OR REPLACE VIEW COMENZI
AS
  SELECT COMANDA.ID_COMANDA,
    COMANDA.ID_UTILIZATOR,
    COMANDA.VALOARE_TOTALA,
    COMANDA.DATA_COMANDA_INREGISTRATA,
    COMANDA.DATA_COMANDA_FINALIZATA,
    STATUS_COMANDA.STATUS
  FROM COMANDA
  INNER JOIN STATUS_COMANDA
  ON COMANDA.ID_STATUS_COMANDA=STATUS_COMANDA.ID_STATUS_COMANDA;
CREATE OR REPLACE VIEW PRODUSE_COMANDATE
AS
  SELECT PRODUS.NUME,
    PRODUS.DESCRIERE,
    PRODUS_COMANDA.PRET_VANZARE,
    PRODUS_COMANDA.CANTITATE,
    PRODUS_COMANDA.ID_COMANDA
  FROM PRODUS_COMANDA
  INNER JOIN PRODUS
  ON PRODUS_COMANDA.ID_PRODUS=PRODUS.ID_PRODUS;
CREATE SEQUENCE categorie_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE client_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE comanda_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE permisiune_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE producator_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE produs_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE produs_comanda_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE recenzie_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE rol_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE stoc_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE utilizator_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE oras_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE tara_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE promotie_seq MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE OR REPLACE TRIGGER producator_tr BEFORE
  INSERT ON producator FOR EACH ROW WHEN (new.ID_PRODUCATOR IS NULL) BEGIN
  SELECT PRODUCATOR_SEQ.NEXTVAL INTO :new.ID_PRODUCATOR FROM dual;
END;
CREATE OR REPLACE TRIGGER tara_tr BEFORE
  INSERT ON tara FOR EACH ROW WHEN (new.ID_TARA IS NULL) BEGIN
  SELECT TARA_SEQ.NEXTVAL INTO :new.ID_TARA FROM dual;
END;
CREATE OR REPLACE TRIGGER recenzie_tr BEFORE
  INSERT ON recenzie FOR EACH ROW WHEN (new.ID_RECENZIE IS NULL) BEGIN
  SELECT RECENZIE_SEQ.NEXTVAL INTO :new.ID_RECENZIE FROM dual;
END;
CREATE OR REPLACE TRIGGER permisiune_tr BEFORE
  INSERT ON permisiune FOR EACH ROW WHEN (new.ID_PERMISIUNE IS NULL) BEGIN
  SELECT PERMISIUNE_SEQ.NEXTVAL INTO :new.ID_PERMISIUNE FROM dual;
END;
CREATE OR REPLACE TRIGGER rol_tr BEFORE
  INSERT ON rol FOR EACH ROW WHEN (new.ID_ROL IS NULL) BEGIN
  SELECT ROL_SEQ.NEXTVAL INTO :new.ID_ROL FROM dual;
END;
CREATE OR REPLACE TRIGGER categorie_tr BEFORE
  INSERT ON categorie FOR EACH ROW WHEN (new.ID_CATEGORIE IS NULL) BEGIN
  SELECT CATEGORIE_SEQ.NEXTVAL INTO :new.ID_CATEGORIE FROM dual;
END;
CREATE OR REPLACE TRIGGER promotie_tr BEFORE
  INSERT ON promotie FOR EACH ROW WHEN (new.ID_PROMOTIE IS NULL) BEGIN
  SELECT PROMOTIE_SEQ.NEXTVAL INTO :new.ID_PROMOTIE FROM dual;
END;
/*
CREATE OR REPLACE TRIGGER utilizator_tr
BEFORE INSERT ON utilizator
FOR EACH ROW
WHEN (new.ID_UTILIZATOR IS NULL)
BEGIN
SELECT UTILIZATOR_SEQ.NEXTVAL
INTO   :new.ID_UTILIZATOR
FROM   dual;
END;
CREATE OR REPLACE TRIGGER client_tr
BEFORE INSERT ON client
FOR EACH ROW
WHEN (new.ID_UTILIZATOR IS NULL)
BEGIN
SELECT UTILIZATOR_SEQ.CURRVAL
INTO   :new.ID_UTILIZATOR
FROM   dual;
END;
*/
CREATE OR REPLACE TRIGGER produs_tr BEFORE
  INSERT ON produs FOR EACH ROW WHEN (new.ID_PRODUS IS NULL) BEGIN
  SELECT PRODUS_SEQ.CURRVAL INTO :new.ID_PRODUS FROM dual;
END;
SET define OFF;
CREATE OR REPLACE TRIGGER EMAIL_VALID_TR BEFORE
  INSERT ON utilizator FOR EACH ROW DECLARE output NUMBER := 1;
  ncount NUMBER;
BEGIN
  /*
  IF :new.EMAIL NOT LIKE '%_@_%.__%' THEN
  erori.obtine_text_eroare('INVALID_EMAIL');
  END IF;*/
  SELECT COUNT(u.EMAIL)
  INTO ncount
  FROM UTILIZATOR u
  WHERE :new.EMAIL = u.EMAIL;
  IF ncount        > 0 THEN
    output        := -1;
    erori.obtine_text_eroare('DUPLICATE_EMAIL');
  ELSE
    actiuni.valideaza_email(:new.EMAIL, output);
    IF output = -1 THEN
      erori.obtine_text_eroare('INVALID_EMAIL');
    END IF;
  END IF;
END;
CREATE OR REPLACE PACKAGE erori
AS
  PROCEDURE obtine_text_eroare(
      cod_eroare VARCHAR2);
END erori;
CREATE OR REPLACE PACKAGE BODY erori
AS
PROCEDURE obtine_text_eroare(
    cod_eroare VARCHAR2)
IS
BEGIN
  FOR r IN
  (SELECT text FROM eroare WHERE cod = cod_eroare
  )
  LOOP
    raise_application_error(-20001, r.text);
  END LOOP;
  raise_application_error(-20001, 'Nu gasesc textul mesajului de eroare cu codul ''' || cod_eroare || ''' ! Contacteaza administratorul.');
END;
END erori;
CREATE OR REPLACE PACKAGE actiuni
AS
  PROCEDURE insereaza_utilizator(
      nume       IN VARCHAR2,
      prenume    IN VARCHAR2,
      email      IN VARCHAR2,
      parola     IN VARCHAR2,
      telefon    IN VARCHAR2,
      adresa     IN VARCHAR2,
      id_oras    IN NUMBER,
      cod_postal IN VARCHAR2,
      id_rol     IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE editeaza_utilizator(
      pid_utilizator IN NUMBER,
      pnume          IN VARCHAR2,
      pprenume       IN VARCHAR2,
      pemail         IN VARCHAR2,
      ptelefon       IN VARCHAR2,
      padresa        IN VARCHAR2,
      pid_oras       IN NUMBER,
      pcod_postal    IN VARCHAR2,
      pid_rol        IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE sterge_utilizator(
      pid_utilizator IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE insereaza_produs(
      pnume              IN VARCHAR2,
      pimagine           IN VARCHAR2,
      pdescriere         IN VARCHAR2,
      pspecificatii      IN VARCHAR2,
      ppret_de_achizitie IN NUMBER,
      pcantitate         IN NUMBER,
      pid_categorie      IN NUMBER,
      pid_producator     IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE editeaza_produs(
      pprodus_id         IN NUMBER,
      pnume              IN VARCHAR2,
      pdescriere         IN VARCHAR2,
      pspecificatii      IN VARCHAR2,
      ppret_de_achizitie IN NUMBER,
      pcantitate         IN NUMBER,
      pid_categorie      IN NUMBER,
      pid_producator     IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE sterge_produs(
      pid_produs IN NUMBER,
      status_out OUT NUMBER);
  PROCEDURE valideaza_email(
      email IN VARCHAR2,
      status_out OUT NUMBER);
  PROCEDURE valideaza_nume(
      nume IN VARCHAR2,
      status_out OUT NUMBER);
  PROCEDURE insereaza_comanda(
      putilizator IN NUMBER,
      pstatus_comanda IN NUMBER,
      pvaloare_totala IN NUMBER,
      id_out     OUT NUMBER,
      status_out OUT NUMBER);
END actiuni;
CREATE OR REPLACE PACKAGE BODY actiuni
AS
PROCEDURE insereaza_utilizator(
    nume       IN VARCHAR2,
    prenume    IN VARCHAR2,
    email      IN VARCHAR2,
    parola     IN VARCHAR2,
    telefon    IN VARCHAR2,
    adresa     IN VARCHAR2,
    id_oras    IN NUMBER,
    cod_postal IN VARCHAR2,
    id_rol     IN NUMBER,
    status_out OUT NUMBER)
IS
  utilizator_id NUMBER(10);
BEGIN
  /* Default status to success */
  status_out := 1;
  ACTIUNI.VALIDEAZA_NUME(nume, status_out);
  ACTIUNI.VALIDEAZA_NUME(prenume, status_out);
  SELECT UTILIZATOR_SEQ.NEXTVAL INTO utilizator_id FROM dual;
  INSERT
  INTO UTILIZATOR
    (
      ID_UTILIZATOR,
      EMAIL,
      PAROLA,
      ID_ROL
    )
    VALUES
    (
      utilizator_id,
      email,
      parola,
      id_rol
    );
  INSERT
  INTO CLIENT
    (
      ID_UTILIZATOR,
      NUME,
      PRENUME,
      TELEFON,
      ADRESA,
      ID_ORAS,
      COD_POSTAL
    )
    VALUES
    (
      utilizator_id,
      nume,
      prenume,
      telefon,
      adresa,
      id_oras,
      cod_postal
    );
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE editeaza_utilizator
  (
    pid_utilizator IN NUMBER,
    pnume          IN VARCHAR2,
    pprenume       IN VARCHAR2,
    pemail         IN VARCHAR2,
    ptelefon       IN VARCHAR2,
    padresa        IN VARCHAR2,
    pid_oras       IN NUMBER,
    pcod_postal    IN VARCHAR2,
    pid_rol        IN NUMBER,
    status_out OUT NUMBER
  )
IS
BEGIN
  /* Default status to success */
  status_out := 1;
  /*ACTIUNI.VALIDEAZA_NUME(nume, status_out);
  ACTIUNI.VALIDEAZA_NUME(prenume, status_out);*/
  UPDATE UTILIZATOR
  SET EMAIL           = pemail,
    ID_ROL            = pid_rol
  WHERE ID_UTILIZATOR = pid_utilizator;
  UPDATE CLIENT
  SET NUME            = pnume,
    PRENUME           = pprenume,
    TELEFON           = ptelefon,
    ADRESA            = padresa,
    ID_ORAS           = pid_oras,
    COD_POSTAL        = pcod_postal
  WHERE ID_UTILIZATOR = pid_utilizator;
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE sterge_utilizator(
    pid_utilizator IN NUMBER,
    status_out OUT NUMBER)
IS
BEGIN
  /* Default status to success */
  status_out := 1;
  UPDATE UTILIZATOR SET ACTIV = 0 WHERE ID_UTILIZATOR = pid_utilizator;
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE insereaza_produs(
    pnume              IN VARCHAR2,
    pimagine           IN VARCHAR2,
    pdescriere         IN VARCHAR2,
    pspecificatii      IN VARCHAR2,
    ppret_de_achizitie IN NUMBER,
    pcantitate         IN NUMBER,
    pid_categorie      IN NUMBER,
    pid_producator     IN NUMBER,
    status_out OUT NUMBER)
IS
  produs_id                 NUMBER(10);
  pret_de_vanzare           NUMBER(19,4);
  pret_de_vanzare_lichidare NUMBER(19,4);
  tva                       NUMBER(19,4);
  adaos                     NUMBER(19,4);
  adaos_lichidare           NUMBER(19,4);
BEGIN
  /* Default status to success */
  status_out := 1;
  SELECT TVA,
    ADAOS,
    ADAOS_LICHIDARE_STOC
  INTO tva,
    adaos,
    adaos_lichidare
  FROM DATE_CALCUL_PRET;
  pret_de_vanzare           := ppret_de_achizitie + ppret_de_achizitie * tva/100 + ppret_de_achizitie * adaos/100;
  pret_de_vanzare_lichidare := ppret_de_achizitie + ppret_de_achizitie * tva/100 + ppret_de_achizitie * adaos_lichidare/100;
  SELECT PRODUS_SEQ.NEXTVAL INTO produs_id FROM dual;
  INSERT
  INTO PRODUS
    (
      ID_PRODUS,
      ID_CATEGORIE,
      ID_PRODUCATOR,
      NUME,
      IMAGINE,
      DESCRIERE,
      SPECIFICATII,
      PRET_DE_VANZARE,
      PRET_LICHIDARE_STOC
    )
    VALUES
    (
      produs_id,
      pid_categorie,
      pid_producator,
      pnume,
      pimagine,
      pdescriere,
      pspecificatii,
      pret_de_vanzare,
      pret_de_vanzare_lichidare
    );
  INSERT
  INTO STOC
    (
      ID_PRODUS,
      PRET_DE_ACHIZITIE,
      CANTITATE
    )
    VALUES
    (
      produs_id,
      ppret_de_achizitie,
      pcantitate
    );
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE editeaza_produs
  (
    pprodus_id         IN NUMBER,
    pnume              IN VARCHAR2,
    pdescriere         IN VARCHAR2,
    pspecificatii      IN VARCHAR2,
    ppret_de_achizitie IN NUMBER,
    pcantitate         IN NUMBER,
    pid_categorie      IN NUMBER,
    pid_producator     IN NUMBER,
    status_out OUT NUMBER
  )
IS
  pret_de_vanzare           NUMBER(19,4);
  pret_de_vanzare_lichidare NUMBER(19,4);
  tva                       NUMBER(19,4);
  adaos                     NUMBER(19,4);
  adaos_lichidare           NUMBER(19,4);
BEGIN
  /* Default status to success */
  status_out := 1;
  SELECT TVA,
    ADAOS,
    ADAOS_LICHIDARE_STOC
  INTO tva,
    adaos,
    adaos_lichidare
  FROM DATE_CALCUL_PRET;
  pret_de_vanzare           := ppret_de_achizitie + ppret_de_achizitie * tva/100 + ppret_de_achizitie * adaos/100;
  pret_de_vanzare_lichidare := ppret_de_achizitie + ppret_de_achizitie * tva/100 + ppret_de_achizitie * adaos_lichidare/100;
  UPDATE PRODUS
  SET ID_CATEGORIE      = pid_categorie,
    ID_PRODUCATOR       = pid_producator,
    NUME                = pnume,
    DESCRIERE           = pdescriere,
    SPECIFICATII        = pspecificatii,
    PRET_DE_VANZARE     = pret_de_vanzare,
    PRET_LICHIDARE_STOC = pret_de_vanzare_lichidare
  WHERE ID_PRODUS       = pprodus_id;
  UPDATE STOC
  SET PRET_DE_ACHIZITIE = ppret_de_achizitie,
    CANTITATE           = pcantitate
  WHERE ID_PRODUS       = pprodus_id;
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE sterge_produs(
    pid_produs IN NUMBER,
    status_out OUT NUMBER)
IS
BEGIN
  /* Default status to success */
  status_out := 1;
  UPDATE PRODUS SET ACTIV = 0 WHERE ID_PRODUS = pid_produs;
EXCEPTION
WHEN OTHERS THEN
  status_out := -1;
END;
PROCEDURE valideaza_email(
    email IN VARCHAR2,
    status_out OUT NUMBER)
IS
BEGIN
  IF regexp_like(email,'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$','i') THEN
    status_out := 1;
  ELSE
    status_out := -1;
  END IF;
END;
PROCEDURE valideaza_nume(
    nume IN VARCHAR2,
    status_out OUT NUMBER)
IS
BEGIN
  IF regexp_like(nume,'^[A-Za-z[:blank:]-]+$','i') THEN
    status_out := 1;
  ELSE
    erori.obtine_text_eroare('INVALID_CHAR');
    status_out := -1;
  END IF;
END;
PROCEDURE insereaza_comanda(
      putilizator IN NUMBER,
      pstatus_comanda IN NUMBER,
      pvaloare_totala IN NUMBER,
      id_out     OUT NUMBER,
      status_out OUT NUMBER)
IS
BEGIN
  /* Default status to success */
  status_out := 1;
  SELECT COMANDA_SEQ.NEXTVAL INTO id_out FROM dual;
  INSERT
  INTO COMANDA
    (
      ID_COMANDA,
      ID_UTILIZATOR,
      ID_STATUS_COMANDA,
      VALOARE_TOTALA
    )
    VALUES
    (
      id_out,
      putilizator,
      pstatus_comanda,
      pvaloare_totala
    );
  EXCEPTION
  WHEN OTHERS THEN
    status_out := -1;
END;
END actiuni;
INSERT ALL
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Afghanistan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Albania'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Algeria'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Andorra'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Angola'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Antigua and Barbuda'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Argentina'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Armenia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Australia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Austria'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Azerbaijan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bahamas, The'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bahrain'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bangladesh'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Barbados'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Belarus'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Belgium'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Belize'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Benin'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bhutan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bolivia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bosnia and Herzegovina'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Botswana'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Brazil'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Brunei'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Bulgaria'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Burkina Faso'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Burma'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Burundi'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cambodia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cameroon'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Canada'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cape Verde'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Central Africa'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Chad'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Chile'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'China'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Colombia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Comoros'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Congo, Democratic Republic of the'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Costa Rica'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cote dIvoire'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Crete'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Croatia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cuba'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Cyprus'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Czech Republic'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Denmark'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Djibouti'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Dominican Republic'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'East Timor'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ecuador'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Egypt'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'El Salvador'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Equatorial Guinea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Eritrea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Estonia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ethiopia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Fiji'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Finland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'France'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Gabon'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Gambia, The'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Georgia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Germany'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ghana'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Greece'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Grenada'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Guadeloupe'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Guatemala'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Guinea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Guinea-Bissau'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Guyana'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Haiti'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Holy See'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Honduras'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Hong Kong'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Hungary'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Iceland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'India'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Indonesia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Iran'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Iraq'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ireland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Israel'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Italy'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ivory Coast'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Jamaica'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Japan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Jordan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kazakhstan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kenya'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kiribati'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Korea, North'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Korea, South'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kosovo'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kuwait'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Kyrgyzstan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Laos'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Latvia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Lebanon'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Lesotho'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Liberia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Libya'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Liechtenstein'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Lithuania'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Macau'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Macedonia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Madagascar'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Malawi'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Malaysia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Maldives'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mali'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Malta'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Marshall Islands'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mauritania'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mauritius'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mexico'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Micronesia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Moldova'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Monaco'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mongolia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Montenegro'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Morocco'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Mozambique'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Namibia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Nauru'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Nepal'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Netherlands'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'New Zealand'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Nicaragua'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Niger'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Nigeria'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'North Korea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Norway'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Oman'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Pakistan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Palau'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Panama'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Papua New Guinea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Paraguay'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Peru'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Philippines'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Poland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Portugal'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Qatar'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Romania'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Russia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Rwanda'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Saint Lucia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Saint Vincent and the Grenadines'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Samoa'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'San Marino'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Sao Tome and Principe'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Saudi Arabia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Scotland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Senegal'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Serbia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Seychelles'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Sierra Leone'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Singapore'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Slovakia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Slovenia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Solomon Islands'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Somalia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'South Africa'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'South Korea'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Spain'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Sri Lanka'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Sudan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Suriname'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Swaziland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Sweden'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Switzerland'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Syria'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Taiwan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tajikistan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tanzania'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Thailand'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tibet'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Timor-Leste'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Togo'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tonga'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Trinidad and Tobago'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tunisia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Turkey'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Turkmenistan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Tuvalu'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Uganda'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Ukraine'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'United Arab Emirates'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'United Kingdom'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'United States'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Uruguay'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Uzbekistan'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Vanuatu'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Venezuela'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Vietnam'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Yemen'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Zambia'
  )
INTO TARA
  (
    NUME
  )
  VALUES
  (
    'Zimbabwe'
  )
SELECT * FROM dual;