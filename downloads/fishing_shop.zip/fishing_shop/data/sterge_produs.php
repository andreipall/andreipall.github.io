<?php
session_start();
//session_destroy();
$produs["id_produs"] = $_POST["id"];
if(isset($_SESSION["produse"])) {
	foreach($_SESSION["produse"] as $key => $value) {
		//echo "Key: $key; Value:".$value["id_produs"]."<br />\n";
		if($value["id_produs"]==$produs["id_produs"]) {
			$_SESSION["nr_total_produse"] = $_SESSION["nr_total_produse"] - $value["cantitate"];
			unset($_SESSION["produse"][$key]);
			$_SESSION["success_msg"] = 'Produsul a fost sters din cos!';
		}
	}
}
//var_dump($_SESSION["produse"]);die;
?>