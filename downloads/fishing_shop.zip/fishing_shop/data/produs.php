<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
		$allowedExts = array("gif", "jpeg", "jpg", "png");
		$temp = explode(".", $_FILES["imagine"]["name"]);
		$extension = end($temp);

		if ((($_FILES["imagine"]["type"] == "image/gif")
		|| ($_FILES["imagine"]["type"] == "image/jpeg")
		|| ($_FILES["imagine"]["type"] == "image/jpg")
		|| ($_FILES["imagine"]["type"] == "image/pjpeg")
		|| ($_FILES["imagine"]["type"] == "image/x-png")
		|| ($_FILES["imagine"]["type"] == "image/png"))
		&& in_array($extension, $allowedExts)) {
			$target_path = SRV_PATH."img/imagini_produse/";

			$target_path = $target_path . basename( $_FILES['imagine']['name']); 

			if(move_uploaded_file($_FILES['imagine']['tmp_name'], $target_path)) {

				$mesaj = $crud->run_stored_proc("actiuni.insereaza_produs('".strip_tags(addslashes(trim($_POST["nume"])))."','".basename($_FILES['imagine']['name'])."','".strip_tags(addslashes(trim($_POST["descriere"])))."','".strip_tags(addslashes(trim($_POST["specificatii"])))."','".strip_tags(trim($_POST["pret_achizitie"]))."','".strip_tags(trim($_POST["cantitate"]))."','".strip_tags(trim($_POST["categorie"]))."','".strip_tags(trim($_POST["producator"]))."', :output);");

				if($mesaj["tip"]=="succes") {
					$_SESSION["success_msg"] = 'Produsul a fost adaugat cu succes!';
				}
				elseif($mesaj["tip"]=="eroare"){
					$_SESSION["error_msg"] = 'Eroare la adaugarea produsului!';
				}
			} else{
				$_SESSION["error_msg"] = 'Eroare la adaugarea produsului! Problema la uploadarea imaginii cu produsul!';
			}
		}
		else {
			$_SESSION["error_msg"] = 'Problema la uploadarea imaginii cu produsul! Fisier invalid!';
		}
        header("location: ../views/admin/adauga_produs.php");
        break;
    case "edit":
		$mesaj = $crud->run_stored_proc("actiuni.editeaza_produs('".strip_tags(trim($_POST["id"]))."','".strip_tags(addslashes(trim($_POST["nume"])))."','".strip_tags(addslashes(trim($_POST["descriere"])))."','".strip_tags(addslashes(trim($_POST["specificatii"])))."','".strip_tags(trim($_POST["pret_achizitie"]))."','".strip_tags(trim($_POST["cantitate"]))."','".strip_tags(trim($_POST["categorie"]))."','".strip_tags(trim($_POST["producator"]))."', :output);");

		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = 'Produsul a fost editat cu succes!';
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = 'Eroare la editarea produsului!';
		}
        break;
    case "delete":
        $mesaj = $crud->run_stored_proc("actiuni.sterge_produs('".strip_tags(trim($_POST["id"]))."', :output);");

		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = 'Produsul a fost sters cu succes!';
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = 'Eroare la stergerea produsului!';
		}
        break;
		default:
			  header("location: ../index.php");
			  
}
?>