<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
	    $mesaj = $crud->insert("promotie", array("ID_PRODUS", "PROCENT_DISCOUNT", "DATA_INCEPUT", "DATA_SFARSIT"), array($_POST["produs"], $_POST["discount"], $_POST["data_inceput"], $_POST["data_sfarsit"]));
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Promotia a fost adaugata cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la adaugarea promotiei!";
		}
        break;
    case "edit":
        $mesaj = $crud->update("promotie", array("ID_PRODUS" => $_POST["produs"], "PROCENT_DISCOUNT" => $_POST["discount"], "DATA_INCEPUT" => $_POST["data_inceput"], "DATA_SFARSIT" => $_POST["data_sfarsit"]), "ID_PROMOTIE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Promotia a fost editata cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la editarea promotiei!";
		}
        break;
    case "delete":
        $mesaj = $crud->delete("promotie", "ID_PROMOTIE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Promotia a fost stearsa cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la stergerea promotiei!";
		}
        break;
	default:
		header("location: ../index.php");
			  
}
?>