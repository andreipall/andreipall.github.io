<?php
session_start();
//session_destroy();
$produs["id_produs"] = $_POST["product_id"];
$produs["id_promotie"] = $_POST["promotion_id"];
$produs["lichidare_stoc"] = $_POST["selloff"];
$produs["cantitate"] = $_POST["quantity"];
$_SESSION["nr_total_produse"] += $produs["cantitate"];

if(isset($_SESSION["produse"])) {
	$in_cos = false;
	foreach($_SESSION["produse"] as &$produs_cos) {
		if($produs_cos["id_produs"]==$produs["id_produs"]) {
			$produs_cos["cantitate"] += $produs["cantitate"];
			$in_cos = true;
		}
	}
	if($in_cos == false) {
		$_SESSION["produse"][] = $produs;
	}
}
else {
	$_SESSION["produse"][] = $produs;
}
$_SESSION["success_msg"] = 'Produsul a fost adaugat in cos!';
?>