<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "login":
	$users = $crud->select(array("ID_UTILIZATOR","EMAIL","PAROLA","NUME","PRENUME","ROL"), array("DETALII_UTILIZATOR"), "EMAIL = '".strip_tags(trim($_POST["email"]))."'");

	if(count($users)==1) {
		$users = $users[0];
		$password = strip_tags(trim($_POST["parola"])); 
		$aes256Key = hash("SHA256", $password, false);

		if($aes256Key == $users->PAROLA) {
			$_SESSION["utilizator"]["user_id"] = $users->ID_UTILIZATOR;
			$_SESSION["utilizator"]["nume"] = $users->NUME;
			$_SESSION["utilizator"]["prenume"] = $users->PRENUME;
			$permissions = $crud->select(array("PERMISIUNE"), array("ROLURI_PERMISIUNI"), "ROL = '".$users->ROL."'");
			foreach($permissions as $permission) {
				$_SESSION["utilizator"]["permisiuni"][] = $permission->PERMISIUNE;
			}
			if(isset($_SESSION["login_redirect"])) {
				header("location: ".$_SESSION["login_redirect"]);
			}
			else {
				header("location: ../index.php");
			}
		}
		else {
			$_SESSION["error_msg"] = "Parola incorecta!";
			header("location: ../views/autentificare.php");
		}
	}
	else {
		$_SESSION["error_msg"] = "Email sau parola incorecta!";
		header("location: ../views/autentificare.php");
	}	
	break;
	case "change":
		if($_POST["parola"] == $_POST["confirma_parola"]) {
			//var_dump($_POST);die;
			$password = strip_tags(trim($_POST["parola"])); 
			$aes256Key = hash("SHA256", $password, false);
			$mesaj = $crud->update("UTILIZATOR", array("PAROLA" => $aes256Key), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]);
		}
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = 'Datele au fost modificate cu succes!';
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = 'Eroare la editarea datelor!';
		}
		header("location: ../views/setari_siguranta.php");
	break;
}
?>