<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
	    $mesaj = $crud->insert("rol_permisiune", array("ID_ROL", "ID_PERMISIUNE"), array($_POST["id_rol"], $_POST["id_permisiune"]));
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = $mesaj["mesaj"];
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = $mesaj["mesaj"];
		}
        //header("location: ../index.php");
		return json_encode($result);
        break;
    case "delete":
        $crud->delete("rol_permisiune", "ID_ROL = ".$_POST["id_rol"]."AND ID_PERMISIUNE = ".$_POST["id_permisiune"]);
        break;
	default:
		header("location: ../index.php");
			  
}
?>