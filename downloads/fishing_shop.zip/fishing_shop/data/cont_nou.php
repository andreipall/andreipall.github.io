<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
		if($_POST["parola"] == $_POST["confirma_parola"] && strlen(trim($_POST["parola"])) >= 6) {	
			$rol = $crud->select(array("ID_ROL"), array("ROL"), "NUME = 'Client'");

			/*
			DECLARE
			output number;
			BEGIN
			  actiuni.insereaza_utilizator('nume','prenume','email@email.com','parola','telefon','adresa','1','12345','1', output);
			  DBMS_OUTPUT.PUT_LINE (output);
			END;*/
			$password = strip_tags(trim($_POST["parola"])); 
			$aes256Key = hash("SHA256", $password, false);
			//$aes256Key = str_replace("'", "''", $aes256Key);
			//echo "actiuni.insereaza_utilizator('".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["email"]."','".$aes256Key."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["oras"]."','".$_POST["cod_postal"]."','".$rol[0]->ID_ROL."', :output);";die;
			$mesaj = $crud->run_stored_proc("actiuni.insereaza_utilizator('".strip_tags(trim($_POST["nume"]))."','".strip_tags(trim($_POST["prenume"]))."','".strip_tags(trim($_POST["email"]))."','".$aes256Key."','".strip_tags(trim($_POST["telefon"]))."','".strip_tags(trim($_POST["adresa"]))."','".strip_tags(trim($_POST["oras"]))."','".strip_tags(trim($_POST["cod_postal"]))."','".$rol[0]->ID_ROL."', :output);");

			if($mesaj["tip"]=="succes") {
				$_SESSION["success_msg"] = 'Utilizatorul a fost adaugat cu succes!';
			}
			elseif($mesaj["tip"]=="eroare"){
				$_SESSION["error_msg"] = 'Eroare la adaugarea utilizatorului!';
			}
		}
		else {
			$_SESSION["error_msg"] = "Parola si confirma parola trebuie sa fie identice.";
		}
        header("location: ../views/cont_nou.php");
        break;
    case "edit":
		//var_dump($_FILES);die;
		if(empty($_FILES['picture']['name'])) {
			$mesaj = $crud->update("CLIENT", array("NUME" => strip_tags(trim($_POST["nume"])),"PRENUME" => strip_tags(trim($_POST["prenume"])),"TELEFON" => strip_tags(trim($_POST["telefon"])),"ADRESA" => strip_tags(trim($_POST["adresa"])),"ID_ORAS" => strip_tags(trim($_POST["oras"])),"COD_POSTAL" => strip_tags(trim($_POST["cod_postal"]))), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]);
			if($mesaj["tip"]=="succes") {
				$_SESSION["success_msg"] = 'Datele au fost modificate cu succes!';
			}
			elseif($mesaj["tip"]=="eroare"){
				$_SESSION["error_msg"] = 'Eroare la editarea datelor!';
			}
		}
		else {
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			$temp = explode(".", $_FILES["picture"]["name"]);
			$extension = end($temp);

			if ((($_FILES["picture"]["type"] == "image/gif")
			|| ($_FILES["picture"]["type"] == "image/jpeg")
			|| ($_FILES["picture"]["type"] == "image/jpg")
			|| ($_FILES["picture"]["type"] == "image/pjpeg")
			|| ($_FILES["picture"]["type"] == "image/x-png")
			|| ($_FILES["picture"]["type"] == "image/png"))
			&& in_array($extension, $allowedExts)) {
				$target_path = SRV_PATH."img/poze/";

				$target_path = $target_path . basename( $_FILES['picture']['name']);
				
				if(move_uploaded_file($_FILES['picture']['tmp_name'], $target_path)) {
					$mesaj = $crud->update("CLIENT", array("NUME" => strip_tags(trim($_POST["nume"])),"PRENUME" => strip_tags(trim($_POST["prenume"])),"TELEFON" => strip_tags(trim($_POST["telefon"])),"ADRESA" => strip_tags(trim($_POST["adresa"])),"ID_ORAS" => strip_tags(trim($_POST["oras"])),"COD_POSTAL" => strip_tags(trim($_POST["cod_postal"])), "POZA" => basename($_FILES['picture']['name'])), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]);
					if($mesaj["tip"]=="succes") {
						$_SESSION["success_msg"] = 'Datele au fost modificate cu succes!';
					}
					elseif($mesaj["tip"]=="eroare"){
						$_SESSION["error_msg"] = 'Eroare la editarea datelor!';
					}
				} else{
					$_SESSION["error_msg"] = 'Eroare la editarea datelor! Problema la uploadarea imaginii!';
				}
			}
			else {
				$_SESSION["error_msg"] = 'Problema la uploadarea imaginii! Fisier invalid!';
			}
		}
		
		header("location: ../views/date_personale.php");
        break;
	default:
		header("location: ../index.php");
			  
}
?>