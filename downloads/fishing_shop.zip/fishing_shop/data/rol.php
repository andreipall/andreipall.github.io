<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
			  $mesaj = $crud->insert("rol", array("NUME", "DESCRIERE"), array($_POST["nume"], $_POST["descriere"]));
				if($mesaj["tip"]=="succes") {
					$_SESSION["success_msg"] = 'Rolul a fost adaugat cu succes!';
				}
				elseif($mesaj["tip"]=="eroare"){
					$_SESSION["error_msg"] = 'Eroare la adaugarea rolului!';
				}
        break;
    case "edit":
        $mesaj = $crud->update("rol", array("NUME" => $_POST["nume"], "DESCRIERE" => $_POST["descriere"]), "ID_ROL = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Rolul a fost editat cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la editarea rolului!";
		}
        break;
    case "delete":
        $mesaj = $crud->delete("rol", "ID_ROL = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Rolul a fost sters cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la stergerea rolului!";
		}
        break;
	default:
		header("location: ../index.php");
			  
}
?>