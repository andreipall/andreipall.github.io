<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
	    $mesaj = $crud->insert("categorie", array("NUME", "DESCRIERE", "ID_CATEGORIE_PARINTE"), array($_POST["nume"], $_POST["descriere"], $_POST["categorie_parinte"]));
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Categoria a fost adaugata cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la adaugarea categoriei!";
		}
        break;
    case "edit":
        $mesaj = $crud->update("categorie", array("NUME" => $_POST["nume"], "DESCRIERE" => $_POST["descriere"], "ID_CATEGORIE_PARINTE" => $_POST["categorie_parinte"]), "ID_CATEGORIE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Categoria a fost editata cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la editarea categoriei!";
		}
        break;
    case "delete":
        $mesaj = $crud->delete("categorie", "ID_CATEGORIE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Categoria a fost stearsa cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la stergerea categoriei!";
		}
        break;
	default:
		header("location: ../index.php");
			  
}
?>