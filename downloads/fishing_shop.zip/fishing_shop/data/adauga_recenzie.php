<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$product_id = strip_tags(trim($_POST["product_id"]));
$parent_review_id = strip_tags(trim($_POST["parent_review_id"]));
$review = strip_tags(trim($_POST["review"]));
$user_id = $_SESSION["utilizator"]["user_id"];

$crud = new Crud();

$mesaj = $crud->insert("recenzie", array("ID_PRODUS", "ID_UTILIZATOR", "CONTINUT", "ID_RECENZIE_PARINTE"), array($product_id, $user_id, $review, $parent_review_id));
if($mesaj["tip"]=="succes") {
	$_SESSION["success_msg"] = "Recenzia a fost adaugata cu succes!";
}
elseif($mesaj["tip"]=="eroare"){
	$_SESSION["error_msg"] = "Eroare la adaugarea recenziei!";
}

?>


