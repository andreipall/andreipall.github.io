<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$status = $_POST["status"];
$comanda = $_POST["order"];

$crud = new Crud();

if($status == 5) {
	$mesaj = $crud->update("COMANDA", array("ID_STATUS_COMANDA" => $status, "DATA_COMANDA_FINALIZATA" => date("d-m-Y")), "ID_COMANDA = ".$comanda);
}
else {
	$mesaj = $crud->update("COMANDA", array("ID_STATUS_COMANDA" => $status), "ID_COMANDA = ".$comanda);
}
if($mesaj["tip"]=="succes") {
	$_SESSION["success_msg"] = "Statusul comenzii a fost modificat cu succes!";
}
elseif($mesaj["tip"]=="eroare"){
	$_SESSION["error_msg"] = "Eroare la schimbarea statusului!";
}

?>


