<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$email = $_POST["email"];
$crud = new Crud();
$users = $crud->count("UTILIZATOR", "EMAIL = '".$email."'");

if($users > 0) {

	$password = uniqid(); 
	$aes256Key = hash("SHA256", $password, false);
	$mesaj = $crud->update("UTILIZATOR", array("PAROLA" => $aes256Key), "EMAIL = '".$email."'");

	mail($email,"Fishing Shop - Recuperare parola","Noua parola cu care va puteti autentifica este: ".$password);
	
	if($mesaj["tip"]=="succes") {
		$_SESSION["success_msg"] = 'Noua parola a fost trimisa cu succes!';
	}
	elseif($mesaj["tip"]=="eroare"){
		$_SESSION["error_msg"] = 'Eroare la schimbarea parolei!';
	}
}
else {
	$_SESSION["error_msg"] = "Adresa de email nu exista in baza de date!";
}
header("location: ../views/am_uitat_parola.php");

?>