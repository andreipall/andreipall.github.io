<?php
require_once SRV_PATH.'classes/crud.php';


function success_msg() {
	if(!empty($_SESSION["success_msg"])){
		echo '<div class="alert alert-success alert-dismissable">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$_SESSION["success_msg"].
			 '</div>';
		
		unset($_SESSION["success_msg"]);
	}
}

function error_msg() {
	if(!empty($_SESSION["error_msg"])){
		echo '<div class="alert alert-danger alert-dismissable">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$_SESSION["error_msg"].
			 '</div>';
		unset($_SESSION["error_msg"]);
	}
}

function warning_msg() {
	if(!empty($_SESSION["warning_msg"])){
		echo '<div class="alert alert-warning alert-dismissable">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$_SESSION["warning_msg"].
			 '</div>';
		unset($_SESSION["warning_msg"]);
	}
}

function select_country($selected_country) {
    $crud = new Crud();
    $countries = $crud->select(array("ID_TARA","NUME"), array("TARA"), false);
	echo '<select name="tara" id="country" class="form-control">';
	foreach($countries as $country) {
		if($country->NUME == $selected_country) {
			echo '<option value="'.$country->ID_TARA.'" selected>'.$country->NUME.'</option>';
		}
		else {
			echo '<option value="'.$country->ID_TARA.'">'.$country->NUME.'</option>';
		}
	}
	echo '</select>';
}

function select_order_status($selected_status) {
    $crud = new Crud();
    $statuses = $crud->select(array("ID_STATUS_COMANDA","STATUS"), array("STATUS_COMANDA"), false);
	echo '<select name="status" id="status" class="form-control">';
	foreach($statuses as $status) {
		if($status->ID_STATUS_COMANDA == $selected_status) {
			echo '<option value="'.$status->ID_STATUS_COMANDA.'" selected>'.$status->STATUS.'</option>';
		}
		else {
			echo '<option value="'.$status->ID_STATUS_COMANDA.'">'.$status->STATUS.'</option>';
		}
	}
	echo '</select>';
}

function select_city($selected_city) {
    $crud = new Crud();
    $cities = $crud->select(array("ID_ORAS","NUME"), array("ORAS"), false);
	echo '<select name="oras" id="city" class="form-control">';
	foreach($cities as $city) {
		if($city->NUME == $selected_city) {
			echo '<option value="'.$city->ID_ORAS.'" selected>'.$city->NUME.'</option>';
		}
		else {
			echo '<option value="'.$city->ID_ORAS.'">'.$city->NUME.'</option>';
		}
	}
	echo '</select>';
}

function select_role($selected_role) {
    $crud = new Crud();
    $roles = $crud->select(array("ID_ROL","NUME"), array("ROL"), false);
	echo '<select name="rol" id="role" class="form-control">';
	foreach($roles as $role) {
		if($role->NUME == $selected_role) {
			echo '<option value="'.$role->ID_ROL.'" selected>'.$role->NUME.'</option>';
		}
		else {
			echo '<option value="'.$role->ID_ROL.'">'.$role->NUME.'</option>';
		}
	}
	echo '</select>';
}

function select_producer($selected_producer) {
    $crud = new Crud();
    $producers = $crud->select(array("ID_PRODUCATOR","DESCRIERE"), array("PRODUCATOR"), false);
	echo '<select name="producator" id="producer" class="form-control">';
	foreach($producers as $producer) {
		if($producer->DESCRIERE == $selected_producer) {
			echo '<option value="'.$producer->ID_PRODUCATOR.'" selected>'.$producer->DESCRIERE.'</option>';
		}
		else {
			echo '<option value="'.$producer->ID_PRODUCATOR.'">'.$producer->DESCRIERE.'</option>';
		}
	}
	echo '</select>';
}

function select_parent_category($parent_category) {
    $crud = new Crud();
    $categories = $crud->select(array("ID_CATEGORIE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE IS NULL");
	echo '<select name="categorie" id="parent_category" class="form-control">';
	foreach($categories as $category) {
		echo '<optgroup label="'.$category->DESCRIERE.'">'.$category->DESCRIERE.'</optgroup>';
		$categories = $crud->select(array("ID_CATEGORIE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$category->ID_CATEGORIE);
		foreach($categories as $category) {
			if($category->ID_CATEGORIE == $parent_category) {
				echo '<option value="'.$category->ID_CATEGORIE.'" selected>'.$category->DESCRIERE.'</option>';
			}
			else {
				echo '<option value="'.$category->ID_CATEGORIE.'">'.$category->DESCRIERE.'</option>';
			}
		}
	}
	echo '</select>';
}

function select_category($selected_category) {
    $crud = new Crud();
    $categories = $crud->select(array("ID_CATEGORIE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE IS NULL");
	echo '<select name="categorie" id="category" class="form-control">';
	foreach($categories as $category) {
		echo '<optgroup label="'.$category->DESCRIERE.'">'.$category->DESCRIERE.'</optgroup>';
		$categories = $crud->select(array("ID_CATEGORIE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$category->ID_CATEGORIE);
		foreach($categories as $category) {
			if($category->ID_CATEGORIE == $selected_category) {
				echo '<option value="'.$category->ID_CATEGORIE.'" selected>'.$category->DESCRIERE.'</option>';
			}
			else {
				echo '<option value="'.$category->ID_CATEGORIE.'">'.$category->DESCRIERE.'</option>';
			}
			$categories = $crud->select(array("ID_CATEGORIE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$category->ID_CATEGORIE);
			foreach($categories as $category) {
				if($category->ID_CATEGORIE == $selected_category) {
					echo '<option value="'.$category->ID_CATEGORIE.'" selected> - '.$category->DESCRIERE.'</option>';
				}
				else {
					echo '<option value="'.$category->ID_CATEGORIE.'"> - '.$category->DESCRIERE.'</option>';
				}
			}
		}
	}
	echo '</select>';
}

function select_product($selected_product) {
    $crud = new Crud();
    $products = $crud->select(array("ID_PRODUS", "NUME"), array("DETALII_PRODUS"), false);
	echo '<select name="produs" id="product" class="form-control">';
	foreach($products as $product) {
		if($product->ID_PRODUS == $selected_product) {
			echo '<option value="'.$product->ID_PRODUS.'" selected>'.$product->NUME.'</option>';
		}
		else {
			echo '<option value="'.$product->ID_PRODUS.'">'.$product->NUME.'</option>';
		}
	}
	echo '</select>';
}

function list_products() {
    $crud = new Crud();
    $products = $crud->select(array("ID_PRODUS","NUME", "DESCRIERE"), array("DETALII_PRODUS"), false);
	
	foreach($products as $product) {
		echo '<tr>';
		echo '<td>'.$product->NUME.'</td>';
		echo '<td>'.substr($product->DESCRIERE, 0, 120).'...</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/produs_modal_edit.php?product_id='.$product->ID_PRODUS.'" data-toggle="modal" data-target="#editProduct"><span class="glyphicon glyphicon-edit"></span></a></td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/produs_modal_delete.php?product_id='.$product->ID_PRODUS.'" data-toggle="modal" data-target="#deleteProduct"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function list_promotions() {
    $crud = new Crud();
    $promotions= $crud->select(array("ID_PROMOTIE","ID_PRODUS","PRODUS", "PROCENT_DISCOUNT", "DATA_INCEPUT", "DATA_SFARSIT"), array("PROMOTII"), false);
	
	foreach($promotions as $promotion) {
		echo '<tr>';
		echo '<td>'.$promotion->PRODUS.'</td>';
		echo '<td>'.$promotion->DATA_INCEPUT.' - '.$promotion->DATA_SFARSIT.'</td>';
		echo '<td>'.$promotion->PROCENT_DISCOUNT.'%</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/promotie_modal_edit.php?promotion_id='.$promotion->ID_PROMOTIE.'" data-toggle="modal" data-target="#editPromotion"><span class="glyphicon glyphicon-edit"></span></a></td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/promotie_modal_delete.php?promotion_id='.$promotion->ID_PROMOTIE.'" data-toggle="modal" data-target="#deletePromotion"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function list_reviews() {
    $crud = new Crud();
    $reviews= $crud->select(array("ID_RECENZIE","PRODUS","CONTINUT","DATA_POSTARII", "POZA", "NUME", "PRENUME"), array("RECENZII_PRODUS"), false);
	
	foreach($reviews as $review) {
		echo '<tr>';
		echo '<td>'.$review->CONTINUT.'</td>';
		echo '<td>'.$review->PRODUS.'</td>';
		echo '<td>'.$review->DATA_POSTARII.'</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/recenzie_modal_delete.php?review_id='.$review->ID_RECENZIE.'" data-toggle="modal" data-target="#deleteReview"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function list_orders($user_id) {
    $crud = new Crud();
	if($user_id == false) {
		$orders= $crud->select(array("ID_COMANDA","VALOARE_TOTALA", "DATA_COMANDA_INREGISTRATA", "STATUS"), array("COMENZI"), false);
	}
	else {
		$orders= $crud->select(array("ID_COMANDA","VALOARE_TOTALA", "DATA_COMANDA_INREGISTRATA", "STATUS"), array("COMENZI"), "ID_UTILIZATOR = ".$user_id);
	}
	if(!empty($orders)) {
		foreach($orders as $order) {
			echo '<tr>';
			echo '<td><a href="'.HOME_PATH.'views/comanda.php?order_id='.$order->ID_COMANDA.'">'.$order->ID_COMANDA.'</a></td>';
			echo '<td>'.$order->DATA_COMANDA_INREGISTRATA.'</td>';
			echo '<td>'.$order->VALOARE_TOTALA.' RON</td>';
			echo '<td>'.$order->STATUS.'</td>';
			echo '</tr>';
		}
	}
	else {
		echo '<tr>';
		echo '<td>Nu aveti nici o comanda.</td>';
		echo '</tr>';
	}
}

function list_all_orders() {
    $crud = new Crud();
	$orders= $crud->select(array("ID_COMANDA","VALOARE_TOTALA", "DATA_COMANDA_INREGISTRATA", "DATA_COMANDA_FINALIZATA", "STATUS"), array("COMENZI"), false);
	foreach($orders as $order) {
		echo '<tr>';
		echo '<td><a href="'.HOME_PATH.'views/admin/comanda.php?order_id='.$order->ID_COMANDA.'">'.$order->ID_COMANDA.'</a></td>';
		echo '<td>'.$order->DATA_COMANDA_INREGISTRATA.' - '.$order->DATA_COMANDA_FINALIZATA.'</td>';
		echo '<td>'.$order->VALOARE_TOTALA.' RON</td>';
		echo '<td>'.$order->STATUS.'</td>';
		echo '</tr>';
	}
}

function list_order_products($order_id) {
    $crud = new Crud();
    $products= $crud->select(array("NUME","DESCRIERE", "CANTITATE", "ID_COMANDA", "PRET_VANZARE"), array("PRODUSE_COMANDATE"), "ID_COMANDA = ".$order_id);
	
	foreach($products as $product) {
		echo '<tr>';
		echo '<td>'.$product->NUME.'</td>';
		echo '<td>'.$product->DESCRIERE.'</td>';
		echo '<td>'.$product->CANTITATE.'</td>';
		echo '<td>'.$product->PRET_VANZARE.' RON</td>';
		echo '</tr>';
	}
}

function list_permissions() {
    $crud = new Crud();
    $permissions = $crud->select(array("ID_PERMISIUNE","NUME", "DESCRIERE"), array("PERMISIUNE"), false);
	
	foreach($permissions as $permission) {
		echo '<tr>';
		echo '<td>'.$permission->NUME.'</td>';
		echo '<td>'.$permission->DESCRIERE.'</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/permisiune_modal_edit.php?permission_id='.$permission->ID_PERMISIUNE.'" data-toggle="modal" data-target="#editPermission"><span class="glyphicon glyphicon-edit"></span></a></td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/permisiune_modal_delete.php?permission_id='.$permission->ID_PERMISIUNE.'" data-toggle="modal" data-target="#deletePermission"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function list_roles() {
    $crud = new Crud();
    $roles = $crud->select(array("ID_ROL","NUME", "DESCRIERE"), array("ROL"), false);
	
	foreach($roles as $role) {
		echo '<tr>';
		echo '<td>'.$role->NUME.'</td>';
		echo '<td>'.$role->DESCRIERE.'</td>';
		if($role->NUME == 'Client' || $role->NUME == 'Admin') {
			echo '<td>-</td>';
			echo '<td>-</td>';
		}
		else {
			echo '<td><a href="'.HOME_PATH.'views/admin/modals/rol_modal_edit.php?role_id='.$role->ID_ROL.'" data-toggle="modal" data-target="#editRole"><span class="glyphicon glyphicon-edit"></span></a></td>';
			echo '<td><a href="'.HOME_PATH.'views/admin/modals/rol_modal_delete.php?role_id='.$role->ID_ROL.'" data-toggle="modal" data-target="#deleteRole"><span class="glyphicon glyphicon-remove"></span></a></td>';
		}
		echo '</tr>';
	}
}

function list_users() {
    $crud = new Crud();
    $users = $crud->select(array("ID_UTILIZATOR","NUME", "PRENUME", "ROL"), array("DETALII_UTILIZATOR"), false);
	
	foreach($users as $user) {
		echo '<tr>';
		echo '<td>'.$user->NUME." ".$user->PRENUME.'</td>';
		echo '<td>'.$user->ROL.'</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/utilizator_modal_edit.php?user_id='.$user->ID_UTILIZATOR.'" data-toggle="modal" data-target="#editUser"><span class="glyphicon glyphicon-edit"></span></a></td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/utilizator_modal_delete.php?user_id='.$user->ID_UTILIZATOR.'" data-toggle="modal" data-target="#deleteUser"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function list_categories() {
    $crud = new Crud();
    $categories = $crud->select(array("ID_CATEGORIE", "ID_CATEGORIE_PARINTE","NUME", "DESCRIERE"), array("CATEGORIE"), false);
	
	foreach($categories as $category) {
		echo '<tr>';
		echo '<td>'.$category->NUME.'</td>';
		echo '<td>'.$category->DESCRIERE.'</td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/categorie_modal_edit.php?category_id='.$category->ID_CATEGORIE.'" data-toggle="modal" data-target="#editCategory"><span class="glyphicon glyphicon-edit"></span></a></td>';
		echo '<td><a href="'.HOME_PATH.'views/admin/modals/categorie_modal_delete.php?category_id='.$category->ID_CATEGORIE.'" data-toggle="modal" data-target="#deleteCategory"><span class="glyphicon glyphicon-remove"></span></a></td>';
		echo '</tr>';
	}
}

function th_roles() {
    $crud = new Crud();
    $roles = $crud->select(array("ID_ROL","NUME"), array("ROL"), false);
	
	foreach($roles as $role) {
		echo '<th>'.$role->NUME.'</th>';
	}
}

function tr_permissions() {
    $crud = new Crud();
	$roles = $crud->select(array("ID_ROL","NUME"), array("ROL"), false);
    $permissions = $crud->select(array("ID_PERMISIUNE","NUME"), array("PERMISIUNE"), false);
	$roles_permissions = $crud->select(array("ID_ROL","ID_PERMISIUNE"), array("ROL_PERMISIUNE"), false);
	
	$assigned_permissions = array();
	foreach($roles_permissions as $roles_permission) {
		$assigned_permissions[] = $roles_permission->ID_ROL."_".$roles_permission->ID_PERMISIUNE;
	}
	
	foreach($permissions as $permission) {
		echo '<tr>';
		echo '<td>'.$permission->NUME.'</td>';

		foreach($roles as $role) {
			$checkbox_id = $role->ID_ROL.'_'.$permission->ID_PERMISIUNE;
			if(in_array($checkbox_id, $assigned_permissions)) {
				echo '<td><input type="checkbox" id="'.$role->ID_ROL.'_'.$permission->ID_PERMISIUNE.'" class="role-permission" checked></td>';
			}
			else {
				echo '<td><input type="checkbox" id="'.$role->ID_ROL.'_'.$permission->ID_PERMISIUNE.'" class="role-permission"></td>';
			}
		}
		echo '</tr>';
	}
}

function get_parent_categories($parent_category) {
	$crud = new Crud();
	$parent_categories = array();
	$parent_category_id = $parent_category;
	while ($parent_category_id != NULL) {
		$categories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE = ".$parent_category_id);
		foreach($categories as $category) {
			$parent_category_id = $category->ID_CATEGORIE_PARINTE;
			$parent_categories[$category->ID_CATEGORIE] = $category->NUME;
			//var_dump($parent_category_id == NULL);
		}
	}
	ksort($parent_categories);
	return $parent_categories;
}
?>