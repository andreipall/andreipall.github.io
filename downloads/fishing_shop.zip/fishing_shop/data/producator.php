<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
			  $mesaj = $crud->insert("producator", array("NUME", "DESCRIERE"), array($_POST["producator"], $_POST["descriere"]));
				if($mesaj["tip"]=="succes") {
					$_SESSION["success_msg"] = $mesaj["mesaj"];
				}
				elseif($mesaj["tip"]=="eroare"){
					$_SESSION["error_msg"] = $mesaj["mesaj"];
				}
        header("location: ../index.php");
        break;
    case 1:
        echo "edit";
        break;
    case 2:
        echo "delete";
        break;
		default:
			  header("location: ../index.php");
			  
}
?>