<?php
session_start();

include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
			  $mesaj = $crud->insert("permisiune", array("NUME", "DESCRIERE"), array($_POST["nume"], $_POST["descriere"]));
				if($mesaj["tip"]=="succes") {
					$_SESSION["success_msg"] = 'Permisiunea a fost adaugata cu succes!';
				}
				elseif($mesaj["tip"]=="eroare"){
					$_SESSION["error_msg"] = 'Eroare la adaugarea permisiunii!';
				}
        //header("location: ../index.php");
		return json_encode($result);
        break;
    case "edit":
        $mesaj = $crud->update("permisiune", array("NUME" => $_POST["nume"], "DESCRIERE" => $_POST["descriere"]), "ID_PERMISIUNE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Permisiunea a fost editata cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la editarea permisiunii!";
		}
        break;
    case "delete":
        $mesaj = $crud->delete("permisiune", "ID_PERMISIUNE = ".$_POST["id"]);
		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = "Permisiunea a fost stearsa cu succes!";
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = "Eroare la stergerea permisiunii!";
		}
        break;
	default:
		header("location: ../index.php");
			  
}
?>