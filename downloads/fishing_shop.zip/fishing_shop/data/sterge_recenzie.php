<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
$mesaj = $crud->delete("recenzie", "ID_RECENZIE = ".strip_tags(trim($_POST["id"])));
if($mesaj["tip"]=="succes") {
	$_SESSION["success_msg"] = "Recenzia a fost stearsa cu succes!";
}
elseif($mesaj["tip"]=="eroare"){
	$_SESSION["error_msg"] = "Eroare la stergerea recenziei!";
}
?>