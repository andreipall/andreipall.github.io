<?php
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';
session_start();
//session_destroy();
if(empty($_SESSION["utilizator"]["user_id"])) {
	$_SESSION["warning_msg"] = 'Trebuie sa fiti autentificat pentru a putea trimite comanda!';
	$_SESSION["login_redirect"] = HOME_PATH.'views/cos_cumparaturi.php';
	header("location: ../views/autentificare.php");
}
else {
	if(isset($_SESSION["produse"])) {
		//var_dump($_SESSION["produse"]);
		$cost_total = 0;
		$crud = new Crud();
		$status_comanda = $crud->select(array("ID_STATUS_COMANDA"), array("STATUS_COMANDA"), "STATUS = 'Comanda inregistrata'");
		$status_comanda = $status_comanda[0];
		//var_dump($status_comanda);die;
		
		$mesaj = $crud->run_stored_proc_ins("actiuni.insereaza_comanda('".$_SESSION["utilizator"]["user_id"]."','".$status_comanda->ID_STATUS_COMANDA."','".$_SESSION["cost_total"]."', :id, :output);");
		//var_dump($mesaj);die;
		if($mesaj["tip"]=="succes") {
				
			foreach($_SESSION["produse"] as $produs_cos) {
				
				if($produs_cos["lichidare_stoc"] == "true") {
					$command = $crud->insert("PRODUS_COMANDA", array("ID_COMANDA", "ID_PRODUS", "CANTITATE", "PRET_VANZARE", "LICHIDARE_STOC"), array($mesaj["id"], $produs_cos["id_produs"], $produs_cos["cantitate"], $produs_cos["pret_vanzare"], 1));
				}
				elseif($produs_cos["id_promotie"] > 0) {
					$command = $crud->insert("PRODUS_COMANDA", array("ID_COMANDA", "ID_PRODUS", "CANTITATE", "PRET_VANZARE", "ID_PROMOTIE"), array($mesaj["id"], $produs_cos["id_produs"], $produs_cos["cantitate"], $produs_cos["pret_vanzare"], $produs_cos["id_promotie"]));
				}
				else {
					$command = $crud->insert("PRODUS_COMANDA", array("ID_COMANDA", "ID_PRODUS", "CANTITATE", "PRET_VANZARE"), array($mesaj["id"], $produs_cos["id_produs"], $produs_cos["cantitate"], $produs_cos["pret_vanzare"]));
				}
			}
		}
		unset($_SESSION["nr_total_produse"]);
		unset($_SESSION["produse"]);
		unset($_SESSION["cost_total"]);
		$_SESSION["success_msg"] = 'Comanda a fost trimisa!';
	}
	else {
		$_SESSION["error_msg"] = 'Nu exista nici un produs in cosul cu cumparaturi!';
	}
	header("location: ".HOME_PATH.'views/cos_cumparaturi.php');
}
?>