<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
switch ($_POST["action"]) {
    case "add":
		if($_POST["parola"] == $_POST["confirma_parola"] && strlen($_POST["parola"]) > 6) {	
			$password = $_POST["parola"]; 
			$aes256Key = hash("SHA256", $password, false);
			//$aes256Key = str_replace("'", "''", $aes256Key);
			//echo "actiuni.insereaza_utilizator('".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["email"]."','".$aes256Key."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["oras"]."','".$_POST["cod_postal"]."','".$rol[0]->ID_ROL."', :output);";die;
			$mesaj = $crud->run_stored_proc("actiuni.insereaza_utilizator('".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["email"]."','".$aes256Key."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["oras"]."','".$_POST["cod_postal"]."','".$_POST["rol"]."', :output);");

			if($mesaj["tip"]=="succes") {
				$_SESSION["success_msg"] = 'Utilizatorul a fost adaugat cu succes!';
			}
			elseif($mesaj["tip"]=="eroare"){
				$_SESSION["error_msg"] = 'Eroare la adaugarea utilizatorului!';
			}
		}
		else {
			$_SESSION["error_msg"] = "Parola si confirma parola trebuie sa fie identice.";
		}
        //header("location: ../views/admin/utilizator.php");
        break;
    case "edit":

		//echo "actiuni.editeaza_utilizator('".$_POST["id"]."','".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["email"]."','".$aes256Key."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["oras"]."','".$_POST["cod_postal"]."','".$_POST["rol"]."', :output);";die;
		$mesaj = $crud->run_stored_proc("actiuni.editeaza_utilizator('".$_POST["id"]."','".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["email"]."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["oras"]."','".$_POST["cod_postal"]."','".$_POST["rol"]."', :output);");

		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = 'Utilizatorul a fost editat cu succes!';
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = 'Eroare la editarea utilizatorului!';
		}
        break;
    case "delete":
        $mesaj = $crud->run_stored_proc("actiuni.sterge_utilizator('".$_POST["id"]."', :output);");

		if($mesaj["tip"]=="succes") {
			$_SESSION["success_msg"] = 'Utilizatorul a fost sters cu succes!';
		}
		elseif($mesaj["tip"]=="eroare"){
			$_SESSION["error_msg"] = 'Eroare la stergerea utilizatorului!';
		}
        break;
	default:
		header("location: ../index.php");
			  
}
?>