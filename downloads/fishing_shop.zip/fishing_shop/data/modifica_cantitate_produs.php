<?php
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
require_once SRV_PATH.'classes/crud.php';
header('Content-Type: application/json');
session_start();
//session_destroy();
$produs["id_produs"] = $_POST["product_id"];
$produs["cantitate"] = $_POST["quantity"];
$_SESSION["nr_total_produse"] = 0;
$cost_total = 0;

$crud = new Crud();

if(isset($_SESSION["produse"])) {
	foreach($_SESSION["produse"] as &$produs_cos) {
		$product = $crud->select(array("ID_PRODUS","ID_PROMOTIE","NUME","CANTITATE","PRET_DE_VANZARE","PRET_LICHIDARE_STOC","PRET_DE_VANZARE_PROMOTIE"), array("DETALII_PRODUS"), "ID_PRODUS = ".$produs_cos["id_produs"]);
		$product = $product[0];
		
		if($produs_cos["id_produs"]==$produs["id_produs"]) {
			$produs_cos["cantitate"] = $produs["cantitate"];
		}
		$_SESSION["nr_total_produse"] += $produs_cos["cantitate"];
		if($produs_cos["lichidare_stoc"] == "true") {
			$cost_total += $produs_cos["cantitate"] * $product->PRET_LICHIDARE_STOC;
		}
		elseif($produs_cos["id_promotie"] > 0) {
			$cost_total += $produs_cos["cantitate"] * $product->PRET_DE_VANZARE_PROMOTIE;
		}
		else {
			$cost_total += $produs_cos["cantitate"] * $product->PRET_DE_VANZARE;
		}
	}
}
$_SESSION["cost_total"] = $cost_total;
$arr = array('nr_total_produse' => $_SESSION["nr_total_produse"], 'cost_total' => $cost_total);
echo json_encode($arr);

?>


