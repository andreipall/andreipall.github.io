<?php 
//include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
//include SRV_PATH."views/header.php";
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/views/acasa.php";  
//include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/views/category.php"; 
//include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/views/autentificare.php"; 
//include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/views/cont_nou.php"; 
//include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/views/am_uitat_parola.php"; 
//include SRV_PATH."views/producator.php";
//include SRV_PATH."views/permisiune.php";
//include SRV_PATH."views/rol.php";
//include SRV_PATH."views/utilizator.php";
//include SRV_PATH."views/produs.php"; 
//include SRV_PATH."views/footer.php"; 
?>