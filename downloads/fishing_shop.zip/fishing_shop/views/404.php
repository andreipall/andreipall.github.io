<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li class="active">Eroare 404</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<div class="alert alert-danger alert-dismissable">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<h1 class="admin-title">Eroare 404</h1><br />
						<p>Ne pare rau dar pagina cautată nu există!
						Va rugam sa verificati daca ati introdus un url corect.</p>
					</div>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>