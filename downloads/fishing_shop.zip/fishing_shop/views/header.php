<?php 
session_start(); 
$user_logged_in = !empty($_SESSION["utilizator"]["user_id"]);
function user_has_permission($permission) {
	return in_array($permission, $_SESSION["utilizator"]["permisiuni"]);
}
//var_dump($_SESSION);
if(empty($_SESSION["nr_total_produse"])) {
	$_SESSION["nr_total_produse"] = 0;
}
$path = explode('/', $_SERVER['REQUEST_URI']);

if(in_array("admin", $path)) {
	if($user_logged_in) { 
		if(!user_has_permission("Acceseaza pagini administrare")) {
			$_SESSION["warning_msg"] = 'Nu aveti suficiente permisiuni pentru a accesa aceasta pagina!';
			$_SESSION["login_redirect"] = HOME_PATH.'views/admin/'.basename($_SERVER['REQUEST_URI']);
			header("location: ".HOME_PATH."views/autentificare.php");
		}
	}
	else {
		$_SESSION["warning_msg"] = 'Trebuie sa fiti autentificat pentru a putea putea accesa pagina!';
		$_SESSION["login_redirect"] = HOME_PATH.'views/admin/'.basename($_SERVER['REQUEST_URI']);
		header("location: ".HOME_PATH."views/autentificare.php");
    }
}
//print_r($path);
?>
<!DOCTYPE html>
<html lang="ro">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fishing Shop</title>

    <!-- Bootstrap -->
    <link href="/fishing_shop/lib/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="/fishing_shop/lib/bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
	<link href="/fishing_shop/css/datepicker.css" rel="stylesheet">
    <link href="/fishing_shop/css/style.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <nav class="navbar navbar-default" role="navigation">
	    <div class="container-fluid">
	      <!-- Brand and toggle get grouped for better mobile display -->
	      <div class="navbar-header">
	        <a class="navbar-brand" href="<?php echo HOME_PATH ?>"><span class="glyphicon glyphicon-leaf"></span> Fishing Shop</a>
	      </div>

	      <!-- Collect the nav links, forms, and other content for toggling -->
	      <div class="collapse navbar-collapse" id="bs-main-navbar-collapse">
	        <?php include 'main_navigation.php' ?>
	        <form action="<?php echo HOME_PATH."views/cauta.php"; ?>" method="get" class="navbar-form navbar-left" role="search">
	          <div class="form-group">
	            <input name="term" type="text" class="form-control" placeholder="Cauta">
	          </div>
	        </form>
	        <ul class="nav navbar-nav navbar-right">
	          <li><a href="<?php echo HOME_PATH."views/cos_cumparaturi.php"; ?>"><span class="glyphicon glyphicon-shopping-cart"></span>  Cosul meu  <span id="cart-products-number" class="badge"><?php echo $_SESSION["nr_total_produse"]; ?></span></a></li>
	          <li class="dropdown">
				<?php if(!$user_logged_in) { ?>
				<a href="<?php echo HOME_PATH."views/autentificare.php"; ?>"><span class="glyphicon glyphicon-user"></span> Autentificare</a>
				<?php } else { ?>
	            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION["utilizator"]["prenume"]." ".$_SESSION["utilizator"]["nume"]; ?> <b class="caret"></b></a>
	            <ul class="dropdown-menu">
				  <li><a href="<?php echo HOME_PATH."views/autentificare.php"; ?>"></a></li>
	              <li><a href="<?php echo HOME_PATH."views/date_personale.php"; ?>">Date personale</a></li>
	              <li><a href="<?php echo HOME_PATH."views/setari_siguranta.php"; ?>">Setari siguranta</a></li>
	              <li><a href="<?php echo HOME_PATH."views/istoric_comenzi.php"; ?>">Istoric comenzi</a></li>
				  <li class="divider"></li>
				  <?php 
				  if($user_logged_in && user_has_permission("Acceseaza pagini administrare")) { ?>
				  <li><a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>">Produse</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/promotie.php"; ?>">Promotii</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/comenzi.php"; ?>">Comenzi</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/recenzie.php"; ?>">Recenzii</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/categorie.php"; ?>">Categorii</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/utilizator.php"; ?>">Utilizatori</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/rol.php"; ?>">Roluri</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/permisiune.php"; ?>">Permisiuni</a></li>
				  <li><a href="<?php echo HOME_PATH."views/admin/permisiuni_utilizatori.php"; ?>">Permisiuni utilizatori</a></li>
	              <li class="divider"></li>
				  <?php } ?>
	              <li><a href="<?php echo HOME_PATH."views/iesire.php"; ?>"><span class="glyphicon glyphicon-off"></span> Iesire</a></li>
	            </ul>
				<?php } ?>
	          </li>
	        </ul>
	      </div><!-- /.navbar-collapse -->
	    </div><!-- /.container-fluid -->
      </nav>