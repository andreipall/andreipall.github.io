<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
require_once SRV_PATH.'classes/crud.php';

include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li class="active">Date personale</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-8 col-md-offset-2">
		      		<br />
					<?php 
		      		success_msg(); 
					error_msg();

					$crud = new Crud();
					$client = $crud->select(array("NUME","PRENUME","EMAIL","PAROLA","TELEFON","ADRESA","ORAS","TARA","COD_POSTAL","ROL", "POZA"), array("DETALII_UTILIZATOR"), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]);
					$client = $client[0];
					?>
					<h1 class="admin-title col-md-offset-3">Date personale</h1><br />
					<br /><br />
					<form action="/fishing_shop/data/cont_nou.php" method="post" enctype="multipart/form-data" role="form" class="form-horizontal">
						<div class="form-group">
							<label for="firstName" class="col-sm-4 control-label">Nume</label>
							<div class="col-sm-8">
							    <input type="hidden" name="action" value="edit" />
								<input type="text" name="nume" class="form-control" id="firstName" placeholder="Nume" value="<?php echo $client->NUME; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="lastName" class="col-sm-4 control-label">Prenume</label>
							<div class="col-sm-8">
							  <input type="text" name="prenume" class="form-control" id="lastName" placeholder="Prenume" value="<?php echo $client->PRENUME; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="address" class="col-sm-4 control-label">Adresa livrare</label>
							<div class="col-sm-8">
								<textarea name="adresa" class="form-control" rows="3" id="address" placeholder="Adresa"><?php echo $client->ADRESA; ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="country" class="col-sm-4 control-label">Tara</label>
							<div class="col-sm-8">
								<?php select_country($client->TARA); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="city" class="col-sm-4 control-label">Orasul</label>
							<div class="col-sm-8">
								<?php select_city($client->ORAS); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="telephone" class="col-sm-4 control-label">Telefon</label>
							<div class="col-sm-8">
								<input type="tel" name="telefon" class="form-control" id="telephone" placeholder="Telefon" value="<?php echo $client->TELEFON; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="postal_code" class="col-sm-4 control-label">Cod postal</label>
							<div class="col-sm-8">
								<input type="number" name="cod_postal" class="form-control" id="postal_code" placeholder="Cod postal" value="<?php echo $client->COD_POSTAL; ?>">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-4">
								<img class="media-object" src="<?php if(empty($client->POZA)) {echo HOME_PATH."img/avatar.jpg";} else {echo HOME_PATH."img/poze/".$client->POZA;} ?>" alt="64x64" id="user-picture">
							</div>
						</div>
						<div class="form-group">
							<label for="picture" class="col-sm-4 control-label">Poza</label>
							<div class="col-sm-8">
								<input type="file" name="picture" id="picture">
							</div>
						</div>
						<br />
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-default">Salveaza modificarile</button>
							</div>
						</div>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>