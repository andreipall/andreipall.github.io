<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
include SRV_PATH."views/header.php";
//var_dump($_SESSION);die;
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li class="active">Setari siguranta</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-8 col-md-offset-2">
		      		<br />
					<?php 
		      		success_msg(); 
					error_msg(); 

					$crud = new Crud();
					$user = $crud->select(array("EMAIL","PAROLA"), array("DETALII_UTILIZATOR"), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]); 
					$user =$user[0];
					?>
					<h1 class="admin-title col-md-offset-3">Setari siguranta</h1><br />
					<br /><br />
					<form action="/fishing_shop/data/autentificare.php" method="post" role="form" class="form-horizontal">
						<div class="form-group">
							<label for="password" class="col-sm-4 control-label">Parola</label>
							<div class="col-sm-8">
								<input type="hidden" name="action" value="change" />
								<input type="password" name="parola" class="form-control" id="password" placeholder="Parola">
							</div>
						</div>
						<div class="form-group">
							<label for="confirmPassword" class="col-sm-4 control-label">Confirma parola</label>
							<div class="col-sm-8">
								<input type="password" name="confirma_parola" class="form-control" id="confirmPassword" placeholder="Parola">
							</div>
						</div>
						<br />
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-default">Salveaza modificarile</button>
							</div>
						</div>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>