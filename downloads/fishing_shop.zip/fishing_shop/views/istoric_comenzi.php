<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH; ?>">Acasa</a></li>
			  <li class="active">Istoric comenzi</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
					success_msg(); 
					error_msg(); ?>
					<br />
					<h1 class="admin-title">Istoric comenzi</h1>
		      		<br />
		      		<br />
		      		<table class="table">
					  <thead>
						<tr>
						  <th>Comanda</th>
						  <th>Data</th>
						  <th>Valoare</th>
						  <th>Status</th>
						</tr>
					  </thead>
					  <tbody>
						<?php list_orders($_SESSION["utilizator"]["user_id"]); ?>
					  </tbody>
					</table>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>