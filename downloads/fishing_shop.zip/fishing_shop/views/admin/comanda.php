<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
include SRV_PATH."views/header.php";

$crud = new Crud();
$order = $crud->select(array("ID_COMANDA","VALOARE_TOTALA", "DATA_COMANDA_INREGISTRATA", "ID_STATUS_COMANDA"), array("COMANDA"), "ID_COMANDA = ".$_GET["order_id"]);
$order = $order[0];
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>" class="list-group-item">Produse</a>
				<a href="<?php echo HOME_PATH."views/admin/promotie.php"; ?>" class="list-group-item">Promotii</a>
				<a href="<?php echo HOME_PATH."views/admin/comenzi.php"; ?>" class="list-group-item active">Comenzi</a>
				<a href="<?php echo HOME_PATH."views/admin/recenzie.php"; ?>" class="list-group-item">Recenzii</a>
				<a href="<?php echo HOME_PATH."views/admin/categorie.php"; ?>" class="list-group-item">Categorii</a>
				<a href="<?php echo HOME_PATH."views/admin/utilizator.php"; ?>" class="list-group-item">Utilizatori</a>
				<a href="<?php echo HOME_PATH."views/admin/rol.php"; ?>" class="list-group-item">Roluri</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiune.php"; ?>" class="list-group-item">Permisiuni</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiuni_utilizatori.php"; ?>" class="list-group-item">Permisiuni utilizatori</a>
            </ul>
        </div>
        <div class="col-md-10 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li><a href="<?php echo HOME_PATH.'views/admin/comenzi.php' ?>">Comenzi</a></li>
			  <li class="active"><?php echo 'Comanda nr. '.$order->ID_COMANDA; ?></li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php 
					success_msg(); 
					error_msg();
					?>
					<br />
					<h1 class="admin-title"><?php echo 'Comanda nr. '.$order->ID_COMANDA.' din data de '.$order->DATA_COMANDA_INREGISTRATA; ?></h1>
		      		<br />
		      		<br />
					<table id="shopping-cart" class="table">
					  <thead>
						<tr>
						  <th class="col-md-2">Produs</th>
						  <th>Descriere</th>
						  <th>Cant.</th>
						  <th>Pret</th>
						</tr>
					  </thead>
					  <tbody>
						<?php
							list_order_products($order->ID_COMANDA);
							echo '<tr>';
							echo '<td><strong>Cost total:</strong></td>';
							echo '<td><strong id="total_cost">'.$order->VALOARE_TOTALA.' RON</strong></td>';
							echo '<td></td>';
							echo '<td></td>';
							echo '</tr>';
						?>
					  </tbody>
					</table>
					<form role="form">
					<label for="status">Status</label>
					<input type="hidden" name="order_id" value="<?php echo $order->ID_COMANDA; ?>" id="order_id">
					<?php select_order_status($order->ID_STATUS_COMANDA); ?>
					<br />
					<button id="save_status" class="btn btn-default">Salveaza modificarile</button>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>