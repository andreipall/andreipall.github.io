<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>" class="list-group-item active">Produse</a>
				<a href="<?php echo HOME_PATH."views/admin/promotie.php"; ?>" class="list-group-item">Promotii</a>
				<a href="<?php echo HOME_PATH."views/admin/comenzi.php"; ?>" class="list-group-item">Comenzi</a>
				<a href="<?php echo HOME_PATH."views/admin/recenzie.php"; ?>" class="list-group-item">Recenzii</a>
				<a href="<?php echo HOME_PATH."views/admin/categorie.php"; ?>" class="list-group-item">Categorii</a>
				<a href="<?php echo HOME_PATH."views/admin/utilizator.php"; ?>" class="list-group-item">Utilizatori</a>
				<a href="<?php echo HOME_PATH."views/admin/rol.php"; ?>" class="list-group-item">Roluri</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiune.php"; ?>" class="list-group-item">Permisiuni</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiuni_utilizatori.php"; ?>" class="list-group-item">Permisiuni utilizatori</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH; ?>">Acasa</a></li>
			  <li><a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>">Produse</a></li>
			  <li class="active">Adauga produs</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-10 col-md-offset-1">
		      		<br />
		      		<?php include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
					success_msg();
					error_msg(); ?>
					<h1 class="admin-title col-md-offset-1">Adauga produs</h1><br /><br /><br />
		      		
					<form action="/fishing_shop/data/produs.php" method="post" enctype="multipart/form-data" role="form" class="form-horizontal">
						<div class="form-group">
							<label for="firstName" class="col-sm-2 control-label">Nume</label>
							<div class="col-sm-8">
							    <input type="hidden" name="action" value="add" />
								<input type="text" name="nume" class="form-control" id="firstName" placeholder="Nume" required>
							</div>
						</div>
						<div class="form-group">
							<label for="description" class="col-sm-2 control-label">Descriere</label>
							<div class="col-sm-8">
							  <textarea rows="4" cols="50" name="descriere" class="form-control" id="description" placeholder="Descriere" required></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="specifications" class="col-sm-2 control-label">Specificatii</label>
							<div class="col-sm-8">
								<textarea rows="4" cols="50" name="specificatii" class="form-control" id="specifications" placeholder="Specificatii" required></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="image" class="col-sm-2 control-label">Imagine</label>
							<div class="col-sm-8">
								<input type="file" name="imagine" class="form-control" id="image" required>
							</div>
						</div>
						<div class="form-group">
							<label for="producer" class="col-sm-2 control-label">Producator</label>
							<div class="col-sm-8">
								<?php select_producer(false); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="category" class="col-sm-2 control-label">Categorie</label>
							<div class="col-sm-8">
								<?php select_category(false); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="purchasePrice" class="col-sm-2 control-label">Pret de achizitie</label>
							<div class="input-group col-sm-3 input-price">
								<input type="number" name="pret_achizitie" class="form-control" id="purchasePrice" placeholder="0" required>
								<span class="input-group-addon">RON</span>
							</div>
						</div>
						<div class="form-group">
							<label for="quantity" class="col-sm-2 control-label">Cantitate</label>
							<div class="col-sm-8">
								<input type="number" name="cantitate" class="form-control" id="quantity" placeholder="0" required>
							</div>
						</div>
						<br />
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-8">
								<button type="submit" class="btn btn-default">Adauga produs</button>
							</div>
						</div>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>