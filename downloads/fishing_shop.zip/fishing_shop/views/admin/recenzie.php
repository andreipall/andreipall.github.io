<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>" class="list-group-item">Produse</a>
				<a href="<?php echo HOME_PATH."views/admin/promotie.php"; ?>" class="list-group-item">Promotii</a>
				<a href="<?php echo HOME_PATH."views/admin/comenzi.php"; ?>" class="list-group-item">Comenzi</a>
				<a href="<?php echo HOME_PATH."views/admin/recenzie.php"; ?>" class="list-group-item active">Recenzii</a>
				<a href="<?php echo HOME_PATH."views/admin/categorie.php"; ?>" class="list-group-item">Categorii</a>
				<a href="<?php echo HOME_PATH."views/admin/utilizator.php"; ?>" class="list-group-item">Utilizatori</a>
				<a href="<?php echo HOME_PATH."views/admin/rol.php"; ?>" class="list-group-item">Roluri</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiune.php"; ?>" class="list-group-item">Permisiuni</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiuni_utilizatori.php"; ?>" class="list-group-item">Permisiuni utilizatori</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH; ?>">Acasa</a></li>
			  <li class="active">Recenzii</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
					success_msg(); 
					error_msg(); ?>
					<br />
					<h1 class="admin-title">Recenzii</h1>
		      		<br />
		      		<br />
		      		<table class="table">
					  <thead>
						<tr>
						  <th>Recenzia</th>
						  <th>Produs</th>
						  <th>Data</th>
						  <th>Sterge</th>
						</tr>
					  </thead>
					  <tbody>
						<?php list_reviews(); ?>
					  </tbody>
					</table>

					<!-- Delete Category Modal -->
					<div class="modal fade" id="deleteReview" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  
						</div>
					  </div>
					</div>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>