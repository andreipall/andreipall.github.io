<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH."views/admin/produs.php"; ?>" class="list-group-item active">Produse</a>
				<a href="<?php echo HOME_PATH."views/admin/promotie.php"; ?>" class="list-group-item">Promotii</a>
				<a href="<?php echo HOME_PATH."views/admin/comenzi.php"; ?>" class="list-group-item">Comenzi</a>
				<a href="<?php echo HOME_PATH."views/admin/recenzie.php"; ?>" class="list-group-item">Recenzii</a>
				<a href="<?php echo HOME_PATH."views/admin/categorie.php"; ?>" class="list-group-item">Categorii</a>
				<a href="<?php echo HOME_PATH."views/admin/utilizator.php"; ?>" class="list-group-item">Utilizatori</a>
				<a href="<?php echo HOME_PATH."views/admin/rol.php"; ?>" class="list-group-item">Roluri</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiune.php"; ?>" class="list-group-item">Permisiuni</a>
				<a href="<?php echo HOME_PATH."views/admin/permisiuni_utilizatori.php"; ?>" class="list-group-item">Permisiuni utilizatori</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			    <li><a href="<?php echo HOME_PATH; ?>">Acasa</a></li>
			    <li class="active">Produse</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
					success_msg(); 
					error_msg(); ?>
					<br />
					<h1 class="admin-title">Produse</h1>
					<a class="btn btn-default pull-right" href="<?php echo HOME_PATH."views/admin/adauga_produs.php";?>">Adauga produs</a>
					<br />
					<br />
					<table class="table">
					  <thead>
						<tr>
						  <th>Nume</th>
						  <th>Descriere</th>
						  <th>Editeaza</th>
						  <th>Sterge</th>
						</tr>
					  </thead>
					  <tbody>
						<?php 
						$products = $crud->select(array("ID_PRODUS","NUME", "DESCRIERE"), array("DETALII_PRODUS"), false);
	
						$num_rows = $crud->count("DETALII_PRODUS", false);

						$per_page = 10;	// Per Page
						
						if(!empty($_GET["page"])) {
							$page = $_GET["page"];
						}
						else {
							$page=1;
						}
						
						$prev_page = $page-1;
						$next_page = $page+1;

						$page_start = (($per_page*$page)-$per_page);
						if($num_rows<=$per_page)
						{
							$num_pages =1;
						}
						else if(($num_rows % $per_page)==0)
						{
							$num_pages =($num_rows/$per_page);
						}
						else
						{
							$num_pages =($num_rows/$per_page)+1;
							$num_pages = (int)$num_pages;
						}
						$page_end = $per_page * $page;
						if ($page_end > $num_rows)
						{
							$page_end = $num_rows;
						}
						
						for($i=$page_start;$i<$page_end;$i++) {
							echo '<tr>';
							echo '<td>'.$products[$i]->NUME.'</td>';
							echo '<td>'.substr($products[$i]->DESCRIERE, 0, 120).'...</td>';
							echo '<td><a href="'.HOME_PATH.'views/admin/modals/produs_modal_edit.php?product_id='.$products[$i]->ID_PRODUS.'" data-toggle="modal" data-target="#editProduct"><span class="glyphicon glyphicon-edit"></span></a></td>';
							echo '<td><a href="'.HOME_PATH.'views/admin/modals/produs_modal_delete.php?product_id='.$products[$i]->ID_PRODUS.'" data-toggle="modal" data-target="#deleteProduct"><span class="glyphicon glyphicon-remove"></span></a></td>';
							echo '</tr>';
						}
						?>
					  </tbody>
					</table>
					<?php 
					if($num_pages!=1) { 
						echo '<div id="pagination"><ul class="pagination center-block">';
							if($page==1) {
								echo '<li class="disabled"><span>&laquo;</span></li>';
							} 
							else {
								echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$prev_page.'">&laquo;</a></li>';
							}
							for($i=1; $i<=$num_pages; $i++){ 
								if($i == $page) {
									echo '<li class="active"><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$i.'">'.$i.'</a></li>';
								}
								else {
									echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$i.'">'.$i.'</a></li>';
								}
							}
							if($page==$num_pages) {
								echo '<li class="disabled"><span>&raquo;</span></li>';
							}
							else {
								echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$next_page.'">&raquo;</a></li>';
							}
						echo '</ul></div>';
					} ?>
					
					<!-- Edit Product Modal -->
					<div class="modal fade" id="editProduct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  
						</div>
					  </div>
					</div>
					
					<!-- Delete Product Modal -->
					<div class="modal fade" id="deleteProduct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  
						</div>
					  </div>
					</div>
				
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>