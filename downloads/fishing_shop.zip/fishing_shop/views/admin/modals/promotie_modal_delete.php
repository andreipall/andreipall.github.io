<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Sterge promotia</h4>
</div>
<div class="modal-body">
	  <?php 
	  $crud = new Crud();
	  $promotion = $crud->select(array("PRODUS","PROCENT_DISCOUNT","DATA_INCEPUT","DATA_SFARSIT"), array("PROMOTII"), "ID_PROMOTIE = ".$_GET["promotion_id"]); 
	  $promotion =$promotion[0];
	  ?>
	  <p>Sunteti sigur ca doriti sa stergeti promotia pentru produsul:</p>
	  <p><strong><?php echo $promotion->PRODUS; ?></strong></p>
	  <p>Discount: <?php echo $promotion->PROCENT_DISCOUNT; ?></p>
	  <p>De la data de: <?php echo $promotion->DATA_INCEPUT." pana la data de ".$promotion->DATA_SFARSIT; ?></p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="delete-promotion" class="btn btn-primary">Sterge promotia</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#delete-promotion" ).click(function() {
    $.post("/fishing_shop/data/promotie.php", { action: "delete", id: <?php echo $_GET["promotion_id"]; ?> })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>