<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Adauga promotie</h4>
</div>
<div class="modal-body">
	<form action="/fishing_shop/data/promotie.php" method="post" role="form">
	  <div class="form-group">
		<label for="name">Produs</label>
		<?php select_product(false); ?>
	  </div>
	  <div class="form-group">
		<label for="description">Discount</label>
		<div class="input-group">
		<input type="number" name="discount" class="form-control" id="discount" placeholder="Discount">
		<span class="input-group-addon">%</span>
		</div>
	  </div>
	  <div class="form-group">
		<label for="parent_category">Data inceput / data sfarsit</label>
		<div class="input-daterange input-group" id="datepicker">
			<input type="text" id="start" class="input-sm form-control" name="start" />
			<span class="input-group-addon">pana la</span>
			<input type="text" id="end" class="input-sm form-control" name="end" />
		</div>
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="add-promotion" class="btn btn-primary">Adauga promotie</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $('.input-daterange').datepicker({
    format: 'dd/mm/yyyy',
	autoclose: true
  });
  $( "#add-promotion" ).click(function() {
    var product = $("#product").val();
	var discount = $("#discount").val();
	var start_date = $("#start").val();
	var end_date = $("#end").val();

    $.post("/fishing_shop/data/promotie.php", { action: "add", produs: product, discount: discount, data_inceput: start_date, data_sfarsit: end_date })
	  .done(function( data ) {
		$("#product").val('');
		$("#discount").val('');
		$("#start").val('');
		$("#end").val('');
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>