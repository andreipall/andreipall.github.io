<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Adauga categorie</h4>
</div>
<div class="modal-body">
	<form action="/fishing_shop/data/rol.php" method="post" role="form">
	  <div class="form-group">
		<label for="name">Nume</label>
		<input type="hidden" name="action" value="add" />
		<input type="text" name="nume" class="form-control" id="name" placeholder="Nume">
	  </div>
	  <div class="form-group">
		<label for="description">Descriere</label>
		<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere">
	  </div>
	  <div class="form-group">
		<label for="parent_category">Categoria parinte</label>
		<?php select_parent_category(false); ?>
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="add-category" class="btn btn-primary">Adauga categorie</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#add-category" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();
	var parent_category = $("#parent_category").val();

    $.post("/fishing_shop/data/categorie.php", { action: "add", nume: name, descriere: description, categorie_parinte: parent_category })
	  .done(function( data ) {
		$("#name").val('');
		$("#description").val('');
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>