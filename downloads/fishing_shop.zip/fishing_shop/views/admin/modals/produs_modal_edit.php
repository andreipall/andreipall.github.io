<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza produsul</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/produs.php" method="post" role="form">
	  <?php 
	  $crud = new Crud();
	  $product = $crud->select(array("NUME","DESCRIERE","SPECIFICATII","IMAGINE","PRODUCATOR","PRET_DE_ACHIZITIE","CANTITATE","ID_CATEGORIE"), array("DETALII_PRODUS"), "ID_PRODUS = ".$_GET["product_id"]); 
	  $product = $product[0];
	  ?>
		<div class="form-group">
			<img src="<?php if(empty($product->IMAGINE)) { echo "http://placehold.it/400x300"; } else { echo HOME_PATH."img/imagini_produse/".$product->IMAGINE; } ?>" alt="image">
	    </div>
		<div class="form-group">
			<label for="firstName">Nume</label>
			<input type="text" name="nume" class="form-control" id="name" placeholder="Nume" value="<?php echo $product->NUME; ?>">
		</div>
		<div class="form-group">
			<label for="description">Descriere</label>
			<textarea rows="4" cols="50" name="descriere" class="form-control" id="description" placeholder="Descriere"><?php echo $product->DESCRIERE; ?></textarea>
		</div>
		<div class="form-group">
			<label for="specifications">Specificatii</label>
			<textarea rows="4" cols="50" name="specificatii" class="form-control" id="specifications" placeholder="Specificatii"><?php echo $product->SPECIFICATII; ?></textarea>
		</div>
		<div class="form-group col-sm-6 pull-left">
			<label for="producer">Producator</label>
			<?php select_producer($product->PRODUCATOR); ?>
		</div>
		<div class="form-group col-sm-6 pull-left">
			<label for="category">Categorie</label>
			<?php select_category($product->ID_CATEGORIE); ?>
		</div>
		<div class="form-group col-sm-6 pull-left">
			<label for="purchasePrice">Pret de achizitie</label>
			<div class="input-group col-sm-12">
				<input type="number" name="pret_achizitie" class="form-control" id="purchasePrice" placeholder="0" value="<?php echo $product->PRET_DE_ACHIZITIE; ?>">
				<span class="input-group-addon">RON</span>
			</div>
		</div>
		<div class="form-group col-sm-6 pull-left">
			<label for="quantity">Cantitate</label>
			<input type="number" name="cantitate" class="form-control" id="quantity" placeholder="0" value="<?php echo $product->CANTITATE; ?>">
		</div>
		<div class="clearfix"></div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-product" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#edit-product" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();
	var specifications = $("#specifications").val();
	var producer = $("#producer").val();
	var category = $("#category").val();
	var purchasePrice = $("#purchasePrice").val();
	var quantity = $("#quantity").val();

    $.post("/fishing_shop/data/produs.php", { action: "edit", id: <?php echo $_GET["product_id"]; ?>, nume: name, descriere: description, specificatii: specifications, pret_achizitie: purchasePrice, cantitate: quantity, categorie: category, producator: producer })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>