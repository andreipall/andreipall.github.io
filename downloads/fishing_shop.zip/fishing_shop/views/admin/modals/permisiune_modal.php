<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Adauga permisiune</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/permisiune.php" method="post" role="form">
	  <div class="form-group">
		<label for="name">Nume</label>
		<input type="hidden" name="action" value="add" />
		<input type="text" name="nume" class="form-control" id="name" placeholder="Nume">
	  </div>
	  <div class="form-group">
		<label for="description">Descriere</label>
		<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere">
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="add-permission" class="btn btn-primary">Adauga permisiune</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#add-permission" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();
	//alert(name);
    $.post("/fishing_shop/data/permisiune.php", { action: "add", nume: name, descriere: description })
	  .done(function( data ) {
		$("#name").val('');
		$("#description").val('');
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>