<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza permisiunea</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/categorie.php" method="post" role="form">
	  <?php 
	  $crud = new Crud();
	  $permission = $crud->select(array("NUME","DESCRIERE"), array("PERMISIUNE"), "ID_PERMISIUNE = ".$_GET["permission_id"]); 
	  $permission = $permission[0];
	  ?>
	  <div class="form-group">
		<label for="name">Nume</label>
		<input type="hidden" name="action" value="add" />
		<input type="text" name="nume" class="form-control" id="name" placeholder="Nume" value="<?php echo $permission->NUME; ?>">
	  </div>
	  <div class="form-group">
		<label for="description">Descriere</label>
		<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere" value="<?php echo $permission->DESCRIERE; ?>">
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-permission" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#edit-permission" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();

    $.post("/fishing_shop/data/permisiune.php", { action: "edit", id: <?php echo $_GET["permission_id"]; ?>, nume: name, descriere: description })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>