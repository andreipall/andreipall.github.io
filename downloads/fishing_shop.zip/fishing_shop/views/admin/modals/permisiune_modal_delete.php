<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Sterge permisiunea</h4>
</div>
<div class="modal-body">
	  <?php 
	  $crud = new Crud();
	  $permission = $crud->select(array("NUME","DESCRIERE"), array("PERMISIUNE"), "ID_PERMISIUNE = ".$_GET["permission_id"]); 
	  $permission = $permission[0];
	  ?>
	  <p>Sunteti sigur ca doriti sa stergeti permisiunea:</p>
	  <p><strong><?php echo $permission->NUME; ?></strong></p>
	  <p><strong><?php echo $permission->DESCRIERE; ?></strong></p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="delete-permission" class="btn btn-primary">Sterge permisiunea</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#delete-permission" ).click(function() {
    $.post("/fishing_shop/data/permisiune.php", { action: "delete", id: <?php echo $_GET["permission_id"]; ?> })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>