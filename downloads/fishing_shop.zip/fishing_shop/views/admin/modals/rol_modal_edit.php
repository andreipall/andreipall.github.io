<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza rolul</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/categorie.php" method="post" role="form">
	  <?php 
	  $crud = new Crud();
	  $role = $crud->select(array("NUME","DESCRIERE"), array("ROL"), "ID_ROL = ".$_GET["role_id"]); 
	  $role =$role[0];
	  ?>
	  <div class="form-group">
		<label for="name">Nume</label>
		<input type="hidden" name="action" value="add" />
		<input type="text" name="nume" class="form-control" id="name" placeholder="Nume" value="<?php echo $role->NUME; ?>">
	  </div>
	  <div class="form-group">
		<label for="description">Descriere</label>
		<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere" value="<?php echo $role->DESCRIERE; ?>">
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-role" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#edit-role" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();

    $.post("/fishing_shop/data/rol.php", { action: "edit", id: <?php echo $_GET["role_id"]; ?>, nume: name, descriere: description })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>