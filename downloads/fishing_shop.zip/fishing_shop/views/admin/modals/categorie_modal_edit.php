<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza categoria</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/categorie.php" method="post" role="form">
	  <?php 
	  $crud = new Crud();
	  $category = $crud->select(array("ID_CATEGORIE_PARINTE", "NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE = ".$_GET["category_id"]); 
	  $category =$category[0];
	  ?>
	  <div class="form-group">
		<label for="name">Nume</label>
		<input type="hidden" name="action" value="add" />
		<input type="text" name="nume" class="form-control" id="name" placeholder="Nume" value="<?php echo $category->NUME; ?>">
	  </div>
	  <div class="form-group">
		<label for="description">Descriere</label>
		<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere" value="<?php echo $category->DESCRIERE; ?>">
	  </div>
	  <div class="form-group">
		<label for="parent_category">Categoria parinte</label>
		<?php select_parent_category($category->ID_CATEGORIE_PARINTE); ?>
	  </div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-category" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#edit-category" ).click(function() {
    var name = $("#name").val();
	var description = $("#description").val();
	var parent_category = $("#parent_category").val();

    $.post("/fishing_shop/data/categorie.php", { action: "edit", id: <?php echo $_GET["category_id"]; ?>, nume: name, descriere: description, categorie_parinte: parent_category })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>