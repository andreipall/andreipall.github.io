<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Sterge utilizatorul</h4>
</div>
<div class="modal-body">
	  <?php 
	  $crud = new Crud();
	  $user = $crud->select(array("NUME","PRENUME"), array("DETALII_UTILIZATOR"), "ID_UTILIZATOR = ".$_GET["user_id"]); 
	  $user =$user[0];
	  ?>
	  <p>Sunteti sigur ca doriti sa stergeti utilizatorul:</p>
	  <p><strong><?php echo $user->NUME." ".$user->PRENUME; ?></strong></p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="delete-user" class="btn btn-primary">Sterge utilizatorul</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#delete-user" ).click(function() {
    $.post("/fishing_shop/data/utilizator.php", { action: "delete", id: <?php echo $_GET["user_id"]; ?> })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>