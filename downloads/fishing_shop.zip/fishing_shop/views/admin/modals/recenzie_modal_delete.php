<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Sterge recenzia</h4>
</div>
<div class="modal-body">
	  <?php 
	  $crud = new Crud();
	  $review = $crud->select(array("PRODUS","CONTINUT"), array("RECENZII_PRODUS"), "ID_RECENZIE = ".$_GET["review_id"]); 
	  $review =$review[0];
	  ?>
	  <p>Sunteti sigur ca doriti sa stergeti recenzia pentru produsul:</p>
	  <p><strong><?php echo $review->PRODUS; ?></strong></p>
	  <p>Continut: <?php echo $review->CONTINUT; ?></p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="delete-review" class="btn btn-primary">Sterge recenzia</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#delete-review" ).click(function() {
    $.post("/fishing_shop/data/sterge_recenzie.php", { action: "delete", id: <?php echo $_GET["review_id"]; ?> })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>