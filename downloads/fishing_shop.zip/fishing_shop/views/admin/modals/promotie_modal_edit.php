<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza promotia</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/promotie.php" method="post" role="form">
	  <?php 
	  $crud = new Crud();
	  $promotion = $crud->select(array("ID_PRODUS", "PROCENT_DISCOUNT","DATA_INCEPUT","DATA_SFARSIT"), array("PROMOTIE"), "ID_PROMOTIE = ".$_GET["promotion_id"]); 
	  $promotion =$promotion[0];
	  ?>
	
	  <div class="form-group">
		<label for="name">Produs</label>
		<?php select_product($promotion->ID_PRODUS); ?>
	  </div>
	  <div class="form-group">
		<label for="description">Discount</label>
		<div class="input-group">
		<input type="number" name="discount" value="<?php echo $promotion->PROCENT_DISCOUNT; ?>" class="form-control" id="discount" placeholder="Discount">
		<span class="input-group-addon">%</span>
		</div>
	  </div>
	  <div class="form-group">
		<label for="parent_category">Data inceput / data sfarsit</label>
		<div class="input-daterange input-group" id="datepicker">
			<input type="text" id="start" class="input-sm form-control" name="start" value="<?php echo $promotion->DATA_INCEPUT; ?>" />
			<span class="input-group-addon">pana la</span>
			<input type="text" id="end" class="input-sm form-control" name="end" value="<?php echo $promotion->DATA_SFARSIT; ?>" />
		</div>
	  </div>
	
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-promotion" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $('.input-daterange').datepicker({
    format: 'dd/mm/yyyy',
	autoclose: true
  });
  $( "#edit-promotion" ).click(function() {
    var product = $("#product").val();
	var discount = $("#discount").val();
	var start_date = $("#start").val();
	var end_date = $("#end").val();

    $.post("/fishing_shop/data/promotie.php", { action: "edit", id: <?php echo $_GET["promotion_id"]; ?>, produs: product, discount: discount, data_inceput: start_date, data_sfarsit: end_date })
	  .done(function( data ) {
		//alert( "Data Loaded: " + data );
		location.reload();
	  });
  });
  
});
</script>