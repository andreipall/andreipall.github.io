<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; 
require_once SRV_PATH.'classes/crud.php';
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <h4 class="modal-title">Editeaza utilizatorul</h4>
</div>
<div class="modal-body">
	<div id="errors"></div>
	<form action="/fishing_shop/data/utilizator.php" method="post" class="form-horizontal" role="form">
	    <?php 
	    $crud = new Crud();
	    $user = $crud->select(array("NUME","PRENUME","EMAIL","PAROLA","TELEFON","ADRESA","ORAS","TARA","COD_POSTAL","ROL"), array("DETALII_UTILIZATOR"), "ID_UTILIZATOR = ".$_GET["user_id"]); 
	    $user =$user[0];
	    ?>
	    <div class="form-group">
			<label for="firstName" class="col-sm-4 control-label">Nume</label>
			<div class="col-sm-8">
				<input type="hidden" name="action" value="add" />
				<input type="text" name="nume" class="form-control" id="firstName" placeholder="Nume" value="<?php echo $user->NUME; ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="lastName" class="col-sm-4 control-label">Prenume</label>
			<div class="col-sm-8">
			  <input type="text" name="prenume" class="form-control" id="lastName" placeholder="Prenume" value="<?php echo $user->PRENUME; ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="email" class="col-sm-4 control-label">Email</label>
			<div class="col-sm-8">
				<input type="email" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo $user->EMAIL; ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="address" class="col-sm-4 control-label">Adresa livrare</label>
			<div class="col-sm-8">
				<textarea name="adresa" class="form-control" rows="3" id="address" placeholder="Adresa"><?php echo $user->ADRESA; ?></textarea>
			</div>
		</div>
		<div class="form-group">
			<label for="country" class="col-sm-4 control-label">Tara</label>
			<div class="col-sm-8">
				<?php select_country($user->TARA); ?>
			</div>
		</div>
		<div class="form-group">
			<label for="city" class="col-sm-4 control-label">Orasul</label>
			<div class="col-sm-8">
				<?php select_city($user->ORAS); ?>
			</div>
		</div>
		<div class="form-group">
			<label for="telephone" class="col-sm-4 control-label">Telefon</label>
			<div class="col-sm-8">
				<input type="tel" name="telefon" class="form-control" id="telephone" placeholder="Telefon" value="<?php echo $user->TELEFON; ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="postal_code" class="col-sm-4 control-label">Cod postal</label>
			<div class="col-sm-8">
				<input type="text" name="cod_postal" class="form-control" id="postal_code" placeholder="Cod postal" value="<?php echo $user->COD_POSTAL; ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="role" class="col-sm-4 control-label">Rol</label>
			<div class="col-sm-8">
				<?php select_role($user->ROL); ?>
			</div>
		</div>
	</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">Inchide</button>
  <button type="button" id="edit-user" class="btn btn-primary">Salveaza modificarile</button>
</div>
<script language="javascript" type="text/javascript">
$( document ).ready(function() {
  $( "#edit-user" ).click(function() {
    var firstname = $("#firstName").val();
	var lastname = $("#lastName").val();
    var email = $("#email").val();
	var password = $("#password").val();
	var confirm_password = $("#confirmPassword").val();
	var address = $("#address").val();
	var country = $("#country").val();
	var city = $("#city").val();
	var telephone = $("#telephone").val();
	var postal_code = $("#postal_code").val();
	var role = $("#role").val();

    $.post("/fishing_shop/data/utilizator.php", { action: "edit", id: <?php echo $_GET["user_id"]; ?>,nume: firstname, prenume: lastname, email: email, parola: password, confirma_parola: confirm_password, adresa: address, oras: city, tara: country, cod_postal: postal_code, telefon: telephone, rol: role })
	  .done(function( data ) {
		$("#firstName").val('');
		$("#lastName").val('');
		$("#email").val('');
		$("#password").val('');
		$("#confirmPassword").val('');
		$("#address").val('');
		$("#telephone").val('');
		$("#postal_code").val('');
		location.reload();
	  });
  });
  
});
</script>