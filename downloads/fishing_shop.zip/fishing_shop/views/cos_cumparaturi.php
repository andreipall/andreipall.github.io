<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li class="active">Cos cumparaturi</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php 
					success_msg(); 
					error_msg(); ?>
					<br />
					<h1 class="admin-title">Cos cumparaturi</h1>
		      		<br />
		      		<br />
					<form action="/fishing_shop/data/trimite_comanda.php" method="post" role="form">
						<table id="shopping-cart" class="table">
						  <thead>
							<tr>
							  <th>Produs</th>
							  <th>Pret</th>
							  <th>Cantitate</th>
							  <th>Sterge</th>
							</tr>
						  </thead>
						  <tbody>
							<?php
							if(isset($_SESSION["produse"])) {
								//var_dump($_SESSION["produse"]);
								$cost_total = 0;
								$crud = new Crud();
								foreach($_SESSION["produse"] as &$produs_cos) {
									$products = $crud->select(array("ID_PRODUS","ID_PROMOTIE","NUME","CANTITATE","PRET_DE_VANZARE","PRET_LICHIDARE_STOC","PRET_DE_VANZARE_PROMOTIE"), array("DETALII_PRODUS"), "ID_PRODUS = ".$produs_cos["id_produs"]);
									foreach($products as $product) {
										echo '<tr>';
										echo '<td>'.$product->NUME.'</td>';
										if($produs_cos["lichidare_stoc"] == "true") {
											echo '<td>'.$product->PRET_LICHIDARE_STOC.' RON</td>';
											$cost_total += $produs_cos["cantitate"] * $product->PRET_LICHIDARE_STOC;
											$produs_cos["pret_vanzare"] = $product->PRET_LICHIDARE_STOC;
										}
										elseif($produs_cos["id_promotie"] > 0) {
											echo '<td>'.$product->PRET_DE_VANZARE_PROMOTIE.' RON</td>';
											$cost_total += $produs_cos["cantitate"] * $product->PRET_DE_VANZARE_PROMOTIE;
											$produs_cos["pret_vanzare"] = $product->PRET_DE_VANZARE_PROMOTIE;
										}
										else {
											echo '<td>'.$product->PRET_DE_VANZARE.' RON</td>';
											$cost_total += $produs_cos["cantitate"] * $product->PRET_DE_VANZARE;
											$produs_cos["pret_vanzare"] = $product->PRET_DE_VANZARE;
										}
										echo '<td><input type="number" id="'.$product->ID_PRODUS.'" class="form-control quantity" name="quantity" min="1" max="'.$product->CANTITATE.'" value="'.$produs_cos["cantitate"].'"></td>';
										echo '<td><a href="'.HOME_PATH.'views/produs_modal_delete.php?product_id='.$product->ID_PRODUS.'" data-toggle="modal" data-target="#deleteProduct"><span class="glyphicon glyphicon-remove"></span></a></td>';
										echo '</tr>';
									}
								}
								$_SESSION["cost_total"] = $cost_total;
								echo '<tr>';
								echo '<td><strong>Cost total:</strong></td>';
								echo '<td><strong id="total_cost">'.$cost_total.' RON</strong></td>';
								echo '<td></td>';
								echo '<td></td>';
								echo '</tr>';
							}
							else {
								echo "<tr><td>Nu exista niciun produs in cosul de cumparaturi.</td></tr>";
							}
							?>
						  </tbody>
						</table>
						<?php
						if(!empty($_SESSION["utilizator"]["user_id"])) { 
							echo '<div id="client-address" class="col-md-10">';
							$crud = new Crud();
							$client = $crud->select(array("NUME","PRENUME","EMAIL","PAROLA","TELEFON","ADRESA","ORAS","TARA","COD_POSTAL","ROL"), array("DETALII_UTILIZATOR"), "ID_UTILIZATOR = ".$_SESSION["utilizator"]["user_id"]);
							$client = $client[0];
							echo '<h3>Detalii livrare</h3>';
							echo '<strong class="address-details">'.$client->NUME.' '.$client->PRENUME.'</strong><br />';
							echo '<address class="address-details">';
							echo $client->ADRESA.'<br />';
							echo $client->ORAS.', '.$client->TARA.'<br />';
							echo $client->COD_POSTAL.'<br />';
							echo 'T: '.$client->TELEFON.'<br />';
							echo '</address>';
							echo '</div>';
						}
						
						if(isset($_SESSION["produse"])) {
							echo '<button type="submit" class="btn btn-default pull-right">Trimite comanda</button>';
						}
						?>
					</form>
					
					<!-- Delete Product Modal -->
					<div class="modal fade" id="deleteProduct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  
						</div>
					  </div>
					</div>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>