<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
include SRV_PATH."views/header.php";

$crud = new Crud();
$order = $crud->select(array("ID_COMANDA","VALOARE_TOTALA", "DATA_COMANDA_INREGISTRATA", "STATUS"), array("COMENZI"), "ID_COMANDA = ".$_GET["order_id"]);
$order = $order[0];
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li><a href="<?php echo HOME_PATH.'views/istoric_comenzi.php' ?>">Istoric comenzi</a></li>
			  <li class="active"><?php echo 'Comanda nr. '.$order->ID_COMANDA; ?></li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-12">
					<?php 
					success_msg(); 
					error_msg();
					?>
					<br />
					<h1 class="admin-title"><?php echo 'Comanda nr. '.$order->ID_COMANDA.' din data de '.$order->DATA_COMANDA_INREGISTRATA; ?></h1>
		      		<br />
		      		<br />
					<table id="shopping-cart" class="table">
					  <thead>
						<tr>
						  <th class="col-md-2">Produs</th>
						  <th>Descriere</th>
						  <th>Cant.</th>
						  <th>Pret</th>
						</tr>
					  </thead>
					  <tbody>
						<?php
							list_order_products($order->ID_COMANDA);
							echo '<tr>';
							echo '<td><strong>Cost total:</strong></td>';
							echo '<td><strong id="total_cost">'.$order->VALOARE_TOTALA.' RON</strong></td>';
							echo '<td></td>';
							echo '<td></td>';
							echo '</tr>';
						?>
					  </tbody>
					</table>
					
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>