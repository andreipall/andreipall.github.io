<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/data/helpers.php";

$crud = new Crud();
$product = $crud->select(array("ID_PRODUS","ID_CATEGORIE","NUME","IMAGINE","DESCRIERE", "SPECIFICATII", "PRODUCATOR", "PRET_DE_VANZARE", "PRET_DE_VANZARE_PROMOTIE", "PRET_LICHIDARE_STOC", "CANTITATE", "PROMOTIE", "ID_PROMOTIE","PROMOTIE_PROCENT_DISCOUNT", "PROMOTIE_DATA_INCEPUT", "PROMOTIE_DATA_SFARSIT"), array("DETALII_PRODUS"), "ID_PRODUS = ".htmlspecialchars($_GET["product_id"]));
if(empty($product)) {
	header("location: ".HOME_PATH."views/404.php");
}
$product = $product[0];
include SRV_PATH."views/header.php";
?>	
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
			<ul class="list-group">
				<?php
				$subcategories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$product->ID_CATEGORIE);
				if(count($subcategories) > 0) {
					foreach($subcategories as $subcategory) {
					  $count = $crud->count("PRODUS", "ID_CATEGORIE = ".$subcategory->ID_CATEGORIE);
					?>
					<a href="<?php echo HOME_PATH."views/categorie.php?category_id=".$subcategory->ID_CATEGORIE; ?>" class="list-group-item"><span class="badge"><?php echo $count;?></span> <?php echo $subcategory->NUME; ?></a>
					<?php
					}
				}
				else {
					$categories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE = ".$product->ID_CATEGORIE." AND ID_CATEGORIE_PARINTE NOT IN (1,2,3)");
					foreach($categories as $category) {
						$breadcrumb_categ[$category->ID_CATEGORIE] = $category->NUME;
						$subcategories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$category->ID_CATEGORIE_PARINTE);
						foreach($subcategories as $subcategory) {
							$count = $crud->count("PRODUS", "ID_CATEGORIE = ".$subcategory->ID_CATEGORIE);
							?>
							<a href="<?php echo HOME_PATH."views/categorie.php?category_id=".$subcategory->ID_CATEGORIE; ?>" class="list-group-item <?php if($subcategory->ID_CATEGORIE==$product->ID_CATEGORIE){echo "active";} ?>"><span class="badge"><?php echo $count;?></span> <?php echo $subcategory->NUME; ?></a>
							<?php
						}
					}
				}
				?>
            </ul>
        </div>
        <div class="col-md-10 main-content">
        	<div class="row">
				<ol class="breadcrumb">
					<li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
					<?php
					$categories = get_parent_categories($product->ID_CATEGORIE);
					foreach($categories as $key => $value) {
						echo '<li><a href="'.HOME_PATH.'views/categorie.php?category_id='.$key.'">'.$value.'</a></li>';
					}
					?>
					<li class="active"><?php echo $product->NUME;?></li>
				</ol>		
			</div>
		    <!-- Example row of columns -->
		    <div class="row">
				<?php success_msg(); 
					error_msg(); 
					warning_msg(); ?>
		      	<div class="pull-left"><img src="<?php if(empty($product->IMAGINE)) { echo "http://placehold.it/400x300"; } else { echo HOME_PATH."img/imagini_produse/".$product->IMAGINE; } ?>" alt="image" class="product-image"></div>
		      	
					<div class="pull-right col-md-6">
						
						<h2 class="pull-left"><?php echo $product->NUME;?></h2><div class="clearfix"></div>
						<form id="product_form" role="form">
							<table>
								<?php if($product->CANTITATE < SELLOFFS_PROD) { ?>
								<tr>
								  <td><strong class="control-label">Pret initial:</strong></td>
								  <td><span class="label label-warning" id="price"><?php echo $product->PRET_DE_VANZARE;?> RON</span></td> 
								</tr>
								<tr>
								  <td><strong class="control-label">Pret cu reducere:</strong></td>
								  <td><span class="label label-warning" id="price"><?php echo $product->PRET_LICHIDARE_STOC;?> RON</span></td> 
								</tr>
								<?php } elseif($product->PROMOTIE == 1 && date("d-m-Y") > date("d-m-Y", strtotime($product->PROMOTIE_DATA_INCEPUT)) && date("d-m-Y") < date("d-m-Y", strtotime($product->PROMOTIE_DATA_SFARSIT))) { ?>
								<tr>
								  <td><strong class="control-label">Pret initial:</strong></td>
								  <td><span class="label label-danger" id="price"><?php echo $product->PRET_DE_VANZARE;?> RON</span></td> 
								</tr>
								<tr>
								  <td><strong class="control-label">Discount:</strong></td>
								  <td><span class="label label-default" id="price"><?php echo $product->PROMOTIE_PROCENT_DISCOUNT;?> %</span></td> 
								</tr>
								<tr>
								  <td><strong class="control-label">Pret final:</strong></td>
								  <td><span class="label label-warning" id="price"><?php echo $product->PRET_DE_VANZARE_PROMOTIE;?> RON</span></td> 
								</tr>
								<?php } else { ?>
								<tr>
								  <td><strong class="control-label">Pret:</strong></td>
								  <td><span class="label label-warning" id="price"><?php echo $product->PRET_DE_VANZARE;?> RON</span></td> 
								</tr>
								<?php } ?>
								<tr>
								  <td><label for="quantity" class="control-label">Cantitate:</label></td>
								  <td><input type="number" class="form-control" id="quantity" name="quantity" placeholder="1" min="1" max="<?php echo $product->CANTITATE;?>"></td> 
								</tr>
								<tr>
								  <td><strong class="control-label">Disponibilitate:</strong></td>
								  <td><span id="stoc" class="label label-success"><?php if($product->CANTITATE >= 10) {echo "in stoc";} else {echo "stoc limitat";} ?></span></td> 
								</tr>
								<tr>
								  <td><strong class="control-label">Producator:</strong></td>
								  <td><strong><?php echo $product->PRODUCATOR;?></strong></td> 
								</tr>
								<tr>
								  <td>
								    <input type="hidden" name="promotion_id" value="<?php echo $product->ID_PROMOTIE; ?>" id="promotion-id">
									<input type="hidden" name="selloff" value="<?php if($product->CANTITATE < SELLOFFS_PROD) { echo "true"; } else { echo "false"; } ?>" id="selloff">
									<input type="hidden" name="product_id" value="<?php echo $product->ID_PRODUS; ?>" id="product-id">
								  </td>
								  <td><button type="submit" id="add-to-cart" class="btn btn-primary">Adauga in cos</button></td> 
								</tr>
							</table>
						</form>
					</div><div class="clearfix"></div><br />
					<div>
						<div>
							<ul class="nav nav-tabs">
							  <li class="active"><a href="#description" data-toggle="tab">Descriere produs</a></li>
							  <li><a href="#specifications" data-toggle="tab">Specificatii</a></li>
							</ul>
							
							<!-- Tab panes -->
							<div class="tab-content">
							  <div class="tab-pane active" id="description">
								<h3>Descriere produs</h3>
								<?php echo $product->DESCRIERE;?>
							  </div>
							  <div class="tab-pane" id="specifications">
								<h3>Specificatii</h3>
								<?php echo $product->SPECIFICATII;?>
							  </div>
							</div>
						</div>
						<div>
							<h3>Recenzii</h3>
							<div id="recenzii">
								<?php
								$recenzii = $crud->select(array("ID_RECENZIE","ID_RECENZIE_PARINTE","ID_UTILIZATOR","CONTINUT","DATA_POSTARII", "POZA", "NUME", "PRENUME"), array("RECENZII_PRODUS"), "ID_PRODUS = ".htmlspecialchars($_GET["product_id"])." AND ID_RECENZIE_PARINTE IS NULL", "DATA_POSTARII ASC");
								foreach($recenzii as $recenzie) {
								?>
								<div class="media">
								  <a class="pull-left" href="#">
									<img class="media-object user-image" src="<?php if(empty($recenzie->POZA)) {echo HOME_PATH."img/avatar.jpg";} else {echo HOME_PATH."img/poze/".$recenzie->POZA;} ?>" alt="64x64">
								  </a>
								  <div class="media-body">
									<h4 class="media-heading"><?php echo $recenzie->NUME." ".$recenzie->PRENUME." - ".$recenzie->DATA_POSTARII; ?></h4>
									<?php echo $recenzie->CONTINUT; 
									if($user_logged_in) {
										if($recenzie->ID_UTILIZATOR == $_SESSION["utilizator"]["user_id"] && user_has_permission("Sterge recenzii")) {
											echo ' <a review_id="'.$recenzie->ID_RECENZIE.'" class="delete-review" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span> sterge</a>';
										}
										if(user_has_permission("Posteaza recenzii")) { 
											echo '<p><a id="'.$recenzie->ID_RECENZIE.'" class="add-review-response" href="javascript:void(0)">raspunde <span class="glyphicon glyphicon-comment"></span></a></p>';
										} 
									}
									$recenzii = $crud->select(array("ID_RECENZIE","ID_RECENZIE_PARINTE","ID_UTILIZATOR","CONTINUT","DATA_POSTARII", "POZA", "NUME", "PRENUME"), array("RECENZII_PRODUS"), "ID_RECENZIE_PARINTE = ".$recenzie->ID_RECENZIE, "DATA_POSTARII ASC");
									foreach($recenzii as $recenzie) {
									?>
									<div class="media">
									  <a class="pull-left" href="#">
										<img class="media-object user-image" src="<?php if(empty($recenzie->POZA)) {echo HOME_PATH."img/avatar.jpg";} else {echo HOME_PATH."img/poze/".$recenzie->POZA;} ?>" alt="64x64">
									  </a>
									  <div class="media-body">
										<h4 class="media-heading"><?php echo $recenzie->NUME." ".$recenzie->PRENUME." - ".$recenzie->DATA_POSTARII; ?></h4>
										<?php echo $recenzie->CONTINUT; 
										if($user_logged_in) {
											if($recenzie->ID_UTILIZATOR == $_SESSION["utilizator"]["user_id"] && user_has_permission("Sterge recenzii")) {
												echo ' <a review_id="'.$recenzie->ID_RECENZIE.'" class="delete-review" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span> sterge</a>';
											}
											if(user_has_permission("Posteaza recenzii")) { 
												echo '<p><a id="'.$recenzie->ID_RECENZIE.'" class="add-review-response" href="javascript:void(0)">raspunde <span class="glyphicon glyphicon-comment"></span></a></p>';
											} 
										}
										$recenzii = $crud->select(array("ID_RECENZIE","ID_RECENZIE_PARINTE","ID_UTILIZATOR","CONTINUT","DATA_POSTARII", "POZA", "NUME", "PRENUME"), array("RECENZII_PRODUS"), "ID_RECENZIE_PARINTE = ".$recenzie->ID_RECENZIE, "DATA_POSTARII ASC");
										foreach($recenzii as $recenzie) {
										?>
										<div class="media">
										  <a class="pull-left" href="#">
											<img class="media-object user-image" src="<?php if(empty($recenzie->POZA)) {echo HOME_PATH."img/avatar.jpg";} else {echo HOME_PATH."img/poze/".$recenzie->POZA;} ?>" alt="64x64">
										  </a>
										  <div class="media-body">
											<h4 class="media-heading"><?php echo $recenzie->NUME." ".$recenzie->PRENUME." - ".$recenzie->DATA_POSTARII; ?></h4>
											<?php echo $recenzie->CONTINUT; 
											if($user_logged_in) {
												if($recenzie->ID_UTILIZATOR == $_SESSION["utilizator"]["user_id"] && user_has_permission("Sterge recenzii")) {
													echo ' <a review_id="'.$recenzie->ID_RECENZIE.'" class="delete-review" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span> sterge</a>';
												}
												if(user_has_permission("Posteaza recenzii")) { 
													echo '<p><a id="'.$recenzie->ID_RECENZIE.'" class="add-review-response" href="javascript:void(0)">raspunde <span class="glyphicon glyphicon-comment"></span></a></p>';
												} 
											}
											$recenzii = $crud->select(array("ID_RECENZIE","ID_RECENZIE_PARINTE","ID_UTILIZATOR","CONTINUT","DATA_POSTARII", "POZA", "NUME", "PRENUME"), array("RECENZII_PRODUS"), "ID_RECENZIE_PARINTE = ".$recenzie->ID_RECENZIE, "DATA_POSTARII ASC");
											foreach($recenzii as $recenzie) {
											?>
											<div class="media">
											  <a class="pull-left" href="#">
												<img class="media-object user-image" src="<?php if(empty($recenzie->POZA)) {echo HOME_PATH."img/avatar.jpg";} else {echo HOME_PATH."img/poze/".$recenzie->POZA;} ?>" alt="64x64">
											  </a>
											  <div class="media-body">
												<h4 class="media-heading"><?php echo $recenzie->NUME." ".$recenzie->PRENUME." - ".$recenzie->DATA_POSTARII; ?></h4>
												<?php echo $recenzie->CONTINUT; 
												if($user_logged_in) {
													if($recenzie->ID_UTILIZATOR == $_SESSION["utilizator"]["user_id"] && user_has_permission("Sterge recenzii")) {
														echo ' <a review_id="'.$recenzie->ID_RECENZIE.'" class="delete-review" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span> sterge</a>';
													}
													if(user_has_permission("Posteaza recenzii")) { 
														echo '<p><a id="'.$recenzie->ID_RECENZIE.'" class="add-review-response" href="javascript:void(0)">raspunde <span class="glyphicon glyphicon-comment"></span></a></p>';
													} 
												} ?>
											  </div>
											</div>
											<?php
											}
											?>
										  </div>
										</div>
										<?php
										}
										?>
									  </div>
									</div>
									<?php
									}
									?>
								  
								  </div>
								</div>
								<?php
								}
								
								if($user_logged_in && user_has_permission("Posteaza recenzii")) { 
								?>
								<form role="form">
									<h3>Adauga recenzie</h3>
									<textarea name="review" id="review" class="form-control" rows="3" required></textarea><br />
									<button id="add-review" class="btn btn-default">Adauga recenzia</button>
								</form>
								<?php } 
								else {
									echo '<p><br />Trebuie sa fiti <a href="'.HOME_PATH.'views/autentificare.php">autentificat</a> pentru a putea posta recenzii.</p>';
								}
								?>
						    </div>
						</div>
					</div>
				</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>