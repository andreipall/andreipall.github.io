<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="#" class="list-group-item active"><span class="badge">14</span> Lansete</a>
				<a href="#" class="list-group-item"><span class="badge">1</span> Mulinete</a>
				<a href="#" class="list-group-item"><span class="badge">5</span> Carlige</a>
				<a href="#" class="list-group-item"><span class="badge">0</span> Plumbi</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			    <li><a href="#">Acasa</a></li>
			    <li><a href="#">Undite</a></li>
			    <li class="active">Lungi</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
		      	<div class="col-md-4 col-md-offset-4">
		      		<br />
		      		<?php include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php'; ?>
		      		<?php success_msg(); ?>
					<?php error_msg(); ?>
					<form action="/fishing_shop/data/producator.php" method="post" class="form-horizontal" role="form">
					  <div class="form-group">
						<label for="producer" class="col-sm-3 control-label">Producator</label>
						<div class="col-sm-9">
							<input type="hidden" name="action" value="add" />
							<input type="text" name="producator" class="form-control" id="producer" placeholder="Producator">
						</div>
					  </div>
					  <div class="form-group">
						<label for="description" class="col-sm-3 control-label">Descriere</label>
						<div class="col-sm-9">
							<input type="text" name="descriere" class="form-control" id="description" placeholder="Descriere">
						</div>
					  </div>
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default">Adauga producator</button>
						</div>
					</div>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>