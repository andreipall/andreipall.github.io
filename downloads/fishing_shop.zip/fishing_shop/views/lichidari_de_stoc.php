<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include SRV_PATH."views/header.php";
?>
	<article>
		<?php
		$products = $crud->select(array("ID_PRODUS","NUME","IMAGINE","DESCRIERE", "PRODUCATOR", "PRET_DE_ACHIZITIE","PRET_DE_VANZARE", "PROMOTIE", "PROMOTIE_PROCENT_DISCOUNT", "PRET_LICHIDARE_STOC"), array("DETALII_PRODUS"), "CANTITATE < ".SELLOFFS_PROD);
		
		$num_rows = $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD);
		if($num_rows == 0) {
			echo '<div class="col-sm-12 col-md-12"><div class="alert alert-warning">Nu exista niciun produs in categoria selectata!</div></div>';
		}
		$per_page = PER_PAGE;	// Per Page
		
		if(!empty($_GET["page"])) {
			$page = $_GET["page"];
		}
		else {
			$page=1;
		}
		
		$prev_page = $page-1;
		$next_page = $page+1;

		$page_start = (($per_page*$page)-$per_page);
		if($num_rows<=$per_page)
		{
			$num_pages =1;
		}
		else if(($num_rows % $per_page)==0)
		{
			$num_pages =($num_rows/$per_page);
		}
		else
		{
			$num_pages =($num_rows/$per_page)+1;
			$num_pages = (int)$num_pages;
		}
		$page_end = $per_page * $page;
		if ($page_end > $num_rows)
		{
			$page_end = $num_rows;
		}
		?>				
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item active"><span class="badge"><?php echo count($products); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 .col-md-offset-2 main-content">
			<ol class="breadcrumb">
			    <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			    <li class="active">Lichidari de stoc</li>
			</ol>		

		    <div class="row">
				<?php
				for($i=$page_start;$i<$page_end;$i++) {
				?>
		        <div class="col-sm-6 col-md-4">
					<div class="thumbnail">
					  <span class="label label-warning stoc-label">lichidare stoc</span>
					  <img src="<?php if(empty($products[$i]->IMAGINE)) { echo "http://placehold.it/300x200"; } else { echo HOME_PATH."img/imagini_produse/".$products[$i]->IMAGINE; } ?>" alt="image" class="product-thumbnail">
					  <div class="caption">
						<h3><?php echo $products[$i]->NUME; ?></h3>
						<p><?php if(strlen($products[$i]->NUME) > 22) { echo substr($products[$i]->DESCRIERE, 0, 100); } else { echo substr($products[$i]->DESCRIERE, 0, 150); }?>...</p>
						<p>
						<span class="price">Pret: <strong><?php echo $products[$i]->PRET_LICHIDARE_STOC; ?></strong> RON<br />
						<span class="producer">Producator: <strong><?php echo $products[$i]->PRODUCATOR; ?></strong></span> 
						<a href="<?php echo HOME_PATH."views/produs.php?product_id=".$products[$i]->ID_PRODUS; ?>" class="btn btn-default pull-right product-details" role="button">Detalii</a></p>
					  </div>
					</div>
				</div>
				<?php
				}
				?>
			</div>
			<?php 
			if($num_pages!=1) { 
				echo '<div id="pagination"><ul class="pagination center-block">';
					if($page==1) {
						echo '<li class="disabled"><span>&laquo;</span></li>';
					} 
					else {
						echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$prev_page.'">&laquo;</a></li>';
					}
				    for($i=1; $i<=$num_pages; $i++){ 
						if($i == $page) {
							echo '<li class="active"><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$i.'">'.$i.'</a></li>';
						}
						else {
						    echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$i.'">'.$i.'</a></li>';
						}
				    }
				    if($page==$num_pages) {
						echo '<li class="disabled"><span>&raquo;</span></li>';
					}
					else {
						echo '<li><a href="'.$_SERVER["SCRIPT_NAME"].'?page='.$next_page.'">&raquo;</a></li>';
					}
				echo '</ul></div>';
			} ?>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>