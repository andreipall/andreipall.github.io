<?php 
include $_SERVER['DOCUMENT_ROOT']."/fishing_shop/classes/config.php";
include $_SERVER['DOCUMENT_ROOT'].'/fishing_shop/data/helpers.php';
include SRV_PATH."views/header.php";
?>
	<article>
      	<div class="col-md-2 sidebar">
            <ul class="list-group">
				<a href="<?php echo HOME_PATH ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "PROMOTIE = 1 AND SYSDATE BETWEEN PROMOTIE_DATA_INCEPUT AND PROMOTIE_DATA_SFARSIT"); ?></span> Promotii</a>
				<a href="<?php echo HOME_PATH."views/lichidari_de_stoc.php"; ?>" class="list-group-item"><span class="badge"><?php echo $crud->count("DETALII_PRODUS", "CANTITATE < ".SELLOFFS_PROD); ?></span> Lichidari de stoc</a>
            </ul>
        </div>
        <div class="col-md-10 main-content">
			<ol class="breadcrumb">
			  <li><a href="<?php echo HOME_PATH ?>">Acasa</a></li>
			  <li class="active">Am uitat parola</li>
			</ol>		
		    <!-- Example row of columns -->
		    <div class="row">
				<div class="col-md-12">
				<?php 
				success_msg(); 
				error_msg(); 
				warning_msg(); ?>
				</div>
		      	<div class="col-md-4 col-md-offset-4">
					<h1 class="admin-title">Am uitat parola</h1><br /><br />
					<form action="<?php echo HOME_PATH."data/am_uitat_parola.php"; ?>" method="post" role="form" class="form-horizontal">
					  <div class="form-group">
						<label for="email" class="col-sm-2 control-label">Email</label>
						<div class="col-sm-10">
							<input type="email" name="email" class="form-control" id="email" placeholder="Email" required>
						</div>
					  </div>
					  <div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
						  <button type="submit" class="btn btn-default">Trimite</button>
						</div>
					  </div>
					</form>
				</div>
			</div>
        </div>
    </article>
<?php
include SRV_PATH."views/footer.php"; 
?>