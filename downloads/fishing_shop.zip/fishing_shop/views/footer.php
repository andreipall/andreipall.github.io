      <div class="clearfix"></div>
      <hr class="footer">

      <footer>
		  	<p>&copy; Fishing Shop 2014</p>
      </footer>
    </div> <!-- /container -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/fishing_shop/js/jquery-2.1.0.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/fishing_shop/lib/bootstrap/js/bootstrap.min.js"></script>
	<script src="/fishing_shop/js/bootstrap-datepicker.js"></script>
	<?php 
	$filename = SRV_PATH."js/script-".basename($_SERVER['SCRIPT_NAME'], '.php').".js"; 
	if (file_exists($filename)) {
		echo '<script src="/fishing_shop/js/script-'.basename($_SERVER['SCRIPT_NAME'], '.php').'.js"></script>';
	}
	
	Db_connect::closeConnection();
	?>
  </body>
</html>