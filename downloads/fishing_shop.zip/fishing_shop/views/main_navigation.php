<?php
require_once SRV_PATH.'classes/crud.php';

$crud = new Crud();
$top_categories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE IS NULL");
?>
<ul class="nav navbar-nav">
  <?php
  foreach($top_categories as $top_category) {
  ?>
  <li class="dropdown">
	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $top_category->NUME; ?> <b class="caret"></b></a>
	<?php
	  $categories = $crud->select(array("ID_CATEGORIE","ID_CATEGORIE_PARINTE","NUME","DESCRIERE"), array("CATEGORIE"), "ID_CATEGORIE_PARINTE = ".$top_category->ID_CATEGORIE);
	?>
	<ul class="dropdown-menu">
	  <?php
      foreach($categories as $category) {
      ?>
	  <li><a href="<?php echo HOME_PATH."views/categorie.php?category_id=".$category->ID_CATEGORIE; ?>"><?php echo $category->NUME; ?></a></li>
	  <?php
	  }
	  ?>
	</ul>
  </li>
  <?php
  }
  ?>
</ul>