package com.andreipall.single_table;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingleTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SingleTableApplication.class, args);
	}
}
