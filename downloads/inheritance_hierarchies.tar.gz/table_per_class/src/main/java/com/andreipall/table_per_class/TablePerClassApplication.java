package com.andreipall.table_per_class;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TablePerClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(TablePerClassApplication.class, args);
	}
}
