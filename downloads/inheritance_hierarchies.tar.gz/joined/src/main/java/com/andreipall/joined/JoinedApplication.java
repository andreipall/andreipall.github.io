package com.andreipall.joined;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoinedApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinedApplication.class, args);
	}
}
