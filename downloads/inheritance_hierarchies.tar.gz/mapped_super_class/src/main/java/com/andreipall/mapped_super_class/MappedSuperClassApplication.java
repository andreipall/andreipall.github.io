package com.andreipall.mapped_super_class;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MappedSuperClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(MappedSuperClassApplication.class, args);
	}
}
