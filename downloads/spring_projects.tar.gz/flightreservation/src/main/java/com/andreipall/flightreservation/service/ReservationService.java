package com.andreipall.flightreservation.service;

import com.andreipall.flightreservation.dto.ReservationRequest;
import com.andreipall.flightreservation.entity.Reservation;

public interface ReservationService {
	public Reservation bookFlight(ReservationRequest request);
}
