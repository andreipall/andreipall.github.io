package com.andreipall.flightreservation.service;

public interface SecurityService {
	boolean login(String username, String password);
}
