insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('AA1', 'American Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 03:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('AA2', 'American Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 05:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('AA3', 'American Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 07:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('SW1', 'South West', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 09:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('UA1', 'United Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 11:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('UA2', 'United Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 13:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('UA3', 'United Airlines', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 15:14:07');
insert into flight (flight_number, operating_airlines, departure_city, arrival_city, date_of_departure, estimated_departure_time) values ('SW2', 'South West', 'AUS', 'NYC', STR_TO_DATE('02-05-2018', '%m-%d-%Y'), '2018-02-05 17:14:07');

insert into role (name) values ('ADMIN');
insert into role (name) values ('USER');

insert into user_role (user_id, role_id) values (1, 1);
insert into user_role (user_id, role_id) values (1, 2);

INSERT INTO `user` (`id`, `email`, `first_name`, `last_name`, `password`) VALUES (1, 'test@test.com', 'afsad', 'dghdgh', '$2a$10$2vzd.QE3UJ.n.AQPfFhKi.VLDsRUmiwy8iEiA0yyFQepZDjmbsmOa');