package com.andreipall.studentdal.repository;

import org.springframework.data.repository.CrudRepository;

import com.andreipall.studentdal.entity.Student;

public interface StudentRepository extends CrudRepository<Student, Long> {

}
