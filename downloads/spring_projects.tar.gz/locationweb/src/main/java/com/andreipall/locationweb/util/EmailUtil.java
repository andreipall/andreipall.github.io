package com.andreipall.locationweb.util;

public interface EmailUtil {
	void sendEmail(String toAddress, String subject, String body);
}
