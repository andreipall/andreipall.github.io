$(document).ready(function() {
  $.each(jsonObject, function( i, item ) {
    var rows = '';
    $.each(item, function( iter, match_item ) {
      rows += '<tr><td>'+iter+'</td><td>'+match_item.avg_speed+'</td><td>'+match_item.distance+'</td><td>'+match_item.highspeed_runs+'</td><td>'+match_item.highspeed_runs_distance+'</td><td>'+match_item.max_speed+'</td><td>'+match_item.sprint_distance+'</td><td class="right aligned">'+match_item.sprints+'</td></tr>';
    });
    
    $("table.match:last").after('<h3>Match '+i+'</h3><table class="ui selectable inverted table match"><thead><tr><th>#</th><th>Average Speed</th><th>Distance</th><th>Highspeed Runs</th><th>Highspeed Runs Distance</th><th>Max Speed</th><th>Sprint Distance</th><th class="right aligned">Sprints</th></tr></thead><tbody>'+rows+'</tbody></table>');
  });
});
