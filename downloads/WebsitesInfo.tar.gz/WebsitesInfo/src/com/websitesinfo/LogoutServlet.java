package com.websitesinfo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

@SuppressWarnings("serial")
public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		HttpSession session = req.getSession(true);
		session.invalidate();
		Cookie c = new Cookie("userId", "");
		c.setMaxAge(0);
		resp.addCookie(c); 
		resp.sendRedirect("/login");
		return;

	}
}
