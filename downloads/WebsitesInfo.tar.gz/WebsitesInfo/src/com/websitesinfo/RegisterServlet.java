package com.websitesinfo;

import java.io.IOException;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.google.appengine.api.datastore.Text;

@SuppressWarnings("serial")
public class RegisterServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String confirm_password = req.getParameter("confirm_password");
		if (password.equals(confirm_password)) {
			PersistenceManager pm = PMF.get().getPersistenceManager();
			Query q = pm.newQuery(User.class);
			q.setFilter("email == emailParam");
			q.declareParameters("String emailParam");

			try {
				List<User> results = (List<User>) q.execute(email);
				if (!results.isEmpty()) {
					req.setAttribute("login_email", email);
					req.setAttribute("login_password", password);
					req.setAttribute("register_email", "");
					req.setAttribute("register_password", "");
					req.setAttribute("register_confirm_password", "");
					req.setAttribute("register_error", "This email address is already in use");
					ServletContext context = getServletContext();
					RequestDispatcher requestDispatcher = context
							.getRequestDispatcher("/login.jsp");
					requestDispatcher.forward(req, resp);
					return; 
				} else {
					User user = new User(email, password);

					try {
						pm.makePersistent(user);
					} finally {
						pm.close();
					}
					HttpSession session = req.getSession(true);
					session.setAttribute("userId", user.getId()); 

					Text txt = new Text("other information...");
					WebsiteRepositoryImpl websiteRepo = new WebsiteRepositoryImpl();
					websiteRepo.addWebsite(user.getId(), "www.website.com", "http://www.website.com", "username", "password", "website.com", 21, "username@website.com", "password", txt);
					resp.sendRedirect("/");
				}
			} finally {
				q.closeAll();
			}
		}
		else {
			req.setAttribute("login_email", "");
			req.setAttribute("login_password", "");
			req.setAttribute("register_email", email);
			req.setAttribute("register_password", password);
			req.setAttribute("register_confirm_password", confirm_password);
			req.setAttribute("register_error", "The password and confirmation password do not match");
			ServletContext context = getServletContext();
			RequestDispatcher requestDispatcher = context
					.getRequestDispatcher("/login.jsp");
			requestDispatcher.forward(req, resp);
		}
	}
}
