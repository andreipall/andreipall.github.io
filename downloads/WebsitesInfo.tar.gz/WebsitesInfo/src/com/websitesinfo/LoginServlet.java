package com.websitesinfo;

import java.io.IOException;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

@SuppressWarnings("serial")
public class LoginServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		// PrintWriter out=resp.getWriter();
		req.setAttribute("login_email", "");
		req.setAttribute("login_password", "");
		req.setAttribute("register_email", "");
		req.setAttribute("register_password", "");
		req.setAttribute("register_confirm_password", "");
		ServletContext context = getServletContext();
		RequestDispatcher requestDispatcher = context
				.getRequestDispatcher("/login.jsp");
		requestDispatcher.forward(req, resp);

	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		// PrintWriter out=resp.getWriter();
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		// out.println(email);
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Query q = pm.newQuery(User.class);
		q.setFilter("email == emailParam");
		q.declareParameters("String emailParam");

		try {
			List<User> results = (List<User>) q.execute(email);
			if (!results.isEmpty()) {
				for (User u : results) {
					// Process result p
					if (u.getPassword().equals(password)) {
						 HttpSession session = req.getSession(true);
						 session.setAttribute("userId", u.getId()); 
						 if(req.getParameter("remember_me") != null){  
							 Cookie c = new Cookie("userId", u.getId().toString());
							 c.setMaxAge(28 * 24 * 60 * 60);
							 resp.addCookie(c); 
						 }
						 resp.sendRedirect("/");
					}
					else {
						req.setAttribute("login_email", email);
						req.setAttribute("login_password", password);
						req.setAttribute("register_email", "");
						req.setAttribute("register_password", "");
						req.setAttribute("register_confirm_password", "");
						req.setAttribute("login_error", "Incorrect password");
						ServletContext context = getServletContext();
						RequestDispatcher requestDispatcher = context
								.getRequestDispatcher("/login.jsp");
						requestDispatcher.forward(req, resp);
						return; 
					}
				}
			} else {
				req.setAttribute("login_email", email);
				req.setAttribute("login_password", password);
				req.setAttribute("register_email", "");
				req.setAttribute("register_password", "");
				req.setAttribute("register_confirm_password", "");
				req.setAttribute("login_error", "Incorrect email or password");
				ServletContext context = getServletContext();
				RequestDispatcher requestDispatcher = context
						.getRequestDispatcher("/login.jsp");
				requestDispatcher.forward(req, resp);
				return; 
			}
		} finally {
			q.closeAll();
		}
	}
}
