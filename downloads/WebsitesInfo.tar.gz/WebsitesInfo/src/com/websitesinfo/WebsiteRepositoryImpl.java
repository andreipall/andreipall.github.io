package com.websitesinfo;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import com.google.appengine.api.datastore.Text;

public class WebsiteRepositoryImpl implements WebsiteRepository {

	@Override
	public Website getWebsite(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long addWebsite(Long userId, String name, String address,
			String user, String password, String ftp_host, int ftp_port,
			String ftp_user, String ftp_password, Text other_info) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Website website = new Website(userId, name, address);
		website.setUser(user);
		website.setPassword(password);
		website.setFtp_host(ftp_host);
		website.setFtp_port(ftp_port);
		website.setFtp_user(ftp_user);
		website.setFtp_password(ftp_password);
		website.setOther_info(other_info);
		try {
			pm.makePersistent(website);
		} finally {
			pm.close();
		}
		return website.getId();
	}

	@Override
	public void updateWebsite(Long id, String name, String address, String user,
			String password, String ftp_host, int ftp_port, String ftp_user,
			String ftp_password, Text other_info) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Website website = pm.getObjectById(Website.class, id);
		website.setName(name);
		website.setAddress(address);
		website.setUser(user);
		website.setPassword(password);
		website.setFtp_host(ftp_host);
		website.setFtp_port(ftp_port);
		website.setFtp_user(ftp_user);
		website.setFtp_password(ftp_password);
		website.setOther_info(other_info);
		try {
            pm.makePersistent(website);
        } finally {
            pm.close();
        }
	}

	@Override
	public void removeWebsite(Long id) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Website website = pm.getObjectById(Website.class, id);
		try {
            pm.deletePersistent(website);
        } finally {
            pm.close();
        }
	}

	@Override
	public List<Website> listWebsites(Long userId) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Query q = pm.newQuery(Website.class);
		q.setFilter("userId == userIdParam");
		q.declareParameters("String userIdParam");

		try {
			List<Website> results = (List<Website>) q.execute(userId);
			return results;
		} finally {
			q.closeAll();
		}
	}

}
