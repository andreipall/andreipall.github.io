package com.websitesinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.appengine.api.datastore.Text;

@SuppressWarnings("serial")
public class AddWebsiteServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		HttpSession session = req.getSession(true);
		Long userId = Long.parseLong(session.getAttribute("userId").toString()); 
		String name = req.getParameter("name");
		String address = req.getParameter("address");
		String user = req.getParameter("user");
		String password = req.getParameter("password"); 
		String ftp_host = req.getParameter("ftp_host");
		int ftp_port = 21;
		if(req.getParameter("ftp_port")!="") {
			ftp_port = Integer.parseInt(req.getParameter("ftp_port"));
		}
		String ftp_user = req.getParameter("ftp_user");
		String ftp_password = req.getParameter("ftp_password");
		Text other_info = new Text(req.getParameter("other_info").toString());
		WebsiteRepositoryImpl websiteRepo = new WebsiteRepositoryImpl();
		Long id = websiteRepo.addWebsite(userId, name, address, user, password, ftp_host, ftp_port, ftp_user, ftp_password, other_info);
		try {
	        resp.setContentType("application/json");
	        PrintWriter out = resp.getWriter();
	        out.println("{");
	        out.println("\"id\": \""+id+"\"");
	        out.println("}");
	        out.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}
