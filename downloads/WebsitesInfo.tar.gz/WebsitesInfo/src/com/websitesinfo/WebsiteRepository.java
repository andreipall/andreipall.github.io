package com.websitesinfo;

import java.util.List;

public interface WebsiteRepository {
	Website getWebsite(Long id);
	Long addWebsite(Long userId, String name, String address, String user, String password, String ftp_host, int ftp_port, String ftp_user, String ftp_password, com.google.appengine.api.datastore.Text other_info);
	void updateWebsite(Long id, String name, String address, String user, String password, String ftp_host, int ftp_port, String ftp_user, String ftp_password, com.google.appengine.api.datastore.Text other_info);
	void removeWebsite(Long id);
	List<Website> listWebsites(Long userId);
}
