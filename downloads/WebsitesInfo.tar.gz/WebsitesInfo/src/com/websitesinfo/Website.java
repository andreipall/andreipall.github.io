package com.websitesinfo;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable
public class Website {
	@PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
    private Long id;
	
	@Persistent
    private Long userId;
	
	@Persistent
    private String name;
	
	@Persistent
    private String address;
    
    @Persistent
    private String user;
    
    @Persistent
    private String password;

    @Persistent
    private String ftp_host;
    
    @Persistent
    private int ftp_port;
    
    @Persistent
    private String ftp_user;
    
    @Persistent
    private String ftp_password;
    
    @Persistent
    private com.google.appengine.api.datastore.Text other_info;
    
    public Website(Long userId, String name, String address) {
    	this.userId = userId;
    	this.name = name;
        this.address = address;
    }

    // Accessors for the fields. JDO doesn't use these, but your application does.

    public Long getId() {
        return id;
    }

    public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFtp_host() {
		return ftp_host;
	}

	public void setFtp_host(String ftp_host) {
		this.ftp_host = ftp_host;
	}

	public int getFtp_port() {
		return ftp_port;
	}

	public void setFtp_port(int ftp_port) {
		this.ftp_port = ftp_port;
	}

	public String getFtp_user() {
		return ftp_user;
	}

	public void setFtp_user(String ftp_user) {
		this.ftp_user = ftp_user;
	}

	public String getFtp_password() {
		return ftp_password;
	}

	public void setFtp_password(String ftp_password) {
		this.ftp_password = ftp_password;
	}

	public String getOther_info() {
		return other_info.getValue();
	}

	public void setOther_info(com.google.appengine.api.datastore.Text other_info) {
		this.other_info = other_info;
	}
}
