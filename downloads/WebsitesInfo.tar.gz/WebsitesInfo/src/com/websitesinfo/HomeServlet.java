package com.websitesinfo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

@SuppressWarnings("serial")
public class HomeServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		HttpSession session = req.getSession(true);
		if (session.getAttribute("userId") == null) {
			Cookie[] cookies = req.getCookies();
			
			String userId = null;
			if (cookies != null) {
				for(Cookie cookie : cookies){
				    if("userId".equals(cookie.getName())){
				        userId = cookie.getValue();
				    }
				}
			}
			session.setAttribute("userId", userId); 
		}
		ServletContext context = getServletContext();
		if (session.getAttribute("userId") != null) {
			Long userId = Long.parseLong(session.getAttribute("userId").toString());
			WebsiteRepositoryImpl websiteRepo = new WebsiteRepositoryImpl();
			req.setAttribute("websites", websiteRepo.listWebsites(userId));
			RequestDispatcher requestDispatcher = context
					.getRequestDispatcher("/home.jsp");
			requestDispatcher.forward(req, resp);
		}
		else {
			RequestDispatcher requestDispatcher = context
					.getRequestDispatcher("/index.jsp");
			requestDispatcher.forward(req, resp);
		}
	}
}
