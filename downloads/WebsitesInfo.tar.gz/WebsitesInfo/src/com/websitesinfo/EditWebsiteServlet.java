package com.websitesinfo;

import java.io.IOException;

import javax.jdo.PersistenceManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.appengine.api.datastore.Text;

@SuppressWarnings("serial")
public class EditWebsiteServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		resp.setContentType("text/html");
		Long id = Long.parseLong(req.getParameter("id"));
		String name = req.getParameter("name");
		String address = req.getParameter("address");
		String user = req.getParameter("user");
		String password = req.getParameter("password"); 
		String ftp_host = req.getParameter("ftp_host");
		int ftp_port = 21;
		if(req.getParameter("ftp_port")!="") {
			ftp_port = Integer.parseInt(req.getParameter("ftp_port"));
		}
		String ftp_user = req.getParameter("ftp_user");
		String ftp_password = req.getParameter("ftp_password");
		Text other_info = new Text(req.getParameter("other_info").toString());
		WebsiteRepositoryImpl websiteRepo = new WebsiteRepositoryImpl();
		websiteRepo.updateWebsite(id, name, address, user, password, ftp_host, ftp_port, ftp_user, ftp_password, other_info);
	}
}
