$( document ).ready(function() {
	$("#add-website").click(function() {
		var name = $('#name').val();
		var address = $('#address').val();
		var user = $('#user').val();
		var password = $('#password').val();
		var ftp_host = $('#ftp_host').val();
		var ftp_port = $('#ftp_port').val();
		var ftp_user = $('#ftp_user').val();
		var ftp_password = $('#ftp_password').val();
		var other_info = $('#other_info').val();
		
		$.post("/add_website", { name: name, address: address, user: user, password: password, ftp_host: ftp_host, ftp_port: ftp_port, ftp_user: ftp_user, ftp_password: ftp_password, other_info: other_info }, function( data ) {
			$("<li id=\'website-"+data.id+"\' class=\'list-group-item\'>" +
				"<div class=\'pull-left\'>" +
					"<h4 id=\'"+data.id+"\' class=\'website\' data-toggle=\'modal\' data-target=\'#websiteModal"+data.id+"\'>"+name+"<\/h4>" +
					"<div class=\"modal fade\" id=\"websiteModal"+data.id+"\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">" +
						"<div class=\"modal-dialog\">" +
							"<div class=\"modal-content\">" +
								"<form class=\"website_form\" role=\"form\">" +
									"<div class=\"modal-header\">" +
										"<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;<\/button>" +
										"<h4 class=\"modal-title\" id=\"myModalLabel\">Edit website<\/h4>" +
									"<\/div>" +
									"<div class=\"modal-body\">" +
										"<div class=\"form-group\">" +
											"<label for=\"name\">Website name<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"name\" required=\"required\" placeholder=\"Name\" value=\""+name+"\">" +
										"<\/div>" +
										"<div class=\"form-group\">" +
											"<label for=\"address\">Website address<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"address\" required=\"required\" placeholder=\"URL\" value=\""+address+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 left\">" +
											"<label for=\"user\">User name or email<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"user\" placeholder=\"User or email\" value=\""+user+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 right\">" +
											"<label for=\"password\">Password<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"password\" placeholder=\"Password\" value=\""+password+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-10 left\">" +
											"<label for=\"ftp_host\">FTP host<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_host\" placeholder=\"Host\" value=\""+ftp_host+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-2 right\">" +
											"<label for=\"ftp_port\">FTP port<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_port\" placeholder=\"Port\" value=\""+ftp_port+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 left\">" +
											"<label for=\"ftp_user\">FTP user<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_user\" placeholder=\"User\" value=\""+ftp_user+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 right\">" +
											"<label for=\"ftp_password\">FTP password<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_password\" placeholder=\"Password\" value=\""+ftp_password+"\">" +
										"<\/div>" +
										"<div class=\"form-group\">" +
											"<label for=\"other_info\">Other info<\/label>" +
											"<textarea class=\"form-control\" rows=\"3\" id=\"other_info\">"+other_info+"<\/textarea>" +
										"<\/div>" +
									"<\/div>" +
									"<div class=\"modal-footer\">" +
										"<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close<\/button>" +
										"<button type=\"button\" id=\'"+data.id+"\' class=\"btn btn-primary save-changes\">Save changes<\/button>" +
									"<\/div>" +
								"<\/form>" +
							"<\/div>" +
						"<\/div>" +
					"<\/div>" +
					"<a href=\'"+address+"\' target=\"_blank\">"+address+"<\/a>" +
				"<\/div>" +
				"<button type=\'button\' class=\'close\' aria-hidden=\'true\'>&times;<\/button>" +
				"<div class=\'clearfix\'><\/div>" +
			  "<\/li>").insertAfter("#websites-list li:last");
			
			$("#addWebsiteModal :input").each(function(){
				$(this).val('');
			});
			$("#addWebsiteModal").modal('hide');
		}, "json");
	});
	
	$(".save-changes").click(function() {
		var id = $(this).attr('id');
		var name = $('#websiteModal'+id+' #name').val();
		var address = $('#websiteModal'+id+' #address').val();
		var user = $('#websiteModal'+id+' #user').val();
		var password = $('#websiteModal'+id+' #password').val();
		var ftp_host = $('#websiteModal'+id+' #ftp_host').val();
		var ftp_port = $('#websiteModal'+id+' #ftp_port').val();
		var ftp_user = $('#websiteModal'+id+' #ftp_user').val();
		var ftp_password = $('#websiteModal'+id+' #ftp_password').val();
		var other_info = $('#websiteModal'+id+' #other_info').val();

		$.post("/edit_website", { id: id, name: name, address: address, user: user, password: password, ftp_host: ftp_host, ftp_port: ftp_port, ftp_user: ftp_user, ftp_password: ftp_password, other_info: other_info })
		.done(function() {
			$("#website-"+id).replaceWith("<li id=\'website-"+id+"\' class=\'list-group-item\'>" +
				"<div class=\'pull-left\'>" +
					"<h4 id=\'"+id+"\' class=\'website\' data-toggle=\'modal\' data-target=\'#websiteModal"+id+"\'>"+name+"<\/h4>" +
					"<div class=\"modal fade\" id=\"websiteModal"+id+"\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">" +
						"<div class=\"modal-dialog\">" +
							"<div class=\"modal-content\">" +
								"<form class=\"website_form\" role=\"form\">" +
									"<div class=\"modal-header\">" +
										"<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;<\/button>" +
										"<h4 class=\"modal-title\" id=\"myModalLabel\">Edit website<\/h4>" +
									"<\/div>" +
									"<div class=\"modal-body\">" +
										"<div class=\"form-group\">" +
											"<label for=\"name\">Website name<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"name\" required=\"required\" placeholder=\"Name\" value=\""+name+"\">" +
										"<\/div>" +
										"<div class=\"form-group\">" +
											"<label for=\"address\">Website address<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"address\" required=\"required\" placeholder=\"URL\" value=\""+address+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 left\">" +
											"<label for=\"user\">User name or email<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"user\" placeholder=\"User or email\" value=\""+user+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 right\">" +
											"<label for=\"password\">Password<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"password\" placeholder=\"Password\" value=\""+password+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-10 left\">" +
											"<label for=\"ftp_host\">FTP host<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_host\" placeholder=\"Host\" value=\""+ftp_host+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-2 right\">" +
											"<label for=\"ftp_port\">FTP port<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_port\" placeholder=\"Port\" value=\""+ftp_port+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 left\">" +
											"<label for=\"ftp_user\">FTP user<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_user\" placeholder=\"User\" value=\""+ftp_user+"\">" +
										"<\/div>" +
										"<div class=\"form-group col-xs-6 right\">" +
											"<label for=\"ftp_password\">FTP password<\/label>" +
											"<input type=\"text\" class=\"form-control\" id=\"ftp_password\" placeholder=\"Password\" value=\""+ftp_password+"\">" +
										"<\/div>" +
										"<div class=\"form-group\">" +
											"<label for=\"other_info\">Other info<\/label>" +
											"<textarea class=\"form-control\" rows=\"3\" id=\"other_info\">"+other_info+"<\/textarea>" +
										"<\/div>" +
									"<\/div>" +
									"<div class=\"modal-footer\">" +
										"<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close<\/button>" +
										"<button type=\"button\" id=\'"+id+"\' class=\"btn btn-primary save-changes\">Save changes<\/button>" +
									"<\/div>" +
								"<\/form>" +
							"<\/div>" +
						"<\/div>" +
					"<\/div>" +
					"<a href=\'"+address+"\' target=\"_blank\">"+address+"<\/a>" +
				"<\/div>" +
				"<button type=\'button\' class=\'close\' aria-hidden=\'true\'>&times;<\/button>" +
				"<div class=\'clearfix\'><\/div>" +
			  "<\/li>");
			$("#websiteModal"+id).modal('hide');
			$('.modal-backdrop').remove();
		});
	});
	$("#websites-list li .close").click(function() {
		var deleteModal = $(this).attr('data-target');
		$(deleteModal).modal('show');
	});
	$("#websites-list li .delete-website").click(function() {
		var id = $(this).attr('id').slice(7);
		$.post("/delete_website", { id: id })
		.done(function() {
			$('#delete-website-'+id).modal('hide');
		});
		$("#website-"+id).remove();
		$('.modal-backdrop').remove();
	});
});