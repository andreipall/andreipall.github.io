$(document).ready(function() {
  $('.ui.dropdown').dropdown();
  $('.ui.checkbox').checkbox();
  $('.ui.form')
  .form({
    comment: {
      identifier  : 'comment',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your comment'
        }
      ]
    },
    search_input: {
      identifier  : 'search-input',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter a search term'
        }
      ]
    },
    first_name: {
      identifier  : 'first_name',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your first name'
        }
      ]
    },
    last_name: {
      identifier  : 'last_name',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your last name'
        }
      ]
    },
    username: {
      identifier  : 'username',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your username'
        }
      ]
    },
    message: {
      identifier  : 'message',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter a message'
        }
      ]
    },
    email: {
      identifier : 'email',
      rules: [
        {
          type   : 'email',
          prompt : 'Please enter a valid email address'
        }
      ]
    },
    password: {
      identifier : 'password',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter a password'
        },
        {
          type   : 'length[6]',
          prompt : 'Your password must be at least 6 characters'
        }
      ]
    },
    form_first_name: {
      identifier  : 'form_first_name',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your first name'
        }
      ]
    },
    form_last_name: {
      identifier  : 'form_last_name',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your last name'
        }
      ]
    },
    form_username: {
      identifier  : 'form_username',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter your username'
        }
      ]
    },
    form_email: {
      identifier : 'form_email',
      rules: [
        {
          type   : 'email',
          prompt : 'Please enter a valid email address'
        }
      ]
    },
    form_password_first: {
      identifier : 'form_password_first',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter a password'
        },
        {
          type   : 'length[6]',
          prompt : 'Your password must be at least 6 characters'
        }
      ]
    },
    form_password_second: {
      identifier : 'form_password_second',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please confirm your password'
        },
        {
          type   : 'match[form_password_first]',
          prompt : 'Password doesn\'t match'
        }
      ]
    },
    terms: {
      identifier : 'terms',
      rules: [
        {
          type   : 'checked',
          prompt : 'You must agree to the terms and conditions'
        }
      ]
    }
  });
  $('a.confirm.delete').click(function(event) {
    event.preventDefault();
    var url = $(this).attr('href');
    var title = $(this).attr('title');
    $('#name').html(title);
    $('.small.modal').modal({
        onApprove: function () {
            $.ajax({
                url: url,
                type: 'DELETE'/*,
                success: function(result) {
                }*/
            });
            //location.reload();
	    window.location.href = window.location.href;
        }
    }).modal('show');
  });
  $(".reply-link").click(function() {
    if(!$(this).hasClass("active")) {
      $(this).addClass("active");
      var parent = $(this).parent();
      var parentId = parent.attr('id');
      var slug = parent.attr("slug");
      $('<form method="post" action="/blog/comment/new" class="ui reply form"><div class="field"><input type="hidden" value="' + slug + '" name="slug"><input type="hidden" value="' + parentId + '" name="parent"><textarea id="comment" name="body"></textarea></div><button class="ui button submit labeled icon" type="submit"><i class="icon edit"></i>Add Comment</button></form>').insertAfter(parent);
      $('.ui.form')
        .form({
          comment: {
            identifier  : 'comment',
            rules: [
              {
                type   : 'empty',
                prompt : 'Please enter your comment'
              }
            ]
          }
       });
    }
  });
  $('.vote').on('click', function()
  {
      var me = $(this);
      //You can also set some attribute value if you do not want to use class
      if(me.hasClass('voted'))
      {
          return false;
      }
      else
      {
          var id = me.attr('id');
          $.get("/portfolio/website/vote/" + id, function(response) {
              me.addClass('voted teal');
              $("#votes_"+id).html(response.votes);
          });
          
      }
  });
  $('#avatars img').on('click', function()
  {
      $('#avatars img').css('border-color', 'rgba(0, 0, 0, 0.1)');
      $(this).css('border-color', '#555555');
      $('#avatar').val($(this).attr('id'));
  });
  $('.message .close').on('click', function() {
    $(this).closest('.message').fadeOut();
  });
  $("#search_users").keyup(function() {
      var name = $(this).val();
      if (!$('#add_friend_button').hasClass("disabled")) {
	      $('#add_friend_button').addClass("disabled");
      };
      
      $("#found_users").html('');
      $.get("/admin/friends/get/" + name, function( data ) {
	      jQuery.each( data.usernames, function( i, user ) {
	        $("#found_users").append('<div class="item">'+user.username+'</div>');
	      });
	      $("#found_users .item").on('click', function() {
	        $("#search_users").val($(this).html());
	        $('.ui.dropdown.select_users_dropdown').dropdown('hide');
	        $("#found_users").html('');
	        $('#add_friend_button').removeClass("disabled").on('click', function() {
	          $("#add_friend").submit();
	        });
	      });
	      $('.ui.dropdown.select_users_dropdown').dropdown('show');
      });
  });
  $('#search-button').on('click', function() {
    $("#search-form").submit();
  });
});
