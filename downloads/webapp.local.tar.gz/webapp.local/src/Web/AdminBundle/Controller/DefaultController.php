<?php

namespace Web\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Web\BlogBundle\Entity\Activity;
use Web\BlogBundle\Entity\Message;

class DefaultController extends Controller
{
    /**
     * @Route("/dashboard")
     * @Template()
     */
    public function indexAction()
    {
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        
        return array('webapps' => $webapps, 'user' => $this->getUser());
    }
    
    /**
     * Profile
     *
     * @Route("/profile")
     *
     * @Template()
     */
    public function profileAction()
    {
        $request = $this->getRequest();
        $current_user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $user = $em->getRepository('WebBlogBundle:User')->findOneById($current_user->getId());
        if($request->getMethod() == "POST") {
          $avatar = $request->request->get('avatar');
          
          $user->setAvatar($avatar);
            
          $em->persist($user);

	  $activity = new Activity();
	  $activity->setAuthor($current_user);
	  $activity->setContent('You changed your profile picture');
	  $activity->setExtra('<img src="/images/avatars/'.$avatar.'">');
	  $activity->setType('photo');
	  $em->persist($activity);
          $em->flush();
          
          $this->get('session')->getFlashBag()->add(
              'notice',
              'Your profile has been updated successfully!'
          );
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('user' => $user, 'webapps' => $webapps);
    }
    
    /**
     * Account Settings
     *
     * @Route("/account-settings")
     * 
     * @Template()
     */
    public function accountAction()
    {
        $request = $this->getRequest();
        $current_user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $user = $em->getRepository('WebBlogBundle:User')->findOneById($current_user->getId());
        $factory = $this->get('security.encoder_factory');
        $encoder = $factory->getEncoder($user);
        $form = $this->createFormBuilder($user)
            ->add('first_name', 'text', array('attr' => array('placeholder' => 'First Name',),'label' => 'First Name',))
            ->add('last_name', 'text', array('attr' => array('placeholder' => 'Last Name',),'label' => 'Last Name',))
            ->add('email', 'email', array('attr' => array('placeholder' => 'Email',)))
            ->add('username', 'text', array('attr' => array('placeholder' => 'Username',)))
            ->add('password', 'repeated', array(
                'type' => 'password',
                'invalid_message' => 'The password fields must match.',
                'options' => array('attr' => array('class' => 'password-field')),
                'required' => true,
                'first_options'  => array('attr' => array('placeholder' => 'Password',),'label' => 'Password'),
                'second_options' => array('attr' => array('placeholder' => 'Confirm Password',),'label' => 'Confirm Password'),
            ))
            ->add('save', 'submit', array('label' => 'Update'))
            ->getForm();
        
        $form->handleRequest($request);

        if ($form->isValid()) {
            $pasword = $encoder->encodePassword($user->getPassword(), null);
            $user->setPassword($pasword);
            
            $em->persist($user);
            $em->flush();

            return $this->redirect($this->generateUrl('web_admin_security_logout'));
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return $this->render('AdminBundle:Default:account.html.twig', array(
            'form' => $form->createView(), 'webapps' => $webapps, 'user' => $this->getUser()
        ));
    }
    
    /**
     * @Route("/friends")
     * @Template()
     */
    public function friendsAction()
    {
	$request = $this->getRequest();
	if ($request->getMethod() == 'POST') {
	    $username = $request->request->get('username');
	    $current_user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $user = $em->getRepository('WebBlogBundle:User')->findOneByUsername($username);
          
        $current_user->addMyFriend($user);
	    $current_user->addFriendsWithMe($user);
            
	    $activity = new Activity();
	    $activity->setAuthor($current_user);
	    $activity->setContent('You added '.$user->getFirstName().' '.$user->getLastName().' as a friend');
	    $activity->setType('user-request');
	    $em->persist($activity);
	    
	    $activity1 = new Activity();
	    $activity1->setAuthor($user);
	    $activity1->setContent($current_user->getFirstName().' '.$current_user->getLastName().' added you as a friend');
	    $activity1->setType('user-request');	
	    $em->persist($activity1);
            $em->flush();
          
            $this->get('session')->getFlashBag()->add(
                'notice',
                'Your friend request has been sent successfully!'
            );
	}
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);

        return array('webapps' => $webapps, 'user' => $this->getUser());
    }
    
    /**
     * Removes a User friend.
     *
     * @Route("/friends/delete/{id}")
     * @Method("DELETE")
     */
    public function removeFriendAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $friend = $em->getRepository('WebBlogBundle:User')->find($id);
        
        if (!$friend) {
            throw $this->createNotFoundException('Unable to find User entity.');
        }
        $user = $this->getUser();
        $user->removeMyFriend($friend);
	    $user->removeFriendsWithMe($friend);
        $em->flush();
        
        $this->get('session')->getFlashBag()->add(
            'notice',
            'Your friend has been removed successfully from the list!'
        );
        return $this->redirect($this->generateUrl('web_admin_default_friends'));
    }
    
    /**
     * @Route("/messages")
     * @Template()
     */
    public function messagesAction()
    {
        $request = $this->getRequest();
        $current_user = $this->getUser();
        $users = $current_user->getMyFriends();
        $my_users = $current_user->getFriendsWithMe();
        $em = $this->getDoctrine()->getManager();
        $user_ids = [];
        $user_ids[] = $current_user->getId();
        foreach($users as $user) {
            $user_ids[] = $user->getId();
        }
        foreach($my_users as $user) {
            $user_ids[] = $user->getId();
        }
        $user_ids = array_unique($user_ids);
	    if ($request->getMethod() == 'POST') {
	        $text = $request->request->get('message');
            $message = new Message();
	        $message->setAuthor($current_user);
	        $message->setText($text);
	        $em->persist($message);
	        $em->flush();
        }
        $messages = $em->getRepository('WebBlogBundle:Message')->getMessages($user_ids);
        $webapps = $em->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        
        return array('webapps' => $webapps, 'user' => $this->getUser(), 'messages' => $messages);
    }
    
    /**
     * @param string $id
     *
     * @throws NotFoundHttpException
     *
     * @Route("/friends/get/{name}")
     */
    public function getUsersAction($name)
    {
        $em = $this->getDoctrine()->getManager();
	    $current_user = $this->getUser()->getUsername();
        $users = $em->getRepository('WebBlogBundle:User')->getUsersByUsername($name, $current_user);

        if (!$users) {
            throw $this->createNotFoundException(
                'No user found for name '.$name
            );
        }

        return new JsonResponse(array('usernames' => $users));
    }
}
