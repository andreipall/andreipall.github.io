<?php

namespace Web\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Web\BlogBundle\Entity\Category;
use Web\BlogBundle\Form\CategoryType;

/**
 * Category controller.
 *
 * @Route("/categories")
 */
class CategoryController extends Controller
{

    /**
     * Lists all Category entities.
     *
     * @Route("/")
     * @Method("GET")
     * @Template()
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('WebBlogBundle:Category')->findAll();
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array(
            'entities' => $entities, 'webapps' => $webapps, 'user' => $this->getUser()
        );
    }
    /**
     * Creates a new Category entity.
     *
     * @Route("/")
     * @Method("POST")
     * @Template("WebAdminBundle:Category:new.html.twig")
     */
    public function createAction(Request $request)
    {
        $entity = new Category();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('web_admin_category_index'));
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'webapps' => $webapps, 'user' => $this->getUser()
        );
    }

    /**
     * Creates a form to create a Category entity.
     *
     * @param Category $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm(Category $entity)
    {
        $form = $this->createForm(new CategoryType(), $entity, array(
            'action' => $this->generateUrl('web_admin_category_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => 'Create'));

        return $form;
    }

    /**
     * Displays a form to create a new Category entity.
     *
     * @Route("/new")
     * @Method("GET")
     * @Template()
     */
    public function newAction()
    {
        $entity = new Category();
        $form   = $this->createCreateForm($entity);
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'webapps' => $webapps, 'user' => $this->getUser()
        );
    }

    /**
     * Displays a form to edit an existing Category entity.
     *
     * @Route("/{id}/edit")
     * @Method("GET")
     * @Template()
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('WebBlogBundle:Category')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Category entity.');
        }

        $editForm = $this->createEditForm($entity);
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'webapps'     => $webapps, 'user' => $this->getUser()
        );
    }

    /**
    * Creates a form to edit a Category entity.
    *
    * @param Category $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(Category $entity)
    {
        $form = $this->createForm(new CategoryType(), $entity, array(
            'action' => $this->generateUrl('web_admin_category_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => 'Update'));

        return $form;
    }
    /**
     * Edits an existing Category entity.
     *
     * @Route("/{id}")
     * @Method("PUT")
     * @Template("WebAdminBundle:Category:edit.html.twig")
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('WebBlogBundle:Category')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Category entity.');
        }

        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('web_admin_category_index'));
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'webapps'     => $webapps, 'user' => $this->getUser()
        );
    }
    /**
     * Deletes a Category entity.
     *
     * @Route("/{id}")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $entity = $em->getRepository('WebBlogBundle:Category')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Category entity.');
        }

        $em->remove($entity);
        $em->flush();
            
        return $this->redirect($this->generateUrl('web_admin_category_index'));
    }
}
