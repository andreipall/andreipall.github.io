<?php

namespace Web\BlogBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class CategoryControllerTest extends WebTestCase
{
    public function testCompleteScenario()
    {
        // Create a new client to browse the application
        $client = static::createClient(array(), array(
            'PHP_AUTH_USER' => 'andreipall',
            'PHP_AUTH_PW' => 'eclipse'
        ));

        // Create a new entry in the database
        $crawler = $client->request('GET', '/admin/categories/');
        $this->assertTrue($client->getResponse()->isSuccessful(), "Unexpected HTTP status code for GET /admin/categories/");
    }
}
