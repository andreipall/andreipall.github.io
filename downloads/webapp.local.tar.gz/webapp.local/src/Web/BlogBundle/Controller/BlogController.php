<?php

namespace Web\BlogBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Web\BlogBundle\Entity\Comment;
use Web\BlogBundle\Entity\Activity;

class BlogController extends Controller
{
    /**
     * @param string $slug
     *
     * @throws NotFoundHttpException
     * @return array
     *
     * @Route("/blog/{slug}")
     * @Template()
     */
    public function indexAction($slug)
    {
        $post = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findOneBy(array('slug' => $slug));
        if($post === null) {
            throw $this->createNotFoundException('Post was not found');
        }
        $categories = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findAll();
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('post' => $post, 'categories' => $categories, 'webapps' => $webapps);
    }
    
    /**
     * @Route("/blog")
     * @Template()
     */
    public function listAction()
    {
        $posts = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findLatest();
        $categories = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findAll();
        
        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $posts,
            $this->get('request')->query->get('page', 1)/*page number*/,
            6/*limit per page*/
        );
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('posts' => $posts, 'categories' => $categories, 'pagination' => $pagination, 'webapps' => $webapps);
    }
    
    /**
     * @Route("/blog-a-z")
     * @Template()
     */
    public function listByNameAction()
    {
        $posts = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findLatestByName();
        $categories = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findAll();
        
        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $posts,
            $this->get('request')->query->get('page', 1)/*page number*/,
            6/*limit per page*/
        );
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('posts' => $posts, 'categories' => $categories, 'pagination' => $pagination, 'webapps' => $webapps);
    }
    
    /**
     * @Route("/blog/category/{slug}")
     * @Template()
     */
    public function listByCategoryAction($slug)
    {
        $posts = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findOneBySlug($slug)->getPosts();
        $categories = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findAll();
        
        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $posts,
            $this->get('request')->query->get('page', 1)/*page number*/,
            6/*limit per page*/
        );
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('posts' => $posts, 'categories' => $categories, 'pagination' => $pagination, 'webapps' => $webapps);
    }
    
    /**
     * Creates a new Comment entity.
     *
     * @Route("/blog/comment/new")
     * @Method("POST")
     */
    public function newCommentAction(Request $request)
    {   
        $slug = $request->request->get('slug');
        $body = $request->request->get('body');
        
        $post = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findOneBy(array('slug' => $slug));
        $comment = new Comment();
        $comment->setPost($post);
        $comment->setBody($body);
        if(!empty($request->request->get('parent'))) {
          $id = $request->request->get('parent');
          
          $parent_comment = $this->getDoctrine()->getRepository('WebBlogBundle:Comment')->find($id);

          if (!$parent_comment) {
              throw $this->createNotFoundException(
                  'No comment found for id '.$id
              );
          }
          $comment->setParent($parent_comment);
        }
        
        $comment->setAuthor($this->getUser());
        $em = $this->getDoctrine()->getManager();
        $em->persist($comment);

	    $current_user = $this->getUser();
	    $activity = new Activity();
	    $activity->setAuthor($current_user);
	    $url = $this->generateUrl('web_blog_blog_index', array('slug' => $slug));
	    $activity->setContent('You submitted a new comment to the page <a href="'.$url.'">'.$post->getName().'</a>');
	    $activity->setExtra($body);
	    $activity->setType('post');
	    $em->persist($activity);
        $em->flush();
        
        $this->get('session')->getFlashBag()->add(
            'notice',
            'Your comment has been added successfully!'
        );
        return $this->redirect($this->generateUrl('web_blog_blog_index', array('slug' => $slug)));
    }
    
    /**
     * @param string $id
     *
     * @throws NotFoundHttpException
     *
     * @Route("/blog/comment/delete/{id}")
     */
    public function deleteCommentAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $comment = $em->getRepository('WebBlogBundle:Comment')->find($id);

        if (!$comment) {
            throw $this->createNotFoundException(
                'No comment found for id '.$id
            );
        }
        $slug = $comment->getPost()->getSlug();
        $em->remove($comment);
        $em->flush();
        
        $this->get('session')->getFlashBag()->add(
            'notice',
            'Your comment has been deleted successfully!'
        );
        return $this->redirect($this->generateUrl('web_blog_blog_index', array('slug' => $slug)));
    }
}
