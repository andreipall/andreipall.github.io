<?php

namespace Web\BlogBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\SecurityContext;

class HomeController extends Controller
{
    /**
     * @Route("/")
     * @Template()
     */
    public function indexAction()
    {
        $request = $this->getRequest();
        $session = $request->getSession();
        
        // get the login error if there is one
        if ($request->attributes->has(SecurityContext::AUTHENTICATION_ERROR)) {
            $error = $request->attributes->get(SecurityContext::AUTHENTICATION_ERROR);
        }
        else {
            $error = $session->get(SecurityContext::AUTHENTICATION_ERROR);
            $session->remove(SecurityContext::AUTHENTICATION_ERROR);
        }
        $posts = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findLatestNPosts(3);
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('posts' => $posts, 'webapps' => $webapps, 'last_username' => $session->get(SecurityContext::LAST_USERNAME), 'error' => $error);
    }
    
    /**
     * @Route("/search")
     * @Template()
     */
    public function searchAction()
    {
        $request = $this->getRequest();

        $term = $request->request->get('term');
        $search_results = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findByTerm($term);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $search_results,
            $this->get('request')->query->get('page', 1)/*page number*/,
            6/*limit per page*/
        );
        $posts = $this->getDoctrine()->getRepository('WebBlogBundle:Post')->findLatestNPosts(3);
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        $categories = $this->getDoctrine()->getRepository('WebBlogBundle:Category')->findAll();
        return array('posts' => $posts, 'categories' => $categories, 'webapps' => $webapps, 'search_results' => $search_results, 'pagination' => $pagination, 'term' => $term);
    }
    
    /**
     * @Route("/portfolio")
     * @Template()
     */
    public function portfolioAction()
    {
        $now = new \DateTime('now');
        $websites = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findAll();
        foreach($websites as &$website) {
          $difference = $now->diff($website->getDate());
          $difference = $difference->format('%a');
          $website->setDays($difference);
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('websites' => $websites, 'webapps' => $webapps);
    }
    
    /**
     * @Route("/about")
     * @Template()
     */
    public function aboutAction()
    {
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('webapps' => $webapps);
    }
    
    /**
     * @Route("/contact")
     * @Template()
     */
    public function contactAction()
    {
        $request = $this->getRequest();
        if($request->getMethod() == "POST") {
          $name = $request->request->get('first_name').' '.$request->request->get('last_name');
          $email = $request->request->get('email');
          $body = $request->request->get('body');
          
          $message = \Swift_Message::newInstance()
          ->setSubject('Contact Email from Website')
          ->setFrom('send@example.com')
          ->setTo('andreipall@yahoo.com')
          ->setContentType("text/html")
          ->setBody(
              $this->renderView(
                  'WebBlogBundle:Home:basic.html.twig',
                  array('name' => $name, 'email' => $email, 'body' => $body)
              )
          );
          $this->get('mailer')->send($message);
          
          $this->get('session')->getFlashBag()->add(
              'notice',
              'Your mail has been sent successfully!'
          );
        }
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('webapps' => $webapps);
    }
    
    /**
     * @param string $id
     *
     * @throws NotFoundHttpException
     *
     * @Route("/portfolio/website/vote/{id}")
     */
    public function voteAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $website = $em->getRepository('WebBlogBundle:Website')->find($id);

        if (!$website) {
            throw $this->createNotFoundException(
                'No webiste found for id '.$id
            );
        }
        $website->setVotes($website->getVotes() + 1);
        $em->persist($website);
        $em->flush();

        return new JsonResponse(array('votes' => $website->getVotes()));
    }
    
    /**
     * @Route("/terms")
     * @Template()
     */
    public function termsAction()
    {
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('webapps' => $webapps);
    }
    
    /**
     * @Route("/privacy")
     * @Template()
     */
    public function privacyAction()
    {
        $webapps = $this->getDoctrine()->getRepository('WebBlogBundle:Website')->findLatestNWebsites(3);
        return array('webapps' => $webapps);
    }
    
    /**
     * @Route("/sitemap.{_format}", name="web_blog_home_sitemap", Requirements={"_format" = "xml"})
     * @Template("WebBlogBundle:Home:sitemap.xml.twig")
     */
    public function sitemapAction() 
    {
        $em = $this->getDoctrine()->getEntityManager();
        
        $urls = array();
        $hostname = $this->getRequest()->getHost();

        // add some urls homepage
        $urls[] = array('loc' => $this->get('router')->generate('web_blog_home_index'), 'changefreq' => 'weekly', 'priority' => '1.0');
        $urls[] = array('loc' => $this->get('router')->generate('web_blog_home_portfolio'), 'changefreq' => 'weekly', 'priority' => '1.0');
        $urls[] = array('loc' => $this->get('router')->generate('web_blog_blog_list'), 'changefreq' => 'weekly', 'priority' => '1.0');
        foreach ($em->getRepository('WebBlogBundle:Post')->findAll() as $post) {
            $urls[] = array('loc' => $this->get('router')->generate('web_blog_blog_index', array('slug' => $post->getSlug())), 'priority' => '0.5');
        }
        $urls[] = array('loc' => $this->get('router')->generate('web_blog_home_about'), 'changefreq' => 'weekly', 'priority' => '1.0');
        $urls[] = array('loc' => $this->get('router')->generate('web_blog_home_contact'), 'changefreq' => 'weekly', 'priority' => '1.0');
        /*
        
        // service
        
        */
        return array('urls' => $urls, 'hostname' => $hostname);
    }
    
    /**
     * @Route("/rss.xml", name="web_blog_home_feed")
     * @Template("WebBlogBundle:Home:rss.xml.twig")
     */
    public function rssAction() 
    {
        $em = $this->getDoctrine()->getEntityManager();
        
        $urls = array();
        $posts = $em->getRepository('WebBlogBundle:Post')->findAll();

        return array('urls' => $urls, 'posts' => $posts);
    }
}
