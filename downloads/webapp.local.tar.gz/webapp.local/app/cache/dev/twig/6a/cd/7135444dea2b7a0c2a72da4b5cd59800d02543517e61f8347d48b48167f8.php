<?php

/* AdminBundle::admin_layout.html.twig */
class __TwigTemplate_6acd7135444dea2b7a0c2a72da4b5cd59800d02543517e61f8347d48b48167f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'description' => array($this, 'block_description'),
            'keywords' => array($this, 'block_keywords'),
            'title' => array($this, 'block_title'),
            'mainmenu' => array($this, 'block_mainmenu'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_description($context, array $blocks = array())
    {
    }

    // line 3
    public function block_keywords($context, array $blocks = array())
    {
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
    }

    // line 5
    public function block_mainmenu($context, array $blocks = array())
    {
        // line 6
        echo "<div class=\"admin-menu ui vertical menu left floated\">
  <a href=\"";
        // line 7
        echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_index")) {
            echo "active";
        }
        echo " item\"><i class=\"dashboard icon\"></i> Dashboard</a>
  ";
        // line 8
        if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
            // line 9
            echo "  <a href=\"";
            echo $this->env->getExtension('routing')->getPath("web_admin_post_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_post_index")) {
                echo "active";
            }
            echo " item\"><i class=\"pencil icon\"></i> Posts</a>
  <a href=\"";
            // line 10
            echo $this->env->getExtension('routing')->getPath("web_admin_user_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_user_index")) {
                echo "active";
            }
            echo " item\"><i class=\"user icon\"></i> Users</a>
  <a href=\"";
            // line 11
            echo $this->env->getExtension('routing')->getPath("web_admin_category_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_category_index")) {
                echo "active";
            }
            echo " item\"><i class=\"filter layout icon\"></i> Categories</a>
  <a href=\"";
            // line 12
            echo $this->env->getExtension('routing')->getPath("web_admin_website_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_website_index")) {
                echo "active";
            }
            echo " item\"><i class=\"briefcase icon\"></i> Portfolio</a>
  ";
        }
        // line 14
        echo "  <a href=\"";
        echo $this->env->getExtension('routing')->getPath("web_admin_default_friends");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_friends")) {
            echo "active";
        }
        echo " item\"><i class=\"users icon\"></i> Friends</a>
  <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("web_admin_default_messages");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_messages")) {
            echo "active";
        }
        echo " item\"><i class=\"chat icon\"></i> Messages</a>
  <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("web_admin_default_profile");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_profile")) {
            echo "active";
        }
        echo " item\"><i class=\"edit icon\"></i> Edit Profile</a>
  <a href=\"";
        // line 17
        echo $this->env->getExtension('routing')->getPath("web_admin_default_account");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_account")) {
            echo "active";
        }
        echo " item\"><i class=\"settings icon\"></i> Account Settings</a>
  <div class=\"item\">
    <div class=\"admin-center\">
      <img class=\"ui image\" src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "avatar", array()))), "html", null, true);
        echo "\">
      <p>";
        // line 21
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "firstname", array()) . " ") . $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "lastname", array())), "html", null, true);
        echo "</p>
    </div>
  </div>
</div>
";
    }

    // line 26
    public function block_body($context, array $blocks = array())
    {
        // line 27
        echo "<div id=\"admin-content\" class=\"ui segment content right floated\">
";
        // line 28
        $this->displayBlock('content', $context, $blocks);
        // line 29
        echo "</div>
";
    }

    // line 28
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 28,  154 => 29,  152 => 28,  149 => 27,  146 => 26,  137 => 21,  133 => 20,  123 => 17,  115 => 16,  107 => 15,  98 => 14,  89 => 12,  81 => 11,  73 => 10,  64 => 9,  62 => 8,  54 => 7,  51 => 6,  48 => 5,  43 => 4,  38 => 3,  33 => 2,);
    }
}
