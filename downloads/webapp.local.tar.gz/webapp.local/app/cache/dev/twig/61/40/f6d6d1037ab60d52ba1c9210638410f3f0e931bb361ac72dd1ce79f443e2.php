<?php

/* AdminBundle:User:index.html.twig */
class __TwigTemplate_6140f6d6d1037ab60d52ba1c9210638410f3f0e931bb361ac72dd1ce79f443e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Users - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h4 class=\"ui dividing header\">Users</h4>

    <table class=\"ui table segment\">
        <thead>
            <tr>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
                <th>Username</th>
                <th>Active</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 18
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 19
            echo "            <tr>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "firstName", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "lastName", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "username", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            if ($this->getAttribute($context["entity"], "isActive", array())) {
                // line 25
                echo "                        <i class=\"icon checkmark\"></i>
                    ";
            } else {
                // line 27
                echo "                        <i class=\"icon close\"></i>
                    ";
            }
            // line 28
            echo "</td>
                <td>
                    <div class=\"mini ui buttons\"><a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_user_edit", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" class=\"ui button\">edit</a> <div class=\"or\"></div> <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_user_delete", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, (($this->getAttribute($context["entity"], "firstName", array()) . " ") . $this->getAttribute($context["entity"], "lastName", array())), "html", null, true);
            echo "\" class=\"ui button confirm delete\">delete</a></div>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "        </tbody>
        <tfoot>
          <tr>
            <th colspan=\"6\"><a href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("web_admin_user_new");
        echo "\" class=\"ui blue labeled icon button\"><i class=\"user icon\"></i> Add User</a></th>
          </tr>
        </tfoot>
    </table>
    
    <div class=\"ui one column stackable center aligned page grid\">";
        // line 42
        echo $this->env->getExtension('knp_pagination')->render((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "</div>
    
    <div class=\"ui modal small\">
      <i class=\"close icon\"></i>
      <div class=\"header\">
        Delete user
      </div>
      <div class=\"content\">
        Are you sure you want to delete this user: <strong id=\"name\"></strong>?
      </div>
      <div class=\"actions\">
        <a class=\"ui negative button\">Cancel</a>
        <a id=\"button_confirm\" class=\"ui positive right labeled icon button\">OK <i class=\"checkmark icon\"></i></a>
      </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:User:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 42,  111 => 37,  106 => 34,  92 => 30,  88 => 28,  84 => 27,  80 => 25,  78 => 24,  74 => 23,  70 => 22,  66 => 21,  62 => 20,  59 => 19,  55 => 18,  39 => 4,  36 => 3,  29 => 2,);
    }
}
