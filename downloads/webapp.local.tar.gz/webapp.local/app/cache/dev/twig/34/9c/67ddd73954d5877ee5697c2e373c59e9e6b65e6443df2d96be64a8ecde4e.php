<?php

/* AdminBundle:Post:edit.html.twig */
class __TwigTemplate_349c67ddd73954d5877ee5697c2e373c59e9e6b65e6443df2d96be64a8ecde4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Edit post - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h4 class=\"ui dividing header\">Edit post</h4>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Post:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 6,  39 => 4,  36 => 3,  29 => 2,);
    }
}
