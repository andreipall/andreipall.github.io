<?php

/* AdminBundle:Default:index.html.twig */
class __TwigTemplate_df4786b0ca52c884f80bd1afb612439827add5cf747cd26e93b4ab5f8969072a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Dashboard - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h4 class=\"ui dividing header\">Dashboard</h4>
    <h4 class=\"ui header admin-header\">Welcome ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "firstname", array()), "html", null, true);
        echo "</h4>
    <div class=\"ui grid\">
      <div class=\"wide column\">
        <div class=\"ui small piled feed segment\">
          <h4 class=\"ui header\">Activities</h4>
\t  ";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "activities", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
            // line 11
            echo "          <div class=\"event\">
            <div class=\"label\">
              <i class=\"circular ";
            // line 13
            if (($this->getAttribute($context["activity"], "type", array()) == "user-request")) {
                echo "user";
            }
            if (($this->getAttribute($context["activity"], "type", array()) == "post")) {
                echo "pencil";
            }
            if (($this->getAttribute($context["activity"], "type", array()) == "photo")) {
                echo "photo";
            }
            echo " icon\"></i>
            </div>
            <div class=\"content\">
              <div class=\"date\">
                 ";
            // line 17
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["activity"], "date", array()), "M d, Y H:i:s"), "html", null, true);
            echo "
              </div>
              <div class=\"summary\">
                 ";
            // line 20
            echo $this->getAttribute($context["activity"], "content", array());
            echo "
              </div>
\t      ";
            // line 22
            if (($this->getAttribute($context["activity"], "type", array()) == "post")) {
                // line 23
                echo "\t      <div class=\"extra text\">
                ";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["activity"], "extra", array()), "html", null, true);
                echo "
              </div>
\t      ";
            }
            // line 27
            echo "\t      ";
            if (($this->getAttribute($context["activity"], "type", array()) == "photo")) {
                // line 28
                echo "\t      <div class=\"extra images\">
                ";
                // line 29
                echo $this->getAttribute($context["activity"], "extra", array());
                echo "
              </div>
\t      ";
            }
            // line 32
            echo "            </div>
          </div>
\t  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </div>
      </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 35,  107 => 32,  101 => 29,  98 => 28,  95 => 27,  89 => 24,  86 => 23,  84 => 22,  79 => 20,  73 => 17,  58 => 13,  54 => 11,  50 => 10,  42 => 5,  39 => 4,  36 => 3,  29 => 2,);
    }
}
