<?php

/* AdminBundle:Default:messages.html.twig */
class __TwigTemplate_c03d921218c8705cafb8a7fb96ffc21d0fb76cef66fb8ba647219dfbee458d94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Messages - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h4 class=\"ui dividing header\">Messages</h4>
    <div id=\"messages\" class=\"ui column\">
      <div class=\"column\">
        <div class=\"ui piled segment\">
          <div class=\"ui comments\">
            ";
        // line 9
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["messages"]) ? $context["messages"] : $this->getContext($context, "messages")));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 10
            echo "            <div class=\"comment\">
              <a class=\"avatar\">
                <img src=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute($this->getAttribute($context["message"], "author", array()), "avatar", array()))), "html", null, true);
            echo "\">
              </a>
              <div class=\"content\">
                <a class=\"author\">";
            // line 15
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute($context["message"], "author", array()), "firstname", array()) . " ") . $this->getAttribute($this->getAttribute($context["message"], "author", array()), "lastname", array())), "html", null, true);
            echo "</a>
                <div class=\"metadata\">
                  <span class=\"date\">";
            // line 17
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["message"], "date", array()), "M d, Y H:i:s"), "html", null, true);
            echo "</span>
                </div>
                <div class=\"text\">
                  ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["message"], "text", array()), "html", null, true);
            echo "
                </div>
              </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "            <form action=\"";
        echo $this->env->getExtension('routing')->getPath("web_admin_default_messages");
        echo "\" method=\"post\" class=\"ui reply form\">
              <div class=\"field\">
                <textarea name=\"message\"></textarea>
              </div>
              <div class=\"ui fluid labeled submit icon button\">
                <i class=\"icon edit\"></i> Send
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div id=\"users-list\" class=\"ui list column\">
      ";
        // line 38
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "myFriends", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["friend"]) {
            // line 39
            echo "      <div class=\"item\">
        <img class=\"ui avatar image\" src=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute($context["friend"], "avatar", array()))), "html", null, true);
            echo "\">
        <div class=\"content\">
          <div class=\"header\">";
            // line 42
            echo twig_escape_filter($this->env, (($this->getAttribute($context["friend"], "firstname", array()) . " ") . $this->getAttribute($context["friend"], "lastname", array())), "html", null, true);
            echo "</div>
          ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["friend"], "username", array()), "html", null, true);
            echo "
        </div>
      </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['friend'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "    </div>

";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:messages.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 47,  115 => 43,  111 => 42,  106 => 40,  103 => 39,  99 => 38,  82 => 25,  71 => 20,  65 => 17,  60 => 15,  54 => 12,  50 => 10,  46 => 9,  39 => 4,  36 => 3,  29 => 2,);
    }
}
