<?php

/* WebBlogBundle:Home:privacy.html.twig */
class __TwigTemplate_24eaacc09479626484066b7513c5264ef4fe7127858c7b8dca653d172956eb89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("WebBlogBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebBlogBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Privacy policy - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"ui segment content\">
<div class=\"ui breadcrumb\"> <a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> <div class=\"divider\"> / </div> <div class=\"active section\">Privacy policy</div> </div> 
<h1 class=\"title\">Privacy policy</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac porttitor eros. Donec accumsan iaculis dapibus. Nullam condimentum non libero sit amet sodales. Quisque ornare augue sit amet condimentum sodales. Maecenas quam turpis, egestas ut porttitor in, consequat ac erat. Aliquam vitae neque in leo fermentum faucibus sed at mi. Sed vel mattis sem. Ut non vulputate sapien. Aenean ac enim vitae nulla semper gravida sed in nisi. Proin purus felis, cursus vel faucibus sit amet, sollicitudin non leo. Suspendisse porta maximus lacus, non dictum odio accumsan et. Vestibulum eleifend, quam at imperdiet efficitur, lorem neque gravida nulla, eu tristique tortor ligula nec mauris. Etiam sed euismod magna, non efficitur tellus. Sed accumsan ante ut ligula gravida, rutrum mattis felis finibus. Etiam pellentesque iaculis felis, imperdiet fermentum mi cursus ac. Aenean urna tortor, congue et feugiat ac, ultrices ut eros.</p>

<p>Etiam dictum metus ac leo porttitor eleifend non at tellus. Quisque leo leo, maximus ut urna sed, gravida elementum erat. In non gravida lectus. Proin aliquet dolor at dignissim accumsan. Suspendisse scelerisque massa felis, at tincidunt velit sollicitudin sit amet. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed dapibus nec quam et laoreet. Duis placerat massa ex, in volutpat odio feugiat id. Maecenas tempor fermentum cursus.</p>

<p>Donec et magna non purus maximus accumsan. Vivamus suscipit cursus enim, at convallis ipsum tristique eget. Ut est leo, posuere vel ultrices non, rhoncus vitae sapien. Donec orci ex, tempor non volutpat accumsan, mattis sit amet mauris. Morbi at est in velit fermentum ornare vitae eu dui. Integer mattis sem dolor. Aliquam sit amet nunc vitae elit vulputate placerat. Phasellus tristique nisi vitae enim tempor, vitae dapibus felis commodo. Sed scelerisque vulputate mi. Proin at augue sem. Mauris quis molestie diam. Duis et nunc at libero pretium ultricies a et orci. Vestibulum nulla libero, placerat a fringilla ac, rutrum a magna. Nulla mattis quis est eleifend luctus. Cras rutrum magna eu quam mattis, nec cursus enim hendrerit.</p>

<p>In at odio quis ligula tincidunt aliquam id et leo. Nullam fermentum quam nec risus dignissim, eget consequat odio ultrices. Suspendisse at purus a nisl dictum condimentum. Sed porta luctus enim, at pharetra metus mattis eu. Donec vulputate tortor eget arcu ornare, non accumsan eros pellentesque. Fusce mattis maximus sem et commodo. Donec lobortis vestibulum tellus ac porta. Mauris quis enim metus. Fusce dapibus odio orci, feugiat dapibus elit varius a. In tempus, sem vitae faucibus ornare, eros diam porta magna, eu tincidunt nunc diam eget diam. Duis placerat faucibus felis, et suscipit mauris vestibulum id.</p>

<p>Nam vestibulum molestie justo id semper. Sed et lectus tristique, sodales velit at, tempor enim. Donec elit arcu, congue vel fringilla ut, congue vitae mi. Sed ut turpis eu ligula venenatis gravida nec sed nulla. Sed odio dolor, pulvinar id lobortis non, bibendum nec dolor. Mauris accumsan accumsan diam in pharetra. Curabitur sit amet sagittis sapien. Vivamus non ex vel massa fringilla dignissim. </p> 
</div>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:privacy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 5,  39 => 4,  36 => 3,  29 => 2,);
    }
}
