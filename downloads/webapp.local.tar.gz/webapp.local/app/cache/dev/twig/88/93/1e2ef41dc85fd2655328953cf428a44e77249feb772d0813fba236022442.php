<?php

/* WebBlogBundle:Blog:listByName.html.twig */
class __TwigTemplate_88931e2ef41dc85fd2655328953cf428a44e77249feb772d0813fba236022442 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("WebBlogBundle::blog_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebBlogBundle::blog_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Blog - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"blog-post ui segment content left floated twelve wide column\">
<div class=\"ui breadcrumb\"> 
  <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> <div class=\"divider\"> / </div> <div class=\"active section\">Blog</div>
</div> 
";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 9
            echo "<article class=\"ui piled segment message\">
  <div class=\"ui ribbon label\"><time datetime=\"";
            // line 10
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "date", array()), "d M Y"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "date", array()), "D, d M Y"), "html", null, true);
            echo "</time></div>
  <header class=\"header\">
      ";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "name", array()), "html", null, true);
            echo "
  </header>
  ";
            // line 14
            echo twig_truncate_filter($this->env, $this->getAttribute($context["post"], "content", array()), 400);
            echo " &#8212; <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">read more</a>
</article>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "<div class=\"ui one column stackable center aligned page grid\">";
        echo $this->env->getExtension('knp_pagination')->render((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Blog:listByName.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 18,  67 => 14,  62 => 12,  55 => 10,  52 => 9,  48 => 8,  43 => 6,  39 => 4,  36 => 3,  29 => 2,);
    }
}
