<?php

/* WebBlogBundle::blog_layout.html.twig */
class __TwigTemplate_c9fa69e317c3e2232ec9661c8e02718f18aaab098025fa67ad1fda859d84c411 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'description' => array($this, 'block_description'),
            'keywords' => array($this, 'block_keywords'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_description($context, array $blocks = array())
    {
    }

    // line 3
    public function block_keywords($context, array $blocks = array())
    {
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
    }

    // line 6
    public function block_sidebar($context, array $blocks = array())
    {
        // line 7
        echo "<aside class=\"right-sidebar ui vertical menu right floated four wide column\">
  <div class=\"header item\">
    <i class=\"block layout icon\"></i>
    Categories
  </div>
  ";
        // line 22
        echo "  ";
        if ((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories"))) {
            // line 23
            echo "  <div class=\"item\">
      ";
            // line 24
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 25
                echo "          ";
                if (twig_test_empty($this->getAttribute($context["category"], "parent", array()))) {
                    // line 26
                    echo "              ";
                    echo $this->getAttribute($this, "recursiveCategory", array(0 => $context["category"]), "method");
                    echo "
          ";
                }
                // line 28
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "  </div>
  ";
        }
        // line 31
        echo "</aside>
";
    }

    // line 12
    public function getrecursiveCategory($__category__ = null)
    {
        $context = $this->env->mergeGlobals(array(
            "category" => $__category__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 13
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_listbycategory", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()))), "html", null, true);
            echo "\" ";
            if ((!twig_test_empty($this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "parent", array())))) {
                echo "class=\"item\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
            echo "</a>
    ";
            // line 14
            if (twig_length_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "children", array()))) {
                // line 15
                echo "        <div class=\"menu\">
            ";
                // line 16
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 17
                    echo "                ";
                    echo $this->getAttribute($this, "recursiveCategory", array(0 => $context["child"]), "method");
                    echo "
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 19
                echo "        </div>
    ";
            }
            // line 21
            echo "  ";
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "WebBlogBundle::blog_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 21,  136 => 19,  127 => 17,  123 => 16,  120 => 15,  118 => 14,  107 => 13,  96 => 12,  91 => 31,  87 => 29,  81 => 28,  75 => 26,  72 => 25,  68 => 24,  65 => 23,  62 => 22,  55 => 7,  52 => 6,  47 => 5,  42 => 4,  37 => 3,  32 => 2,);
    }
}
