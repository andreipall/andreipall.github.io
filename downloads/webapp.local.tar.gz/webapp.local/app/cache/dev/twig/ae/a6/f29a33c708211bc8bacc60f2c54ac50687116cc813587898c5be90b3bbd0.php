<?php

/* AdminBundle:Default:account.html.twig */
class __TwigTemplate_aea6f29a33c708211bc8bacc60f2c54ac50687116cc813587898c5be90b3bbd0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Account settings - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"ui segment content\">
    <h4 class=\"ui dividing header\">Account settings</h4>
    <form action=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("web_admin_default_account");
        echo "\" method=\"post\" id=\"sign-up-form\" class=\"ui form segment ";
        if ((!$this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "valid", array()))) {
            echo "error";
        }
        echo "\">
      <div class=\"ui error message\">
          ";
        // line 8
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "first_name", array()), 'errors');
        echo "
          ";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "last_name", array()), 'errors');
        echo "
          ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "username", array()), 'errors');
        echo "
          ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'errors');
        echo "
          ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "password", array()), 'errors');
        echo "
          ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
      </div>
      <div class=\"field\">
        <label for=\"username\">First Name</label>
        <div class=\"ui corner labeled left icon input\">
          ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "first_name", array()), 'widget');
        echo "
          <i class=\"user icon\"></i>
          <div class=\"ui corner label\">
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      <div class=\"field\">
        <label for=\"username\">Last Name</label>
        <div class=\"ui corner labeled left icon input\">
          ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "last_name", array()), 'widget');
        echo "
          <i class=\"user icon\"></i>
          <div class=\"ui corner label\">
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      <div class=\"field\">
        <label for=\"username\">Email</label>
        <div class=\"ui corner labeled left icon input\">
          ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'widget');
        echo "
          <i class=\"mail icon\"></i>
          <div class=\"ui corner label\">
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      <div class=\"field\">
        <label for=\"username\">Username</label>
        <div class=\"ui corner labeled left icon input\">
          ";
        // line 48
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "username", array()), 'widget');
        echo "
          <i class=\"user icon\"></i>
          <div class=\"ui corner label\">
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      ";
        // line 55
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "password", array()), 'widget');
        echo "<br />
      ";
        // line 56
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "
    </form>
</div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:account.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 56,  129 => 55,  119 => 48,  106 => 38,  93 => 28,  80 => 18,  72 => 13,  68 => 12,  64 => 11,  60 => 10,  56 => 9,  52 => 8,  43 => 6,  39 => 4,  36 => 3,  29 => 2,);
    }
}
