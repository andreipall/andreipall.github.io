<?php

/* AdminBundle:Category:edit.html.twig */
class __TwigTemplate_32f39a2de16a4580f43c6d278a5287d78efe83e94d13a74c75cf7590323c799e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Edit category - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h4 class=\"ui dividing header\">Edit category</h4>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "


";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Category:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 6,  39 => 4,  36 => 3,  29 => 2,);
    }
}
