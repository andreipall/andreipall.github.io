<?php

/* WebBlogBundle:Home:portfolio.html.twig */
class __TwigTemplate_1554d3b77a3534010b0fbe59d9bfeeec97a534b3dd4dde161c0e37d88f892267 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("WebBlogBundle::layout.html.twig");

        $this->blocks = array(
            'description' => array($this, 'block_description'),
            'keywords' => array($this, 'block_keywords'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebBlogBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_description($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
        echo " portfolio";
    }

    // line 3
    public function block_keywords($context, array $blocks = array())
    {
        echo "portfolio, web, development, programming";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Portfolio - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<div class=\"ui breadcrumb\"> <a href=\"";
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> <div class=\"divider\"> / </div> <div class=\"active section\">Portfolio</div> </div> 
<div class=\"ui five cards\">
";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["websites"]) ? $context["websites"] : $this->getContext($context, "websites")));
        foreach ($context['_seq'] as $context["_key"] => $context["website"]) {
            // line 9
            echo "  <div class=\"card\">
    <div>
      <a href=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "url", array()), "html", null, true);
            echo "\" target=\"_blank\" class=\"image\"><img src=\"";
            echo twig_escape_filter($this->env, ($this->env->getExtension('assets')->getAssetUrl("uploads/websites/") . $this->getAttribute($context["website"], "image", array())), "html", null, true);
            echo "\"></a>
      <a id=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "id", array()), "html", null, true);
            echo "\" class=\"vote like ui corner label\">
        <i class=\"like icon\"></i>
      </a>
    </div>
    <div class=\"content\">
      <div class=\"header\">";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "name", array()), "html", null, true);
            echo "</div>
      <div class=\"meta\">";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "days", array()), "html", null, true);
            echo " days ago</div>
      <p class=\"description\">";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "description", array()), "html", null, true);
            echo "</p>
      <div class=\"extra content\">
          <i class=\"heart icon\"></i>
          <span id=\"votes_";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "id", array()), "html", null, true);
            echo "\" class=\"votes\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "votes", array()), "html", null, true);
            echo "</span> votes
      </div>
    </div>
  </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['website'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:portfolio.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 27,  96 => 22,  90 => 19,  86 => 18,  82 => 17,  74 => 12,  68 => 11,  64 => 9,  60 => 8,  54 => 6,  51 => 5,  44 => 4,  38 => 3,  31 => 2,);
    }
}
