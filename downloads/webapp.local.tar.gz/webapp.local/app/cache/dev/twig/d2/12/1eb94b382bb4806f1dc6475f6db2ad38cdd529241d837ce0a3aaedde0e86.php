<?php

/* WebBlogBundle:Blog:index.html.twig */
class __TwigTemplate_d2121eb94b382bb4806f1dc6475f6db2ad38cdd529241d837ce0a3aaedde0e86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("WebBlogBundle::blog_layout.html.twig");

        $this->blocks = array(
            'description' => array($this, 'block_description'),
            'keywords' => array($this, 'block_keywords'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebBlogBundle::blog_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_description($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "metaDescription", array()), "html", null, true);
    }

    // line 3
    public function block_keywords($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "metaTitle", array()), "html", null, true);
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "name", array()), "html", null, true);
        echo " - Blog - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<div class=\"blog-post ui segment content left floated twelve wide column\">
<div class=\"ui breadcrumb\"> <a href=\"";
        // line 7
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> <div class=\"divider\"> / </div> <a href=\"";
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "\" class=\"section\">Blog</a> <div class=\"divider\"> / </div> <div class=\"active section\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "name", array()), "html", null, true);
        echo "</div> </div> 
<h1 class=\"title\">";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "name", array()), "html", null, true);
        echo "</h1>
";
        // line 9
        echo $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "content", array());
        echo " 

<h2>Comments</h2>
";
        // line 12
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 13
            echo "<div class=\"ui success message\">
  <i class=\"close icon\"></i>
    ";
            // line 15
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "<div class=\"ui comments\">
  ";
        // line 50
        echo "
  ";
        // line 51
        if ($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "comments", array())) {
            // line 52
            echo "      ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "comments", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 53
                echo "          ";
                if (twig_test_empty($this->getAttribute($context["comment"], "parent", array()))) {
                    // line 54
                    echo "              ";
                    echo $this->getAttribute($this, "recursiveComment", array(0 => $context["comment"], 1 => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "slug", array())), "method");
                    echo "
          ";
                }
                // line 56
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 57
            echo "      ";
            if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
                // line 58
                echo "      <form action=\"";
                echo $this->env->getExtension('routing')->getPath("web_blog_blog_newcomment");
                echo "\" method=\"post\" class=\"ui reply form\">
        <div class=\"field\">
          <input type=\"hidden\" name=\"slug\" value=\"";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "slug", array()), "html", null, true);
                echo "\" />
          <textarea name=\"body\" id=\"comment\"></textarea>
        </div>
        <button type=\"submit\" class=\"ui button submit labeled icon\">
          <i class=\"icon edit\"></i> Add Comment
        </button>
      </form>
      ";
            } else {
                // line 68
                echo "          <p>Please <a href=\"";
                echo $this->env->getExtension('routing')->getPath("web_admin_security_login");
                echo "\">log in</a> to post comments.</p>
      ";
            }
            // line 70
            echo "  ";
        }
        // line 71
        echo "</div>

</div>
";
    }

    // line 19
    public function getrecursiveComment($__comment__ = null, $__slug__ = null)
    {
        $context = $this->env->mergeGlobals(array(
            "comment" => $__comment__,
            "slug" => $__slug__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 20
            echo "  <div class=\"comment\">
    <a class=\"avatar\">
      <img src=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute($this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "author", array()), "avatar", array()))), "html", null, true);
            echo "\">
    </a>
    <div class=\"content\">
      <a class=\"author\">";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "author", array()), "html", null, true);
            echo "</a>
      <div class=\"metadata\">
        <span class=\"date\">";
            // line 27
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "date", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</span>
      </div>
      <div class=\"text\">
        ";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "body", array()), "html", null, true);
            echo "
      </div>
      ";
            // line 32
            if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
                // line 33
                echo "      <div id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "id", array()), "html", null, true);
                echo "\" class=\"actions\" slug=\"";
                echo twig_escape_filter($this->env, (isset($context["slug"]) ? $context["slug"] : $this->getContext($context, "slug")), "html", null, true);
                echo "\">
        <a class=\"reply-link\">Reply</a>
        ";
                // line 35
                if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()) == $this->getAttribute($this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "author", array()), "id", array()))) {
                    // line 36
                    echo "        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_deletecomment", array("id" => $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "id", array()))), "html", null, true);
                    echo "\" class=\"delete\">Delete</a>
        ";
                }
                // line 38
                echo "      </div>
      ";
            }
            // line 40
            echo "    </div>
    ";
            // line 41
            if (twig_length_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "children", array()))) {
                // line 42
                echo "        <div class=\"comments\">
            ";
                // line 43
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["comment"]) ? $context["comment"] : $this->getContext($context, "comment")), "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 44
                    echo "                ";
                    echo $this->getAttribute($this, "recursiveComment", array(0 => $context["child"], 1 => (isset($context["slug"]) ? $context["slug"] : $this->getContext($context, "slug"))), "method");
                    echo "
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 46
                echo "        </div>
    ";
            }
            // line 48
            echo "  </div>      
  ";
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Blog:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  241 => 48,  237 => 46,  228 => 44,  224 => 43,  221 => 42,  219 => 41,  216 => 40,  212 => 38,  206 => 36,  204 => 35,  196 => 33,  194 => 32,  189 => 30,  183 => 27,  178 => 25,  172 => 22,  168 => 20,  156 => 19,  149 => 71,  146 => 70,  140 => 68,  129 => 60,  123 => 58,  120 => 57,  114 => 56,  108 => 54,  105 => 53,  100 => 52,  98 => 51,  95 => 50,  92 => 18,  83 => 15,  79 => 13,  75 => 12,  69 => 9,  65 => 8,  57 => 7,  54 => 6,  51 => 5,  43 => 4,  37 => 3,  31 => 2,);
    }
}
