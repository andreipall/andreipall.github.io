<?php

/* AdminBundle:Default:friends.html.twig */
class __TwigTemplate_eab0e1a2b49677802c0b7e593a8f7f95d7fc96ff94641e7a91c038f7a9969aee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Friends - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h4 class=\"ui dividing header\">Friends</h4>
    ";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 6
            echo "    <div class=\"ui success message\">
      <i class=\"close icon\"></i>
        ";
            // line 8
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    <table class=\"ui table segment\">
      <thead>
        <tr><th>Name</th>
        <th>Username</th>
        <th>Status</th>
        <th>Delete</th>
      </tr></thead>
      <tbody>
\t";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "myFriends", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["friend"]) {
            // line 20
            echo "        <tr>
          <td>";
            // line 21
            echo twig_escape_filter($this->env, (($this->getAttribute($context["friend"], "firstname", array()) . " ") . $this->getAttribute($context["friend"], "lastname", array())), "html", null, true);
            echo "</td>
          <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["friend"], "username", array()), "html", null, true);
            echo "</td>
          <td>Approved</td>
          <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_default_removefriend", array("id" => $this->getAttribute($context["friend"], "id", array()))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, (($this->getAttribute($context["friend"], "firstName", array()) . " ") . $this->getAttribute($context["friend"], "lastName", array())), "html", null, true);
            echo "\" class=\"mini ui button confirm delete\">delete</a></td>
        </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['friend'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "friendsWithMe", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["friend"]) {
            // line 28
            echo "        <tr>
          <td>";
            // line 29
            echo twig_escape_filter($this->env, (($this->getAttribute($context["friend"], "firstname", array()) . " ") . $this->getAttribute($context["friend"], "lastname", array())), "html", null, true);
            echo "</td>
          <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["friend"], "username", array()), "html", null, true);
            echo "</td>
          <td>Approved</td>
          <td><a href=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_default_removefriend", array("id" => $this->getAttribute($context["friend"], "id", array()))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, (($this->getAttribute($context["friend"], "firstName", array()) . " ") . $this->getAttribute($context["friend"], "lastName", array())), "html", null, true);
            echo "\" class=\"mini ui button confirm delete\">delete</a></td>
        </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['friend'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "      </tbody>
      <tfoot>
        <tr><th colspan=\"2\">
\t  <form id=\"add_friend\" action=\"";
        // line 38
        echo $this->env->getExtension('routing')->getPath("web_admin_default_friends");
        echo "\" method=\"post\">
          <div class=\"ui left icon action input fluid dropdown select_users_dropdown\">
            <input id=\"search_users\" name=\"username\"  placeholder=\"Search users...\" type=\"text\">
            <i class=\"users icon\"></i>
\t    <div id=\"found_users\" class=\"menu ui transition visible\"></div>
            <div id=\"add_friend_button\" class=\"ui button disabled\">Add Friend</div>
          </div>
\t  </form>
        </th><th colspan=\"2\"></th>
      </tr></tfoot>
    </table>
    
    <div class=\"ui modal small\">
      <i class=\"close icon\"></i>
      <div class=\"header\">
        Delete user
      </div>
      <div class=\"content\">
        Are you sure you want to delete this user from your list of friends: <strong id=\"name\"></strong>?
      </div>
      <div class=\"actions\">
        <a class=\"ui negative button\">Cancel</a>
        <a id=\"button_confirm\" class=\"ui positive right labeled icon button\">OK <i class=\"checkmark icon\"></i></a>
      </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:friends.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 38,  124 => 35,  113 => 32,  108 => 30,  104 => 29,  101 => 28,  96 => 27,  85 => 24,  80 => 22,  76 => 21,  73 => 20,  69 => 19,  59 => 11,  50 => 8,  46 => 6,  42 => 5,  39 => 4,  36 => 3,  29 => 2,);
    }
}
