<?php

/* AdminBundle:Security:login.html.twig */
class __TwigTemplate_2f7fc247323447b76046a76ac3efc9d75beb15a06b54c0dbd41c552fb066564f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Login - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<div class=\"ui segment content\">
<div class=\"ui breadcrumb\"> <a href=\"";
        // line 7
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> 
<div class=\"divider\"> / </div> <div class=\"active section\">Login</div> </div> 

";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 11
            echo "<div class=\"ui success message\">
  <i class=\"close icon\"></i>
    ";
            // line 13
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
<p class=\"ui tiny header\">Registration is quick and easy. It enables you to enjoy benefits of registration such as Table of Content alerts, online subscriptions, auto login and exclusive content. You can modify your registration details at any anytime using 'My Account'. To start taking advantage of these benefits click Sign Up.</p>

<div class=\"ui two column middle aligned relaxed grid basic segment\">
  <div class=\"column\">    
    <form action=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("web_admin_security_logincheck");
        echo "\" method=\"post\" class=\"ui form segment ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            echo "error";
        }
        echo "\">
      <div class=\"ui error message\">
          ";
        // line 23
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 24
            echo "          ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message", array()), "html", null, true);
            echo "
          ";
        }
        // line 26
        echo "      </div>
      <div class=\"field\">
        <label for=\"username\">Username</label>
        <div class=\"ui corner labeled left icon input\">
          <input placeholder=\"Username\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 30
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\">
          <i class=\"user icon\"></i>
          <div class=\"ui corner label\"> 
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      <div class=\"field\">
        <label for=\"password\">Password</label>
        <div class=\"ui corner labeled left icon input\">
          <input type=\"password\" id=\"password\" name=\"_password\" placeholder=\"Password\">
          <input type=\"hidden\" name=\"_target_path\" value=\"";
        // line 41
        echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
        echo "\" />
          <i class=\"lock icon\"></i>
          <div class=\"ui corner label\">
            <i class=\"icon asterisk\"></i>
          </div>
        </div>
      </div>
      <button type=\"submit\" class=\"ui blue submit button\">Login</button>
    </form>
  </div>
  <div class=\"ui vertical divider\">
    Or
  </div>
  <div class=\"center aligned column\">
    <a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("web_admin_security_register");
        echo "\" class=\"huge green ui labeled icon button\">
      <i class=\"signup icon\"></i>
      Sign Up
    </a>
  </div>
</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 55,  109 => 41,  95 => 30,  89 => 26,  83 => 24,  81 => 23,  72 => 21,  65 => 16,  56 => 13,  52 => 11,  48 => 10,  42 => 7,  39 => 6,  36 => 5,  29 => 3,);
    }
}
