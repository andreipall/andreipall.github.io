<?php

/* ::base.html.twig */
class __TwigTemplate_291d99f26f9da917be048cf9d08884fbb8f8f3a41f8980b294db3f5995ecf59b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'mainmenu' => array($this, 'block_mainmenu'),
            'body' => array($this, 'block_body'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\">
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("semantic/semantic.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body class=\"ui page grid\">
        <header class=\"ui grid\">
          <div class=\"ui menu main-menu\">
            <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_home_index")) {
            echo "active";
        }
        echo " item\">
              <i class=\"home icon\"></i>
              Home
            </a>
            <a href=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("web_blog_home_portfolio");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_home_portfolio")) {
            echo "active";
        }
        echo " item\">
              <i class=\"grid layout icon\"></i> Portfolio
            </a>
            <a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "\" class=\"";
        if ((($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_blog_index") || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_blog_list"))) {
            echo "active";
        }
        echo " item\">
              <i class=\"browser icon\"></i> Blog
            </a>
            <a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("web_blog_home_about");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_home_about")) {
            echo "active";
        }
        echo " item\">
              <i class=\"list layout icon\"></i> About
            </a>
            <a href=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("web_blog_home_contact");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_blog_home_contact")) {
            echo "active";
        }
        echo " item\">
              <i class=\"mail icon\"></i> Contact
            </a>
            <div class=\"right menu\">
              <div class=\"ui search item\">
                <form action=\"";
        // line 33
        echo $this->env->getExtension('routing')->getPath("web_blog_home_search");
        echo "\" method=\"post\" id=\"search-form\" class=\"ui form icon input\">
                  <input id=\"search-input\" placeholder=\"Search...\" type=\"search\" name=\"term\">
                  <i id=\"search-button\" class=\"search icon\"></i>
                </form>
              </div>
              ";
        // line 38
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 39
            echo "              <div class=\"ui dropdown item\">
                <i class=\"setting icon\"></i> More <i class=\"icon dropdown\"></i>
                <div class=\"menu\">
                  <a href=\"";
            // line 42
            echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
            echo "\" class=\"item\"><i class=\"dashboard icon\"></i> Dashboard</a>
                  <a href=\"";
            // line 43
            echo $this->env->getExtension('routing')->getPath("web_admin_default_profile");
            echo "\" class=\"item\"><i class=\"edit icon\"></i> Edit Profile</a>
                  <a href=\"";
            // line 44
            echo $this->env->getExtension('routing')->getPath("web_admin_default_account");
            echo "\" class=\"item\"><i class=\"settings icon\"></i> Account Settings</a>
                  <a href=\"";
            // line 45
            echo $this->env->getExtension('routing')->getPath("web_admin_security_logout");
            echo "\" class=\"item\"><i class=\"sign out icon\"></i> Logout</a>
                </div>
              </div>
              ";
        } else {
            // line 49
            echo "              <a href=\"";
            echo $this->env->getExtension('routing')->getPath("web_admin_security_login");
            echo "\" class=\"ui item\"><i class=\"sign in icon\"></i> Login</a>
              ";
        }
        // line 51
        echo "            </div>
          </div>
        </header>
        <main class=\"ui grid\">
        ";
        // line 55
        $this->displayBlock('mainmenu', $context, $blocks);
        // line 56
        echo "        ";
        $this->displayBlock('body', $context, $blocks);
        // line 57
        echo "        ";
        $this->displayBlock('sidebar', $context, $blocks);
        // line 58
        echo "        </main>
        <footer class=\"ui inverted page grid segment\">
          <div class=\"twelve wide column\">
            <div class=\"ui three column stackable grid\">
              <div class=\"column\">
                <div class=\"ui inverted header\">Latest Websites</div>
                <div class=\"ui inverted link list\">
                  ";
        // line 65
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["webapps"]) ? $context["webapps"] : $this->getContext($context, "webapps")));
        foreach ($context['_seq'] as $context["_key"] => $context["website"]) {
            // line 66
            echo "                  <a href=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "url", array()), "html", null, true);
            echo "\" class=\"item\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["website"], "name", array()), "html", null, true);
            echo "</a>
                  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['website'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "                </div>
              </div>
              <div class=\"column\">
                <div class=\"ui inverted header\">Blog Posts</div>
                <div class=\"ui inverted link list\">
                  <a href=\"";
        // line 73
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_listbyname");
        echo "\" class=\"item\">A-Z</a>
                  <a href=\"";
        // line 74
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "\" class=\"item\">Recently Changed</a>
                  <a href=\"";
        // line 75
        echo $this->env->getExtension('routing')->getPath("web_blog_home_feed");
        echo "\" class=\"item\">Feed</a>
                </div>
              </div>
              <div class=\"column\">
                <div class=\"ui inverted header\">Community</div>
                <div class=\"ui inverted link list\">
                  <a href=\"";
        // line 81
        echo $this->env->getExtension('routing')->getPath("web_blog_home_terms");
        echo "\" class=\"item\">Terms and Conditions</a>
                  <a href=\"";
        // line 82
        echo $this->env->getExtension('routing')->getPath("web_blog_home_privacy");
        echo "\" class=\"item\">Privacy Policy</a>
                  <a href=\"";
        // line 83
        echo $this->env->getExtension('routing')->getPath("web_blog_home_sitemap", array("_format" => "xml"));
        echo "\" class=\"item\">Sitemap</a>
                </div>
              </div>
            </div>
          </div>
          <div class=\"four wide right floated aligned column\">
            <h3 class=\"ui inverted header contact-header\">Contact</h3>
            <addr>
              26 Mount Grove <br>
              Edgware HA8 9SX, London <br>
              07425885299
            </addr>
          </div>
        </footer>
        <script src=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/jquery-2.1.1.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 98
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("semantic/semantic.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/d3.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>
";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
    }

    // line 55
    public function block_mainmenu($context, array $blocks = array())
    {
    }

    // line 56
    public function block_body($context, array $blocks = array())
    {
    }

    // line 57
    public function block_sidebar($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  266 => 57,  261 => 56,  256 => 55,  251 => 7,  243 => 100,  239 => 99,  235 => 98,  231 => 97,  214 => 83,  210 => 82,  206 => 81,  197 => 75,  193 => 74,  189 => 73,  182 => 68,  171 => 66,  167 => 65,  158 => 58,  155 => 57,  152 => 56,  150 => 55,  144 => 51,  138 => 49,  131 => 45,  127 => 44,  123 => 43,  119 => 42,  114 => 39,  112 => 38,  104 => 33,  92 => 28,  82 => 25,  72 => 22,  62 => 19,  51 => 15,  43 => 10,  39 => 9,  35 => 8,  31 => 7,  23 => 1,);
    }
}
