<?php

/* WebBlogBundle:Home:index.html.twig */
class __TwigTemplate_f7fdec294bc0539dfc8a075953485c2410acc26d330a50588e495fbac3238a59 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Web development - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<div id=\"banner\" class=\"ui segment\">
  <img class=\"ui image\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/web-development.jpg"), "html", null, true);
        echo "\" alt=\"Banner\" />
</div>


<div class=\"home-section ui page grid stackable feature segment\">
  <div class=\"row\">
    <div class=\"ten wide column\">
      <h2 class=\"ui header\">";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
        echo " - Web application development services</h2>
      <p>";
        // line 15
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
        echo " is an “A to Z” Web development company that always keeps its services up to date with the latest market trends, providing customers all over the world with best-of-class, easily extensible Internet products. Our solutions range from custom website designs to business application development of any complexity.</p>

<p>The company’s specialists help clients efficiently present their businesses on the Internet, develop solutions that rise to meet all business needs and/or improve existing systems. Our business practices, combined with the utmost attention to detail, are a proven combination that enables our highly experienced team to provide clients with efficient, reliable and affordable solutions.</p>
      <p>We develop brilliant and effective web applications that your users will love, we share ideas, we develop the bits that make it all hang together, we deliver quality results and we keep promises. Any wonder why our customers keep coming back for more? Do you get this from working with your digital agency? No?
Why don't you give us a call and we'll show you how things really ought to be.</p>
      <a href=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("web_blog_home_about");
        echo "\" class=\"ui basic animated button\">
        <div class=\"visible content\">Read More</div>
        <div class=\"hidden content\"><i class=\"right arrow icon\"></i></div>
      </a>
      <div class=\"ui section divider\"></div>
      <h3 class=\"ui header\">More articles</h3>
      <div class=\"ui animated selection list\">
        ";
        // line 27
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 28
            echo "        <div class=\"item\">
          <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "name", array()), "html", null, true);
            echo "</a>
          <div class=\"right floated\">";
            // line 30
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "date", array()), "M d, Y"), "html", null, true);
            echo "</div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "      </div>
    </div>
    
    <div class=\"six wide column\">
      ";
        // line 37
        if ((!$this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 38
            echo "      <form action=\"";
            echo $this->env->getExtension('routing')->getPath("web_admin_security_logincheck");
            echo "\" method=\"post\" class=\"ui form segment ";
            if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
                echo "error";
            }
            echo "\">
        <div class=\"ui error message\">
            ";
            // line 40
            if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
                // line 41
                echo "            ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message", array()), "html", null, true);
                echo "
            ";
            }
            // line 43
            echo "        </div>
        <div class=\"field\">
          <label for=\"username\">Username</label>
          <div class=\"ui corner labeled left icon input\">
            <input placeholder=\"Username\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
            // line 47
            echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
            echo "\">
            <i class=\"user icon\"></i>
            <div class=\"ui corner label\">
              <i class=\"icon asterisk\"></i>
            </div>
          </div>
        </div>
        <div class=\"field\">
          <label for=\"password\">Password</label>
          <div class=\"ui corner labeled left icon input\">
            <input type=\"password\" id=\"password\" name=\"_password\" placeholder=\"Password\">
            <input type=\"hidden\" name=\"_target_path\" value=\"";
            // line 58
            echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
            echo "\" />
            <i class=\"lock icon\"></i>
            <div class=\"ui corner label\">
              <i class=\"icon asterisk\"></i>
            </div>
          </div>
        </div>
        <button type=\"submit\" class=\"ui blue submit button\">Login</button>
      </form>
      <div class=\"ui horizontal divider\">Or</div>
      ";
        }
        // line 69
        echo "      <div class=\"ui secondary form segment\">
        <h3 class=\"ui header\">Create New Account</h3>
        <p>Sign up and we'll keep you on top of everything fresh with the latest news about web development.</p>
        <div class=\"field\">
          <div class=\"ui left icon action input\">
            <i class=\"user icon\"></i>
            <input name=\"email\" type=\"text\" placeholder=\"name@email.com\">
            <a href=\"";
        // line 76
        echo $this->env->getExtension('routing')->getPath("web_admin_security_register");
        echo "\" class=\"ui teal button\">Sign up</a>
          </div>
        </div>
        <div class=\"ui error message\"></div>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 76,  156 => 69,  142 => 58,  128 => 47,  122 => 43,  116 => 41,  114 => 40,  104 => 38,  102 => 37,  96 => 33,  87 => 30,  81 => 29,  78 => 28,  74 => 27,  64 => 20,  56 => 15,  52 => 14,  42 => 7,  39 => 6,  36 => 5,  29 => 3,);
    }
}
