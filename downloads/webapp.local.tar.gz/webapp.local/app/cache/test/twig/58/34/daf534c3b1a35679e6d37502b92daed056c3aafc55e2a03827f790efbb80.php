<?php

/* WebBlogBundle:Home:index.html.twig */
class __TwigTemplate_5834daf534c3b1a35679e6d37502b92daed056c3aafc55e2a03827f790efbb80 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Web development - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : $this->getContext($context, "website_name")), "html", null, true);
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<div id=\"banner\" class=\"ui segment\">
  <img class=\"ui image\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("images/web-development.jpg"), "html", null, true);
        echo "\" alt=\"Banner\" />
</div>


<div class=\"home-section ui page grid stackable feature segment\">
  <div class=\"row\">
    <div class=\"ten wide column\">
      <h2 class=\"ui header\">How to Win Your Attention</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc nec dolor consectetur, fringilla diam vitae, placerat nisl. Suspendisse placerat vestibulum arcu at ornare. Vivamus condimentum dignissim orci tempor vehicula. Mauris tincidunt venenatis risus, ac consequat odio dignissim vitae.</p>
      <div class=\"ui basic animated button\">
        <div class=\"visible content\">Read More</div>
        <div class=\"hidden content\"><i class=\"right arrow icon\"></i></div>
      </div>
      <div class=\"ui section divider\"></div>
      <h3 class=\"ui header\">More articles</h3>
      <div class=\"ui animated selection list\">
        ";
        // line 23
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 24
            echo "        <div class=\"item\">
          <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "name", array()), "html", null, true);
            echo "</a>
          <div class=\"right floated\">";
            // line 26
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "date", array()), "M d, Y"), "html", null, true);
            echo "</div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "      </div>
    </div>
    
    <div class=\"six wide column\">
      ";
        // line 33
        if ((!$this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 34
            echo "      <form action=\"";
            echo $this->env->getExtension('routing')->getPath("web_admin_security_logincheck");
            echo "\" method=\"post\" class=\"ui form segment ";
            if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
                echo "error";
            }
            echo "\">
        <div class=\"ui error message\">
            ";
            // line 36
            if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
                // line 37
                echo "            ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message", array()), "html", null, true);
                echo "
            ";
            }
            // line 39
            echo "        </div>
        <div class=\"field\">
          <label for=\"username\">Username</label>
          <div class=\"ui left labeled icon input\">
            <input placeholder=\"Username\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
            // line 43
            echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
            echo "\">
            <i class=\"user icon\"></i>
            <div class=\"ui corner label\">
              <i class=\"icon asterisk\"></i>
            </div>
          </div>
        </div>
        <div class=\"field\">
          <label for=\"password\">Password</label>
          <div class=\"ui left labeled icon input\">
            <input type=\"password\" id=\"password\" name=\"_password\" placeholder=\"Password\">
            <input type=\"hidden\" name=\"_target_path\" value=\"";
            // line 54
            echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
            echo "\" />
            <i class=\"lock icon\"></i>
            <div class=\"ui corner label\">
              <i class=\"icon asterisk\"></i>
            </div>
          </div>
        </div>
        <button type=\"submit\" class=\"ui blue submit button\">Login</button>
      </form>
      <div class=\"ui horizontal divider\">Or</div>
      ";
        }
        // line 65
        echo "      <div class=\"ui secondary form segment\">
        <h3 class=\"ui header\">Create New Account</h3>
        <p>Sign up and get spammed with news every day. We have no unsubscribe button!</p>
        <div class=\"field\">
          <div class=\"ui left icon action input\">
            <i class=\"user icon\"></i>
            <input name=\"email\" type=\"text\" placeholder=\"name@email.com\">
            <div class=\"ui teal submit button\">Sign up</div>
          </div>
        </div>
        <div class=\"ui error message\"></div>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 65,  129 => 54,  115 => 43,  109 => 39,  103 => 37,  101 => 36,  91 => 34,  89 => 33,  83 => 29,  74 => 26,  68 => 25,  65 => 24,  61 => 23,  42 => 7,  39 => 6,  36 => 5,  29 => 3,);
    }
}
