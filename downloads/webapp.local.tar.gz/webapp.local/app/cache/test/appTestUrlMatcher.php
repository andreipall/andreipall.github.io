<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appTestUrlMatcher
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appTestUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/categories')) {
                // web_admin_category_index
                if (rtrim($pathinfo, '/') === '/admin/categories') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_category_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'web_admin_category_index');
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::indexAction',  '_route' => 'web_admin_category_index',);
                }
                not_web_admin_category_index:

                // web_admin_category_create
                if ($pathinfo === '/admin/categories/') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_web_admin_category_create;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::createAction',  '_route' => 'web_admin_category_create',);
                }
                not_web_admin_category_create:

                // web_admin_category_new
                if ($pathinfo === '/admin/categories/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_category_new;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::newAction',  '_route' => 'web_admin_category_new',);
                }
                not_web_admin_category_new:

                // web_admin_category_edit
                if (preg_match('#^/admin/categories/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_category_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_category_edit')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::editAction',));
                }
                not_web_admin_category_edit:

                // web_admin_category_update
                if (preg_match('#^/admin/categories/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'PUT') {
                        $allow[] = 'PUT';
                        goto not_web_admin_category_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_category_update')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::updateAction',));
                }
                not_web_admin_category_update:

                // web_admin_category_delete
                if (preg_match('#^/admin/categories/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_web_admin_category_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_category_delete')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\CategoryController::deleteAction',));
                }
                not_web_admin_category_delete:

            }

            // web_admin_default_index
            if ($pathinfo === '/admin/dashboard') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::indexAction',  '_route' => 'web_admin_default_index',);
            }

            // web_admin_default_profile
            if ($pathinfo === '/admin/profile') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::profileAction',  '_route' => 'web_admin_default_profile',);
            }

            // web_admin_default_account
            if ($pathinfo === '/admin/account-settings') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::accountAction',  '_route' => 'web_admin_default_account',);
            }

            if (0 === strpos($pathinfo, '/admin/friends')) {
                // web_admin_default_friends
                if ($pathinfo === '/admin/friends') {
                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::friendsAction',  '_route' => 'web_admin_default_friends',);
                }

                // web_admin_default_removefriend
                if (0 === strpos($pathinfo, '/admin/friends/delete') && preg_match('#^/admin/friends/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_web_admin_default_removefriend;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_default_removefriend')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::removeFriendAction',));
                }
                not_web_admin_default_removefriend:

            }

            // web_admin_default_messages
            if ($pathinfo === '/admin/messages') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::messagesAction',  '_route' => 'web_admin_default_messages',);
            }

            // web_admin_default_getusers
            if (0 === strpos($pathinfo, '/admin/friends/get') && preg_match('#^/admin/friends/get/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_default_getusers')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\DefaultController::getUsersAction',));
            }

            if (0 === strpos($pathinfo, '/admin/posts')) {
                // web_admin_post_index
                if (rtrim($pathinfo, '/') === '/admin/posts') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_post_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'web_admin_post_index');
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::indexAction',  '_route' => 'web_admin_post_index',);
                }
                not_web_admin_post_index:

                // web_admin_post_create
                if ($pathinfo === '/admin/posts/') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_web_admin_post_create;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::createAction',  '_route' => 'web_admin_post_create',);
                }
                not_web_admin_post_create:

                // web_admin_post_new
                if ($pathinfo === '/admin/posts/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_post_new;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::newAction',  '_route' => 'web_admin_post_new',);
                }
                not_web_admin_post_new:

                // web_admin_post_edit
                if (preg_match('#^/admin/posts/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_post_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_post_edit')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::editAction',));
                }
                not_web_admin_post_edit:

                // web_admin_post_update
                if (preg_match('#^/admin/posts/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'PUT') {
                        $allow[] = 'PUT';
                        goto not_web_admin_post_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_post_update')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::updateAction',));
                }
                not_web_admin_post_update:

                // web_admin_post_delete
                if (preg_match('#^/admin/posts/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_web_admin_post_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_post_delete')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\PostController::deleteAction',));
                }
                not_web_admin_post_delete:

            }

            // web_admin_security_login
            if ($pathinfo === '/admin/login') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\SecurityController::loginAction',  '_route' => 'web_admin_security_login',);
            }

            // web_admin_security_register
            if ($pathinfo === '/admin/sign-up') {
                return array (  '_controller' => 'Web\\AdminBundle\\Controller\\SecurityController::registerAction',  '_route' => 'web_admin_security_register',);
            }

            if (0 === strpos($pathinfo, '/admin/log')) {
                // web_admin_security_logincheck
                if ($pathinfo === '/admin/login_check') {
                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\SecurityController::loginCheckAction',  '_route' => 'web_admin_security_logincheck',);
                }

                // web_admin_security_logout
                if ($pathinfo === '/admin/logout') {
                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'web_admin_security_logout',);
                }

            }

            if (0 === strpos($pathinfo, '/admin/users')) {
                // web_admin_user_index
                if (rtrim($pathinfo, '/') === '/admin/users') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_user_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'web_admin_user_index');
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::indexAction',  '_route' => 'web_admin_user_index',);
                }
                not_web_admin_user_index:

                // web_admin_user_create
                if ($pathinfo === '/admin/users/') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_web_admin_user_create;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::createAction',  '_route' => 'web_admin_user_create',);
                }
                not_web_admin_user_create:

                // web_admin_user_new
                if ($pathinfo === '/admin/users/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_user_new;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::newAction',  '_route' => 'web_admin_user_new',);
                }
                not_web_admin_user_new:

                // web_admin_user_edit
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_user_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_user_edit')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::editAction',));
                }
                not_web_admin_user_edit:

                // web_admin_user_update
                if (preg_match('#^/admin/users/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'PUT') {
                        $allow[] = 'PUT';
                        goto not_web_admin_user_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_user_update')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::updateAction',));
                }
                not_web_admin_user_update:

                // web_admin_user_delete
                if (preg_match('#^/admin/users/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_web_admin_user_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_user_delete')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\UserController::deleteAction',));
                }
                not_web_admin_user_delete:

            }

            if (0 === strpos($pathinfo, '/admin/website')) {
                // web_admin_website_index
                if (rtrim($pathinfo, '/') === '/admin/website') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_website_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'web_admin_website_index');
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::indexAction',  '_route' => 'web_admin_website_index',);
                }
                not_web_admin_website_index:

                // web_admin_website_create
                if ($pathinfo === '/admin/website/') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_web_admin_website_create;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::createAction',  '_route' => 'web_admin_website_create',);
                }
                not_web_admin_website_create:

                // web_admin_website_new
                if ($pathinfo === '/admin/website/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_website_new;
                    }

                    return array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::newAction',  '_route' => 'web_admin_website_new',);
                }
                not_web_admin_website_new:

                // web_admin_website_edit
                if (preg_match('#^/admin/website/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_web_admin_website_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_website_edit')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::editAction',));
                }
                not_web_admin_website_edit:

                // web_admin_website_update
                if (preg_match('#^/admin/website/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'PUT') {
                        $allow[] = 'PUT';
                        goto not_web_admin_website_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_website_update')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::updateAction',));
                }
                not_web_admin_website_update:

                // web_admin_website_delete
                if (preg_match('#^/admin/website/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_web_admin_website_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_admin_website_delete')), array (  '_controller' => 'Web\\AdminBundle\\Controller\\WebsiteController::deleteAction',));
                }
                not_web_admin_website_delete:

            }

        }

        if (0 === strpos($pathinfo, '/blog')) {
            // web_blog_blog_index
            if (preg_match('#^/blog/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_blog_blog_index')), array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::indexAction',));
            }

            // web_blog_blog_list
            if ($pathinfo === '/blog') {
                return array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::listAction',  '_route' => 'web_blog_blog_list',);
            }

            // web_blog_blog_listbyname
            if ($pathinfo === '/blog-a-z') {
                return array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::listByNameAction',  '_route' => 'web_blog_blog_listbyname',);
            }

            if (0 === strpos($pathinfo, '/blog/c')) {
                // web_blog_blog_listbycategory
                if (0 === strpos($pathinfo, '/blog/category') && preg_match('#^/blog/category/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_blog_blog_listbycategory')), array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::listByCategoryAction',));
                }

                if (0 === strpos($pathinfo, '/blog/comment')) {
                    // web_blog_blog_newcomment
                    if ($pathinfo === '/blog/comment/new') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_web_blog_blog_newcomment;
                        }

                        return array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::newCommentAction',  '_route' => 'web_blog_blog_newcomment',);
                    }
                    not_web_blog_blog_newcomment:

                    // web_blog_blog_deletecomment
                    if (0 === strpos($pathinfo, '/blog/comment/delete') && preg_match('#^/blog/comment/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_blog_blog_deletecomment')), array (  '_controller' => 'Web\\BlogBundle\\Controller\\BlogController::deleteCommentAction',));
                    }

                }

            }

        }

        // web_blog_home_index
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'web_blog_home_index');
            }

            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::indexAction',  '_route' => 'web_blog_home_index',);
        }

        // web_blog_home_search
        if ($pathinfo === '/search') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::searchAction',  '_route' => 'web_blog_home_search',);
        }

        // web_blog_home_portfolio
        if ($pathinfo === '/portfolio') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::portfolioAction',  '_route' => 'web_blog_home_portfolio',);
        }

        // web_blog_home_about
        if ($pathinfo === '/about') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::aboutAction',  '_route' => 'web_blog_home_about',);
        }

        // web_blog_home_contact
        if ($pathinfo === '/contact') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::contactAction',  '_route' => 'web_blog_home_contact',);
        }

        // web_blog_home_vote
        if (0 === strpos($pathinfo, '/portfolio/website/vote') && preg_match('#^/portfolio/website/vote/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_blog_home_vote')), array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::voteAction',));
        }

        // web_blog_home_terms
        if ($pathinfo === '/terms') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::termsAction',  '_route' => 'web_blog_home_terms',);
        }

        // web_blog_home_privacy
        if ($pathinfo === '/privacy') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::privacyAction',  '_route' => 'web_blog_home_privacy',);
        }

        // web_blog_home_sitemap
        if (0 === strpos($pathinfo, '/sitemap') && preg_match('#^/sitemap\\.(?P<_format>xml)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'web_blog_home_sitemap')), array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::sitemapAction',));
        }

        // web_blog_home_feed
        if ($pathinfo === '/rss.xml') {
            return array (  '_controller' => 'Web\\BlogBundle\\Controller\\HomeController::rssAction',  '_route' => 'web_blog_home_feed',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
