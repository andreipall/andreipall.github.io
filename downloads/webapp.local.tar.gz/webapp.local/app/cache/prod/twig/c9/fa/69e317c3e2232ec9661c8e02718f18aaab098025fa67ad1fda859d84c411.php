<?php

/* WebBlogBundle::blog_layout.html.twig */
class __TwigTemplate_c9fa69e317c3e2232ec9661c8e02718f18aaab098025fa67ad1fda859d84c411 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
    }

    // line 4
    public function block_sidebar($context, array $blocks = array())
    {
        // line 5
        echo "<aside class=\"right-sidebar ui vertical menu right floated four wide column\">
  <div class=\"header item\">
    <i class=\"block layout icon\"></i>
    Categories
  </div>
  ";
        // line 20
        echo "  ";
        if ((isset($context["categories"]) ? $context["categories"] : null)) {
            // line 21
            echo "  <div class=\"item\">
      ";
            // line 22
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 23
                echo "          ";
                if (twig_test_empty($this->getAttribute($context["category"], "parent", array()))) {
                    // line 24
                    echo "              ";
                    echo $this->getAttribute($this, "recursiveCategory", array(0 => $context["category"]), "method");
                    echo "
          ";
                }
                // line 26
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "  </div>
  ";
        }
        // line 29
        echo "</aside>
";
    }

    // line 10
    public function getrecursiveCategory($__category__ = null)
    {
        $context = $this->env->mergeGlobals(array(
            "category" => $__category__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 11
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_listbycategory", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "slug", array()))), "html", null, true);
            echo "\" ";
            if ((!twig_test_empty($this->getAttribute((isset($context["category"]) ? $context["category"] : null), "parent", array())))) {
                echo "class=\"item\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "name", array()), "html", null, true);
            echo "</a>
    ";
            // line 12
            if (twig_length_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "children", array()))) {
                // line 13
                echo "        <div class=\"menu\">
            ";
                // line 14
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["category"]) ? $context["category"] : null), "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 15
                    echo "                ";
                    echo $this->getAttribute($this, "recursiveCategory", array(0 => $context["child"]), "method");
                    echo "
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 17
                echo "        </div>
    ";
            }
            // line 19
            echo "  ";
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "WebBlogBundle::blog_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 19,  124 => 17,  115 => 15,  111 => 14,  108 => 13,  106 => 12,  95 => 11,  84 => 10,  79 => 29,  75 => 27,  69 => 26,  63 => 24,  60 => 23,  56 => 22,  53 => 21,  50 => 20,  43 => 5,  40 => 4,  35 => 3,  30 => 2,);
    }
}
