<?php

/* WebBlogBundle:Home:rss.xml.twig */
class __TwigTemplate_348113bc7b5f0935a0fa0023b86eb98b852dccf7368442e15c36482e9c4a24a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<rss version=\"2.0\">
<channel>
<title>";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo " RSS</title>
<description>Web development feeds</description>
<link>";
        // line 6
        echo $this->env->getExtension('routing')->getPath("web_blog_home_feed");
        echo "</link>
<lastBuildDate>";
        // line 7
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo "</lastBuildDate>
<pubDate>";
        // line 8
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo "</pubDate>
<ttl>86400</ttl>
<item>
<title>Web development - ";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo "</title>
<description>Web development</description>
<link>";
        // line 13
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "</link>
<guid>";
        // line 14
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "</guid>
<pubDate>";
        // line 15
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo " </pubDate>
</item>
<item>
<title>Portfolio - ";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo "</title>
<description>Portfolio</description>
<link>";
        // line 20
        echo $this->env->getExtension('routing')->getPath("web_blog_home_portfolio");
        echo "</link>
<guid>";
        // line 21
        echo $this->env->getExtension('routing')->getPath("web_blog_home_portfolio");
        echo "</guid>
<pubDate>";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo " </pubDate>
</item>
<item>
<title>Blog - ";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo "</title>
<description>Blog</description>
<link>";
        // line 27
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "</link>
<guid>";
        // line 28
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "</guid>
<pubDate>";
        // line 29
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo " </pubDate>
</item>
";
        // line 31
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 32
            echo "<item>
<title>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "name", array()), "html", null, true);
            echo "</title>
<description>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "metadescription", array()), "html", null, true);
            echo "</description>
<link>";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "</link>
<guid>";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "</guid>
<pubDate>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "date", array()), "c"), "html", null, true);
            echo " </pubDate>
</item>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "<item>
<title>About - ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo "</title>
<description>About</description>
<link>";
        // line 43
        echo $this->env->getExtension('routing')->getPath("web_blog_home_about");
        echo "</link>
<guid>";
        // line 44
        echo $this->env->getExtension('routing')->getPath("web_blog_home_about");
        echo "</guid>
<pubDate>";
        // line 45
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo " </pubDate>
</item>
<item>
<title>Contact - ";
        // line 48
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
        echo "</title>
<description>Contact</description>
<link>";
        // line 50
        echo $this->env->getExtension('routing')->getPath("web_blog_home_contact");
        echo "</link>
<guid>";
        // line 51
        echo $this->env->getExtension('routing')->getPath("web_blog_home_contact");
        echo "</guid>
<pubDate>";
        // line 52
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "c"), "html", null, true);
        echo " </pubDate>
</item>
</channel>
</rss>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:rss.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 52,  162 => 51,  158 => 50,  153 => 48,  147 => 45,  143 => 44,  139 => 43,  134 => 41,  131 => 40,  122 => 37,  118 => 36,  114 => 35,  110 => 34,  106 => 33,  103 => 32,  99 => 31,  94 => 29,  90 => 28,  86 => 27,  81 => 25,  75 => 22,  71 => 21,  67 => 20,  62 => 18,  56 => 15,  52 => 14,  48 => 13,  43 => 11,  37 => 8,  33 => 7,  29 => 6,  24 => 4,  19 => 1,);
    }
}
