<?php

/* AdminBundle:Post:index.html.twig */
class __TwigTemplate_3c6aad07965e49721b07e143a3f4d15c28b13c9e150d278a2a4d2f4cc95a03f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Posts - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h4 class=\"ui dividing header\">Posts</h4>
    
    <table class=\"ui table segment\">
      <thead>
        <tr>
          <th>Date</th>
          <th>Name</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ";
        // line 16
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 17
            echo "        <tr>
          <td>";
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["entity"], "date", array()), "d M Y"), "html", null, true);
            echo "</td>
          <td><a href=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_index", array("slug" => $this->getAttribute($context["entity"], "slug", array()))), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "name", array()), "html", null, true);
            echo "</a></td>
          <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, $this->getAttribute($context["entity"], "content", array()), 300), "html", null, true);
            echo "</td>
          <td>
            <div class=\"mini ui buttons\"><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_post_edit", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" class=\"ui button\">edit</a> <div class=\"or\"></div> <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_post_delete", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "name", array()), "html", null, true);
            echo "\" class=\"ui button confirm delete\">delete</a></div>
          </td>
        </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "      </tbody>
      <tfoot>
        <tr>
          <th colspan=\"4\"><a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("web_admin_post_new");
        echo "\" class=\"ui blue labeled icon button\"><i class=\"user icon\"></i> Add Post</a></th>
        </tr>
      </tfoot>
    </table>
    
    <div class=\"ui one column stackable center aligned page grid\">";
        // line 34
        echo $this->env->getExtension('knp_pagination')->render((isset($context["pagination"]) ? $context["pagination"] : null));
        echo "</div>
    
    <div class=\"ui modal small\">
      <i class=\"close icon\"></i>
      <div class=\"header\">
        Delete post
      </div>
      <div class=\"content\">
        Are you sure you want to delete this post: <strong id=\"name\"></strong>?
      </div>
      <div class=\"actions\">
        <a class=\"ui negative button\">Cancel</a>
        <a id=\"button_confirm\" class=\"ui positive right labeled icon button\">OK <i class=\"checkmark icon\"></i></a>
      </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Post:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 34,  94 => 29,  89 => 26,  75 => 22,  70 => 20,  64 => 19,  60 => 18,  57 => 17,  53 => 16,  39 => 4,  36 => 3,  29 => 2,);
    }
}
