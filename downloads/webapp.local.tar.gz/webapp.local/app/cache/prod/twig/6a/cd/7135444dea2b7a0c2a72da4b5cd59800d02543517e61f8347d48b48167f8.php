<?php

/* AdminBundle::admin_layout.html.twig */
class __TwigTemplate_6acd7135444dea2b7a0c2a72da4b5cd59800d02543517e61f8347d48b48167f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'mainmenu' => array($this, 'block_mainmenu'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
    }

    // line 3
    public function block_mainmenu($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"admin-menu ui vertical menu left floated\">
  <a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("web_admin_default_index");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_index")) {
            echo "active";
        }
        echo " item\"><i class=\"dashboard icon\"></i> Dashboard</a>
  ";
        // line 6
        if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
            // line 7
            echo "  <a href=\"";
            echo $this->env->getExtension('routing')->getPath("web_admin_post_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_post_index")) {
                echo "active";
            }
            echo " item\"><i class=\"pencil icon\"></i> Posts</a>
  <a href=\"";
            // line 8
            echo $this->env->getExtension('routing')->getPath("web_admin_user_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_user_index")) {
                echo "active";
            }
            echo " item\"><i class=\"user icon\"></i> Users</a>
  <a href=\"";
            // line 9
            echo $this->env->getExtension('routing')->getPath("web_admin_category_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_category_index")) {
                echo "active";
            }
            echo " item\"><i class=\"filter layout icon\"></i> Categories</a>
  <a href=\"";
            // line 10
            echo $this->env->getExtension('routing')->getPath("web_admin_website_index");
            echo "\" class=\"";
            if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_website_index")) {
                echo "active";
            }
            echo " item\"><i class=\"briefcase icon\"></i> Portfolio</a>
  ";
        }
        // line 12
        echo "  <a href=\"";
        echo $this->env->getExtension('routing')->getPath("web_admin_default_friends");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_friends")) {
            echo "active";
        }
        echo " item\"><i class=\"users icon\"></i> Friends</a>
  <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("web_admin_default_messages");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_messages")) {
            echo "active";
        }
        echo " item\"><i class=\"chat icon\"></i> Messages</a>
  <a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("web_admin_default_profile");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_profile")) {
            echo "active";
        }
        echo " item\"><i class=\"edit icon\"></i> Edit Profile</a>
  <a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("web_admin_default_account");
        echo "\" class=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "web_admin_default_account")) {
            echo "active";
        }
        echo " item\"><i class=\"settings icon\"></i> Account Settings</a>
  <div class=\"item\">
    <div class=\"admin-center\">
      <img class=\"ui image\" src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "avatar", array()))), "html", null, true);
        echo "\">
      <p>";
        // line 19
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "firstname", array()) . " ") . $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "lastname", array())), "html", null, true);
        echo "</p>
    </div>
  </div>
</div>
";
    }

    // line 24
    public function block_body($context, array $blocks = array())
    {
        // line 25
        echo "<div id=\"admin-content\" class=\"ui segment content right floated\">
";
        // line 26
        $this->displayBlock('content', $context, $blocks);
        // line 27
        echo "</div>
";
    }

    // line 26
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 26,  142 => 27,  140 => 26,  137 => 25,  134 => 24,  125 => 19,  121 => 18,  111 => 15,  103 => 14,  95 => 13,  86 => 12,  77 => 10,  69 => 9,  61 => 8,  52 => 7,  50 => 6,  42 => 5,  39 => 4,  36 => 3,  31 => 2,);
    }
}
