<?php

/* WebBlogBundle:Blog:index.html.twig */
class __TwigTemplate_d2121eb94b382bb4806f1dc6475f6db2ad38cdd529241d837ce0a3aaedde0e86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("WebBlogBundle::blog_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebBlogBundle::blog_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "name", array()), "html", null, true);
        echo " - Blog - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"blog-post ui segment content left floated twelve wide column\">
<div class=\"ui breadcrumb\"> <a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("web_blog_home_index");
        echo "\" class=\"section\">Home</a> <div class=\"divider\"> / </div> <a href=\"";
        echo $this->env->getExtension('routing')->getPath("web_blog_blog_list");
        echo "\" class=\"section\">Blog</a> <div class=\"divider\"> / </div> <div class=\"active section\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "name", array()), "html", null, true);
        echo "</div> </div> 
<h1 class=\"title\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "name", array()), "html", null, true);
        echo "</h1>
";
        // line 7
        echo $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "content", array());
        echo " 

<h2>Comments</h2>
";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 11
            echo "<div class=\"ui success message\">
  <i class=\"close icon\"></i>
    ";
            // line 13
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "<div class=\"ui comments\">
  ";
        // line 48
        echo "
  ";
        // line 49
        if ($this->getAttribute((isset($context["post"]) ? $context["post"] : null), "comments", array())) {
            // line 50
            echo "      ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["post"]) ? $context["post"] : null), "comments", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 51
                echo "          ";
                if (twig_test_empty($this->getAttribute($context["comment"], "parent", array()))) {
                    // line 52
                    echo "              ";
                    echo $this->getAttribute($this, "recursiveComment", array(0 => $context["comment"], 1 => $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "slug", array())), "method");
                    echo "
          ";
                }
                // line 54
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 55
            echo "      ";
            if ($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array())) {
                // line 56
                echo "      <form action=\"";
                echo $this->env->getExtension('routing')->getPath("web_blog_blog_newcomment");
                echo "\" method=\"post\" class=\"ui reply form\">
        <div class=\"field\">
          <input type=\"hidden\" name=\"slug\" value=\"";
                // line 58
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "slug", array()), "html", null, true);
                echo "\" />
          <textarea name=\"body\" id=\"comment\"></textarea>
        </div>
        <button type=\"submit\" class=\"ui button submit labeled icon\">
          <i class=\"icon edit\"></i> Add Comment
        </button>
      </form>
      ";
            } else {
                // line 66
                echo "          <p>Please <a href=\"";
                echo $this->env->getExtension('routing')->getPath("web_admin_security_login");
                echo "\">log in</a> to post comments.</p>
      ";
            }
            // line 68
            echo "  ";
        }
        // line 69
        echo "</div>

</div>
";
    }

    // line 17
    public function getrecursiveComment($__comment__ = null, $__slug__ = null)
    {
        $context = $this->env->mergeGlobals(array(
            "comment" => $__comment__,
            "slug" => $__slug__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 18
            echo "  <div class=\"comment\">
    <a class=\"avatar\">
      <img src=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("/images/avatars/" . $this->getAttribute($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "author", array()), "avatar", array()))), "html", null, true);
            echo "\">
    </a>
    <div class=\"content\">
      <a class=\"author\">";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "author", array()), "html", null, true);
            echo "</a>
      <div class=\"metadata\">
        <span class=\"date\">";
            // line 25
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "date", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</span>
      </div>
      <div class=\"text\">
        ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "body", array()), "html", null, true);
            echo "
      </div>
      ";
            // line 30
            if ($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array())) {
                // line 31
                echo "      <div id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "id", array()), "html", null, true);
                echo "\" class=\"actions\" slug=\"";
                echo twig_escape_filter($this->env, (isset($context["slug"]) ? $context["slug"] : null), "html", null, true);
                echo "\">
        <a class=\"reply-link\">Reply</a>
        ";
                // line 33
                if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()) == $this->getAttribute($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "author", array()), "id", array()))) {
                    // line 34
                    echo "        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_blog_blog_deletecomment", array("id" => $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "id", array()))), "html", null, true);
                    echo "\" class=\"delete\">Delete</a>
        ";
                }
                // line 36
                echo "      </div>
      ";
            }
            // line 38
            echo "    </div>
    ";
            // line 39
            if (twig_length_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "children", array()))) {
                // line 40
                echo "        <div class=\"comments\">
            ";
                // line 41
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 42
                    echo "                ";
                    echo $this->getAttribute($this, "recursiveComment", array(0 => $context["child"], 1 => (isset($context["slug"]) ? $context["slug"] : null)), "method");
                    echo "
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 44
                echo "        </div>
    ";
            }
            // line 46
            echo "  </div>      
  ";
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Blog:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 46,  223 => 44,  214 => 42,  210 => 41,  207 => 40,  205 => 39,  202 => 38,  198 => 36,  192 => 34,  190 => 33,  182 => 31,  180 => 30,  175 => 28,  169 => 25,  164 => 23,  158 => 20,  154 => 18,  142 => 17,  135 => 69,  132 => 68,  126 => 66,  115 => 58,  109 => 56,  106 => 55,  100 => 54,  94 => 52,  91 => 51,  86 => 50,  84 => 49,  81 => 48,  78 => 16,  69 => 13,  65 => 11,  61 => 10,  55 => 7,  51 => 6,  43 => 5,  40 => 4,  37 => 3,  29 => 2,);
    }
}
