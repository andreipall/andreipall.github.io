<?php

/* AdminBundle:Category:index.html.twig */
class __TwigTemplate_9be2d99be7c290d37f5ecc9a4824a8da5f48a7d8332f101269db69dfe4d795bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::admin_layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::admin_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Categories - Admin - ";
        echo twig_escape_filter($this->env, (isset($context["website_name"]) ? $context["website_name"] : null), "html", null, true);
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h4 class=\"ui dividing header\">Categories</h4>

    <table class=\"ui table segment\">
        <thead>
            <tr>
                <th>Name</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 16
            echo "            <tr>
                <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "slug", array()), "html", null, true);
            echo "</td>
                <td>
                    <div class=\"mini ui buttons\"><a href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_category_edit", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" class=\"ui button\">edit</a> <div class=\"or\"></div> <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("web_admin_category_delete", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "name", array()), "html", null, true);
            echo "\" class=\"ui button confirm delete\">delete</a></div>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "        </tbody>
        <tfoot>
        <tr>
          <th colspan=\"4\"><a href=\"";
        // line 27
        echo $this->env->getExtension('routing')->getPath("web_admin_category_new");
        echo "\" class=\"ui blue labeled icon button\"><i class=\"user icon\"></i> Add Category</a></th>
        </tr>
      </tfoot>
    </table>
    
    <div class=\"ui modal small\">
      <i class=\"close icon\"></i>
      <div class=\"header\">
        Delete category
      </div>
      <div class=\"content\">
        Are you sure you want to delete this category: <strong id=\"name\"></strong>?
      </div>
      <div class=\"actions\">
        <a class=\"ui negative button\">Cancel</a>
        <a id=\"button_confirm\" class=\"ui positive right labeled icon button\">OK <i class=\"checkmark icon\"></i></a>
      </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Category:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 27,  82 => 24,  68 => 20,  63 => 18,  59 => 17,  56 => 16,  52 => 15,  39 => 4,  36 => 3,  29 => 2,);
    }
}
