<?php

/* WebBlogBundle:Home:sitemap.xml.twig */
class __TwigTemplate_f85d8090419690302150f7680155a9f9d2ce72f41060bde298698d7a0699a5c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" 
   xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"
   xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">
";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["urls"]) ? $context["urls"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["url"]) {
            // line 6
            echo "    <url>";
            // line 7
            echo "        <loc>";
            if ((strtr($this->getAttribute($context["url"], "loc", array()), array("hostname" => "")) == $this->getAttribute($context["url"], "loc", array()))) {
                echo twig_escape_filter($this->env, (isset($context["hostname"]) ? $context["hostname"] : null), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($context["url"], "loc", array()), "html", null, true);
            } else {
                echo twig_escape_filter($this->env, $this->getAttribute($context["url"], "loc", array()), "html", null, true);
            }
            echo "</loc>
";
            // line 8
            if ($this->getAttribute($context["url"], "lastmod", array(), "any", true, true)) {
                // line 9
                echo "        <lastmod>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["url"], "lastmod", array()), "html", null, true);
                echo "</lastmod>
";
            }
            // line 11
            if ($this->getAttribute($context["url"], "changefreq", array(), "any", true, true)) {
                // line 12
                echo "        <changefreq>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["url"], "changefreq", array()), "html", null, true);
                echo "</changefreq>
";
            }
            // line 14
            if ($this->getAttribute($context["url"], "priority", array(), "any", true, true)) {
                // line 15
                echo "        <priority>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["url"], "priority", array()), "html", null, true);
                echo "</priority>
";
            }
            // line 17
            echo "    </url>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['url'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "</urlset>
";
    }

    public function getTemplateName()
    {
        return "WebBlogBundle:Home:sitemap.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 19,  65 => 17,  59 => 15,  57 => 14,  51 => 12,  49 => 11,  43 => 9,  41 => 8,  31 => 7,  29 => 6,  25 => 5,  19 => 1,);
    }
}
