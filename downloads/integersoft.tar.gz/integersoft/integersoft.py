from controller.mainpage import *
from controller.blog import *
from controller.blogpost import *
from controller.posts import *
from controller.addpost import *
from controller.editpost import *
from controller.deletepost import *
from controller.addcategory import *
from controller.getpostimage import *
from controller.addcomment import *
from controller.downloadspage import *
from controller.downloadpost import *
from controller.downloads import *
from controller.adddownload import *
from controller.editdownload import *
from controller.deletedownload import *
from controller.getdownloadimage import *
from controller.getdownloadfile import *
from controller.portfolio import *
from controller.services import *
from controller.about import *
from controller.hire import *
from controller.contact import *
from controller.updatefeeds import *
from controller.search import *
from controller.feedpage import *
from controller.admin import *
from controller.addimage import *
from controller.deleteimage import *
from controller.getimage import *
from controller.images import *
from controller.googleanalytics import *
from controller.sitemap import *

app = webapp2.WSGIApplication([('/', MainPage),
							   ('/updatefeeds', UpdateFeeds),
                               ('/blog', Blog),
                               ('/portfolio', Portfolio),
                               ('/services', Services),
                               ('/about', About),
							   ('/hire', Hire),
                               ('/contact', Contact),
                               (r'/blog/image/(.*)', GetPostImage),
                               (r'/blog/(.*)', BlogPost),
                               ('/comment/add', AddComment),
                               ('/admin/posts', Posts),
                               ('/admin', Admin),
                               ('/admin/posts/add', AddPost),
                               (r'/admin/posts/edit/(.*)', EditPost),
                               (r'/admin/posts/delete/(.*)', DeletePost),
                               ('/downloads', DownloadsPage),
                               (r'/downloads/image/(.*)', GetDownloadImage),
                               (r'/downloads/file/(.*)', GetDownloadFile),
                               (r'/downloads/(.*)', DownloadPost),
                               ('/admin/downloads', Downloads),
                               ('/admin/downloads/add', AddDownload),
                               (r'/admin/downloads/edit/(.*)', EditDownload),
                               (r'/admin/downloads/delete/(.*)', DeleteDownload),
                               ('/admin/images/add', AddImage),
                               (r'/admin/images/delete/(.*)', DeleteImage),
                               ('/admin/images', Images),
                               (r'/image/(.*)', GetImage),
                               ('/admin/category/add', AddCategory),
                               (r'/search/(.*)', Search),
                               ('/feed', FeedPage),
							   ('/googlef4e365c2a0e9a0c1.html', GoogleAnalytics),
							   ('/sitemap.xml', Sitemap)],
                              debug=False)
