import datetime
from google.appengine.ext import db

class Image(db.Model):
  title = db.StringProperty(required=True)
  image = db.BlobProperty(required=True)
