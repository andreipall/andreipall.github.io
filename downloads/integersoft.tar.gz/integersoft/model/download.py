import datetime
from google.appengine.ext import db

class Download(db.Model):
  title = db.StringProperty(required=True)
  slug = db.StringProperty(required=True)
  meta_keywords = db.StringProperty()
  meta_description = db.StringProperty()
  image = db.BlobProperty(required=True)
  download = db.BlobProperty(required=True)
  content = db.TextProperty(required=True)
  counter = db.IntegerProperty(required=True)
  
