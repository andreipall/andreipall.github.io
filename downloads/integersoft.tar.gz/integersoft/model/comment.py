import datetime
from google.appengine.ext import db
from google.appengine.api import users
from post import *

class Comment(db.Model):
  comment = db.TextProperty(required=True)
  post = db.ReferenceProperty(Post, required=True, collection_name='post_comments')
  user = db.UserProperty(required=True)
  date = db.DateTimeProperty(auto_now_add=True)
