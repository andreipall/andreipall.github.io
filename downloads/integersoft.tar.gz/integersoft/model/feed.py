from google.appengine.ext import db


class Feed(db.Model):
  name = db.StringProperty(required=True)
  url = db.StringProperty(required=True)

  
