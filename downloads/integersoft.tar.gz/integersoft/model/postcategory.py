from google.appengine.ext import db
from post import *
from category import *

class PostCategory(db.Model):
	post = db.ReferenceProperty(Post, required=True, collection_name='postcategory_categories')
	category = db.ReferenceProperty(Category, required=True, collection_name='postcategory_posts')
