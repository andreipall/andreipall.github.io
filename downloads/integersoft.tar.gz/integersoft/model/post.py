import datetime
from google.appengine.ext import db
from google.appengine.api import users

class Post(db.Model):
  title = db.StringProperty(required=True)
  slug = db.StringProperty(required=True)
  meta_keywords = db.StringProperty()
  meta_description = db.StringProperty()
  image = db.BlobProperty(required=True)
  content = db.TextProperty(required=True)
  user = db.UserProperty(required=True)
  date = db.DateTimeProperty(auto_now_add=True)
  categories = db.ListProperty(db.Key)
  
