import webapp2
import jinja2
import os
from model.post import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))

class FeedPage(webapp2.RequestHandler):
  def get(self):
        baseurl = self.request.host_url
        query = Post.all()
        query.order("-date")
        posts = query.fetch(20)

        template_values = {
            'baseurl': baseurl,
            'posts': posts,
        }

        template = jinja_environment.get_template('feedpage.html')
        self.response.out.write(template.render(template_values))
