import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.ext import db
from model.post import *
from model.category import *
from model.postcategory import *
from model.feed import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class EditPost(webapp2.RequestHandler):
    def get(self, post_slug):
        baseurl = self.request.host_url
        q = Category.all()
        categories = q.fetch(50)
        saved_post = Post.gql("WHERE slug = :1", post_slug).get()
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
		
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'
		
        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Edit Post - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'categories': categories,
            'post_title': saved_post.title,
            'post_slug': saved_post.slug,
            'post_meta_keywords': saved_post.meta_keywords,
            'post_meta_description': saved_post.meta_description,
            'post_image': saved_post.image,
            'post_content': saved_post.content,
            'old_slug': post_slug,
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('editpost.html')
        self.response.out.write(template.render(template_values))

    def post(self):
		query = db.GqlQuery("SELECT __key__ FROM Post WHERE slug = :1", self.request.get('old_slug'))
		key = query.get()
		post_k = db.Key.from_path('Post', key.id_or_name())
		saved_post = Post.get(post_k)
		saved_post.title = self.request.get('title')
		saved_post.slug = self.request.get('slug')
		saved_post.meta_keywords = self.request.get('meta_keywords')
		saved_post.meta_description = self.request.get('meta_description')
		saved_post.image = db.Blob(self.request.get('image'))
		saved_post.content = self.request.get('content')
		saved_post.put()

		categories = Category.all()
		for category in categories:
			query = db.GqlQuery("SELECT __key__ FROM PostCategory WHERE key_name = :1", self.request.get('old_slug')+'_'+category.name)
			key = query.get()
			post_k = db.Key.from_path('PostCategory', key.id_or_name())
			post = db.get(post_k)
			post.delete()
		
		categories = self.request.get('categories', allow_multiple=True)
		for categ in categories:
			category = Category.gql("WHERE name = :1", categ).get()
			PostCategory(key_name=self.request.get('old_slug')+'_'+categ, post=saved_post, category=category).put()

		self.redirect('/')
        
