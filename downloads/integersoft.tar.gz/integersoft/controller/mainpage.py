import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from model.post import *
from model.download import *
from model.feed import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class MainPage(webapp2.RequestHandler):
    def get(self):
        baseurl = self.request.host_url
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
        q = Download.all()
        q.order("-counter")
        downloads = q.fetch(10)
        f = Feed.all()
        feeds = f.fetch(5)
		
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'

        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Integersoft - Professional software development services',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'latest_posts': latest_posts,
            'downloads': downloads,
            'feeds': feeds,
        }

        template = jinja_environment.get_template('index.html')
        self.response.out.write(template.render(template_values))
