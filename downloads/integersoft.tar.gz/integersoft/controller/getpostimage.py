import webapp2
from google.appengine.ext import db
from model.post import *

class GetPostImage(webapp2.RequestHandler):
	def get(self, post_slug):
		saved_post = Post.gql("WHERE slug = :1", post_slug).get()
		if saved_post.image:
			self.response.headers['Content-Type'] = 'image/png'
			self.response.out.write(saved_post.image)
		else:
			self.response.headers['Content-Type'] = 'text/plain'
			self.response.out.write("No image")
