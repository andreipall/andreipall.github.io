import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.ext import db
from google.appengine.api import search
from model.post import *
from model.category import *
from model.postcategory import *
from model.feed import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))

def CreateDocument(title, slug, image, content, date, user):
    # Let the search service supply the document id.
    return search.Document(
        fields=[search.TextField(name='title', value=title),
                search.HtmlField(name='content', value=content),
                search.DateField(name='date', value=date)])

class AddPost(webapp2.RequestHandler):
    def get(self):
        baseurl = self.request.host_url
        q = Category.all()
        categories = q.fetch(10)
        f = Feed.all()
        feeds = f.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
		
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'
		
        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Add post - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'categories': categories,
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('addpost.html')
        self.response.out.write(template.render(template_values))

    def post(self):
		title = self.request.get('title')
		slug = self.request.get('slug')
		meta_keywords = self.request.get('meta_keywords')
		meta_description = self.request.get('meta_description')
		image = self.request.get('image')
		content = self.request.get('content')
		user = users.get_current_user()
		post = Post(key_name=slug, title=title, slug=slug, meta_keywords=meta_keywords, meta_description=meta_description, image=db.Blob(image), content=content, user=user)
		post.put()
		
		saved_post = Post.gql("WHERE slug = :1", slug).get()
		categories = self.request.get('categories', allow_multiple=True)
		for categ in categories:
			category = Category.gql("WHERE name = :1", categ).get()
			PostCategory(key_name=slug+'_'+categ, post=saved_post, category=category).put()

		search.Index(name='index').add(CreateDocument(saved_post.title, saved_post.slug, saved_post.image, saved_post.content, saved_post.date.date(), saved_post.user))
		self.redirect('/admin/posts')
        
