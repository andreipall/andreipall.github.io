import webapp2
from google.appengine.ext import db
from model.download import *

class GetDownloadImage(webapp2.RequestHandler):
	def get(self, post_slug):
		saved_post = Download.gql("WHERE slug = :1", post_slug).get()
		if saved_post.image:
			self.response.headers['Content-Type'] = 'image/png'
			self.response.out.write(saved_post.image)
		else:
			self.response.headers['Content-Type'] = 'text/plain'
			self.response.out.write("No image")
