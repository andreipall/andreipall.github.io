import webapp2
from google.appengine.ext import db
from model.image import *

class DeleteImage(webapp2.RequestHandler):
    def get(self, post_slug):
		post = Image.get_by_key_name(post_slug)
		post.delete()
		self.redirect('/admin/images')
