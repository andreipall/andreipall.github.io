import webapp2
from google.appengine.ext import db

class DeletePost(webapp2.RequestHandler):
    def get(self, post_slug):
		query = db.GqlQuery("SELECT __key__ FROM Post WHERE slug = :1", post_slug)
		key = query.get()
		post_k = db.Key.from_path('Post', key.id_or_name())
		post = db.get(post_k)
		post.delete()
		self.redirect('/admin/posts')
