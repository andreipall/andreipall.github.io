import datetime
import webapp2
import jinja2
import os

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class GoogleAnalytics(webapp2.RequestHandler):
  def get(self):
        template_values = {
        }

        template = jinja_environment.get_template('googlef4e365c2a0e9a0c1.html')
        self.response.out.write(template.render(template_values))
