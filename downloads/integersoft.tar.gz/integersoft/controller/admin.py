import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.ext import db
from model.feed import *
from model.post import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class Admin(webapp2.RequestHandler):
  def get(self):
        baseurl = self.request.host_url
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
        
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
            logged_in = True
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'
            logged_in = False

        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Admin - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('admin.html')
        self.response.out.write(template.render(template_values))
