import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.ext import db
from model.download import *
from model.feed import *
from model.post import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class AddDownload(webapp2.RequestHandler):
    def get(self):
        baseurl = self.request.host_url
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
		
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'
		
        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Add download - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('adddownload.html')
        self.response.out.write(template.render(template_values))

    def post(self):
		title = self.request.get('title')
		slug = self.request.get('slug')
		meta_keywords = self.request.get('meta_keywords')
		meta_description = self.request.get('meta_description')
		image = self.request.get('image')
		download = self.request.get('download')
		content = self.request.get('content')
		post = Download(key_name=slug, title=title, slug=slug, meta_keywords=meta_keywords, meta_description=meta_description, image=db.Blob(image), download=db.Blob(download), content=content, counter=0)
		post.put()

		self.redirect('/admin/downloads')
        
