import webapp2
from google.appengine.ext import db
from model.image import *

class GetImage(webapp2.RequestHandler):
	def get(self, post_slug):
		saved_post = Image.get_by_key_name(post_slug)
		if saved_post.image:
			self.response.headers['Content-Type'] = 'image/png'
			self.response.out.write(saved_post.image)
		else:
			self.response.headers['Content-Type'] = 'text/plain'
			self.response.out.write("No image")
