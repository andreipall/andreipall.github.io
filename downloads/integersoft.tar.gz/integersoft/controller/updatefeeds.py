import datetime
import os
import webapp2
from xml.dom import minidom
from google.appengine.api import users
from google.appengine.ext import db
from model.feed import *
from google.appengine.api import urlfetch

def get_text(nodelist):
	rc = ""
	for node in nodelist:
		if node.nodeType == node.TEXT_NODE:
			rc = rc + node.data
	return rc

class UpdateFeeds(webapp2.RequestHandler):
    def get(self):
        baseurl = self.request.host_url
        url = 'http://www.h-online.com/developer/atom.xml'
        result = urlfetch.fetch(url)
        if result.status_code == 200:
			file_xml = minidom.parseString(result.content)
			items = file_xml.getElementsByTagName('entry')
			for position, item in enumerate(items[:5]):
				title = get_text(item.getElementsByTagName('title')[0].childNodes)
				link = get_text(item.getElementsByTagName('id')[0].childNodes)
				feed = Feed(key_name='feed'+str(position), name=title, url=link)
				feed.put()


