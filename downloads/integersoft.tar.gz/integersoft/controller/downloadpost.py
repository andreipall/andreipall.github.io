import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.ext import db
from model.download import *
from model.feed import *
from model.post import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class DownloadPost(webapp2.RequestHandler):
  def get(self, post_slug):
        baseurl = self.request.host_url
        saved_post = Download.gql("WHERE slug = :1", post_slug).get()
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
        
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
            logged_in = True
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'
            logged_in = False

        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': saved_post.title + ' - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'post_title': saved_post.title,
            'post_slug': saved_post.slug,
            'post_meta_keywords': saved_post.meta_keywords,
            'post_meta_description': saved_post.meta_description,
            'post_content': saved_post.content,
            'post_counter': saved_post.counter,
            'logged_in': logged_in,
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('download_post.html')
        self.response.out.write(template.render(template_values))
