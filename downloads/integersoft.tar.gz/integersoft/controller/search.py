import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from google.appengine.api import search
from model.post import *
from model.paging import *
from model.feed import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))

class Search(webapp2.RequestHandler):
  def get(self, search_terms):
        baseurl = self.request.host_url
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
        query_string = self.request.get("s")
        query = search.Query(query_string)
        index = search.Index(name='index')
        stuffs = index.search(query)
        
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'

        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Search - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'stuffs': stuffs,
            'feeds': feeds,
            'latest_posts': latest_posts,
        }

        """for scored_document in stuffs:
			self.response.out.write(scored_document.fields)
        template = jinja_environment.get_template('search.html')
        self.response.out.write(template.render(template_values))"""
