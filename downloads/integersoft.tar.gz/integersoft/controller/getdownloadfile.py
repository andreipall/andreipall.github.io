import webapp2
from google.appengine.ext import db
from model.download import *

class GetDownloadFile(webapp2.RequestHandler):
	def get(self, post_slug):
		saved_post = Download.gql("WHERE slug = :1", post_slug).get()
		if saved_post.download:
			saved_post.counter = saved_post.counter + 1
			saved_post.put()
			self.response.headers['Content-Type'] = 'application/x-tar'
			self.response.out.write(saved_post.download)
		else:
			self.response.headers['Content-Type'] = 'text/plain'
			self.response.out.write("No image")
