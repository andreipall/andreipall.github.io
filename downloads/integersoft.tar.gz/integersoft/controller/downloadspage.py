import datetime
import webapp2
import jinja2
import os
from google.appengine.api import users
from model.download import *
from model.paging import *
from model.feed import *
from model.post import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))

def getMyStuff(page):
	query = Download.all()
	query.order("-counter")
	myPagedQuery = PagedQuery(query, 3)
	ret={}
	
	if page > 1:
		ret["results"] = myPagedQuery.fetch_page(page)
		ret["prevPageExists"] = myPagedQuery.has_page(page-1)
	else:
		ret["results"] = myPagedQuery.fetch_page()
		ret["prevPageExists"]=False
	
	ret["nextPageExists"] = myPagedQuery.has_page(page+1)
	
	return ret

class DownloadsPage(webapp2.RequestHandler):
  def get(self):
        baseurl = self.request.host_url
        page = self.request.get("page", default_value=1)
        page = int(page)
        pageinfo = getMyStuff(page)
        stuffs = pageinfo["results"]
        q = Feed.all()
        feeds = q.fetch(5)
        query = Post.all()
        query.order("-date")
        latest_posts = query.fetch(4)
        
        prev_page = None
        if pageinfo["prevPageExists"]:
			prev_page = page - 1
        
        next_page = None
        if pageinfo["nextPageExists"]:
			next_page = page + 1
        
        if users.get_current_user():
            url = users.create_logout_url(self.request.uri)
            url_linktext = 'Logout'
        else:
            url = users.create_login_url(self.request.uri)
            url_linktext = 'Login or register via Google'

        template_values = {
            'baseurl': baseurl,
            'url': url,
            'title': 'Downloads - Integersoft',
            'url_linktext': url_linktext,
            'year': datetime.datetime.now().date().strftime("%Y"),
            'stuffs': stuffs,
            'prev_page_exists': pageinfo["prevPageExists"],
            'prev_page': prev_page,
            'page': page,
            'next_page_exists': pageinfo["nextPageExists"],
			'next_page': next_page,
			'feeds': feeds,
			'latest_posts': latest_posts,
        }

        template = jinja_environment.get_template('downloadspage.html')
        self.response.out.write(template.render(template_values))
