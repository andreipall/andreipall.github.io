import datetime
import webapp2
import jinja2
import os
from model.post import *
from model.download import *

VIEW_DIR = os.path.join(os.path.dirname(__file__), '../view')
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(VIEW_DIR))


class Sitemap(webapp2.RequestHandler):
  def get(self):
	baseurl = self.request.host_url
        query = Post.all()
        query.order("-date")
        posts = query.fetch(200)
        
        q = Download.all()
        downloads = q.fetch(200)
        
        template_values = {
	    'baseurl': baseurl,
            'posts': posts,
            'downloads': downloads,
        }

        template = jinja_environment.get_template('sitemap.xml')
        self.response.out.write(template.render(template_values))
