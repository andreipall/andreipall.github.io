import webapp2
from google.appengine.api import users
from google.appengine.ext import db
from model.post import *
from model.comment import *

class AddComment(webapp2.RequestHandler):
	def post(self):
		baseurl = self.request.host_url
		slug = self.request.get('post_slug')
		comment = self.request.get('comment')
		post = Post.gql("WHERE slug = :1", slug).get()
		user = users.get_current_user()
		newcomment = Comment(comment=comment, post=post, user=user)
		newcomment.put()

		self.redirect('/blog/'+slug)
