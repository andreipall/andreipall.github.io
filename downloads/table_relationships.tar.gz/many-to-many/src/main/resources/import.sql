insert into student (name) values ('Student 1');
insert into student (name) values ('Student 2');
insert into student (name) values ('Student 3');
insert into student (name) values ('Student 4');
insert into student (name) values ('Student 5');

insert into course (name) values ('Course 1');
insert into course (name) values ('Course 2');
insert into course (name) values ('Course 3');

insert into student_course (student_id, course_id) values (1, 1);
insert into student_course (student_id, course_id) values (1, 2);
insert into student_course (student_id, course_id) values (2, 1);
insert into student_course (student_id, course_id) values (2, 2);
insert into student_course (student_id, course_id) values (2, 3);