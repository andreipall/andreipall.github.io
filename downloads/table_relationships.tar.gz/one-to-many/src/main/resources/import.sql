insert into course (name) values ('Course 1');
insert into course (name) values ('Course 2');
insert into course (name) values ('Course 3');
insert into course (name) values ('Course 4');
insert into course (name) values ('Course 5');

insert into review (rating, description, course_id) values (4, 'Review 1', 1);
insert into review (rating, description, course_id) values (5, 'Review 2', 2);
insert into review (rating, description, course_id) values (5, 'Review 3', 2);
insert into review (rating, description, course_id) values (4, 'Review 4', 3);
insert into review (rating, description, course_id) values (3, 'Review 5', 3);
insert into review (rating, description, course_id) values (2, 'Review 6', 4);