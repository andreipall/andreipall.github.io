class HomeController < Simplemvc::Controller
  def index
  end
end
