<?php
// $Id$

/**
 * @file
 * Template for quote content 
 */
?>
<div class="test">

<?php print $nodes; ?>
<?php var_export($nodes); ?>
</div>
